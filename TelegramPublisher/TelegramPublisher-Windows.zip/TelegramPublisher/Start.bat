@echo off
cd /d "%~dp0"
py -3 bootstrap.pyw
if errorlevel 1 (
  echo Please install Python 3.12 from python.org with Tcl/Tk and the Python launcher.
  pause
)
