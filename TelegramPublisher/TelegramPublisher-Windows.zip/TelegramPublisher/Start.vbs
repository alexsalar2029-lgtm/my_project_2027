Option Explicit
Dim sh, fs, base, entry, launched
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
base = fs.GetParentFolderName(WScript.ScriptFullName)
entry = Chr(34) & fs.BuildPath(base, "bootstrap.pyw") & Chr(34)
sh.CurrentDirectory = base
launched = False
On Error Resume Next
sh.Run "pyw -3 " & entry, 1, False
If Err.Number = 0 Then launched = True
Err.Clear
If Not launched Then
    sh.Run "pythonw " & entry, 1, False
    If Err.Number = 0 Then launched = True
End If
On Error GoTo 0
If Not launched Then
    MsgBox "Install Python 3.12 for Windows from python.org (include Tcl/Tk and Python launcher), then run Start.vbs again.", 48, "Telegram Publisher"
End If
