"""Exit lifecycle regressions: recording clients only, never broker login."""
from types import SimpleNamespace
import pytest
from test_engine import make, run
from lordxau.engine import Setup
from test_management_211 import opened, CASES
from signal_trader.brokers.trendo_client import TrendoClient


def live_setup(eng, ex, ids, side='BUY'):
    s = Setup(side, [4184, 4185], 4181, True, 1000, ids=ids, placed=True)
    eng.live.append(s)
    ex.alive.update(ids)
    return s


@pytest.mark.parametrize('action', ['emitted', 'no_open_order', 'unconfirmed'])
def test_unknown_book_stays_tracked_even_after_ack(action):
    eng, ex, clk = make()
    st = live_setup(eng, ex, [101])
    ex.trade_state = lambda ids: None
    async def close(*args, **kwargs):
        return {'action': 'close', 'results': [{'action': action}]}
    ex.close = close
    lines = run(eng._close_ids([101], [st], clk.t))
    assert st in eng.live and not st.closed and not st.done
    assert eng.close_retry['ids'] == [101]
    assert 'تأیید شد' not in '\n'.join(lines)


def test_separate_exit_failures_survive_later_success():
    eng, ex, clk = make()
    a = live_setup(eng, ex, [101], 'BUY')
    b = live_setup(eng, ex, [102], 'SELL')
    actual = ex.close
    async def reject(*args, **kwargs):
        return {'action': 'rejected'}
    ex.close = reject
    run(eng._close_ids([101], [a], clk.t))
    run(eng._close_ids([102], [b], clk.t + 1))
    assert set(eng.close_retry['ids']) == {101, 102}
    ex.close = actual
    run(eng._close_ids([102], [b], clk.t + 2))
    assert eng.close_retry['ids'] == [101]
    run(eng.tick(now=clk.t + 6))
    assert not ex.alive and eng.close_retry is None


def test_exit_retained_beyond_old_deadline_with_bounded_backoff():
    eng, ex, clk = make()
    st = live_setup(eng, ex, [101])
    async def reject(*args, **kwargs):
        return {'action': 'rejected'}
    ex.close = reject
    run(eng._close_ids([101], [st], clk.t))
    for elapsed in [5, 15, 35, 75, 135, 195, 255]:
        run(eng.tick(now=clk.t + elapsed))
        assert eng.close_retry is not None
        assert 0 < eng.next_due() - (clk.t + elapsed) <= 60
    assert st in eng.live and 101 in ex.alive


def test_partial_close_retries_only_remaining_order():
    eng, ex, clk = make()
    st = live_setup(eng, ex, [101, 102])
    async def partial(*args, **kwargs):
        ex.alive.discard(101)
        return {'action': 'close', 'results': [{'action': 'closed', 'order_id': 101},
                                               {'action': 'rejected', 'order_id': 102}]}
    ex.close = partial
    run(eng._close_ids(st.ids, [st], clk.t))
    assert eng.close_retry['ids'] == [102]
    assert not st.done and not st.closed


@pytest.mark.parametrize('mode', ['rejected', 'timeout', 'exception', 'partial'])
def test_failed_or_partial_close_retains_protection(tmp_path, mode):
    eng, ex, client, clk = opened(tmp_path, CASES[0], virtual=True)
    client.quote = CASES[0][2]
    run(eng.handle('فریش کن', msg_id=2, ts=clk.t))
    before = ex.guards()
    assert before
    def failed(**kwargs):
        if mode == 'exception':
            raise ConnectionError('offline test')
        return {'action': 'close', 'results': [{'action': 'emitted' if mode == 'timeout' else mode}]}
    client.close_order = failed
    run(eng.handle('ببندش', msg_id=3, ts=clk.t))
    assert 41 in client.open_orders and ex.guards() == before
    assert eng.close_retry is not None
    assert not ex._channel_closing


def test_channel_close_reservation_prevents_tick_double_close(tmp_path):
    eng, ex, client, clk = opened(tmp_path, CASES[0], virtual=True)
    client.quote = CASES[0][2]
    run(eng.handle('فریش کن', msg_id=2, ts=clk.t))
    calls = []
    def close(**kwargs):
        calls.append(kwargs['order_id'])
        assert 41 in ex._channel_closing
        client.tick(ex, CASES[0][4])  # guard hit while channel close awaits ack
        client.open_orders.pop(41)
        return {'action': 'closed'}
    client.close_order = close
    run(eng.handle('ببندش', msg_id=3, ts=clk.t))
    assert calls == [41] and not ex.guards() and not ex._channel_closing
    assert eng.close_retry is None


def test_unknown_placeholder_cannot_close_other_bot_or_manual_order(tmp_path):
    eng, ex, client, clk = opened(tmp_path, CASES[0])
    calls = []
    client.close_order = lambda **kwargs: calls.append(kwargs)
    result = run(ex.close('XAUUSD', order_ids=['p1234567']))
    assert result['action'] == 'unconfirmed' and not calls
    assert 41 in client.open_orders


def test_manual_explicit_order_is_refused(tmp_path):
    eng, ex, client, clk = opened(tmp_path, CASES[0])
    client.open_orders[99] = {**client.open_orders[41], 'id': 99}
    result = run(ex.close('XAUUSD', order_id=99))
    assert result['action'] == 'refused' and 99 in client.open_orders


@pytest.mark.parametrize('closed', [False, True])
def test_broker_order_update_ack_is_not_full_closure(monkeypatch, closed):
    client = TrendoClient(SimpleNamespace(fxtrendo={}))
    client.open_orders[41] = {'id': 41, 'size': .02, 'symbol': 'xauusd', 'token': 'test'}
    monkeypatch.setattr(client, '_ensure_socket', lambda: None)
    monkeypatch.setattr(client, '_emit_user', lambda p: None)
    def ack(rec, seconds):
        rec['result'] = {'closed': closed}
        return 'confirmed'
    monkeypatch.setattr(client, '_wait_ack', ack)
    result = client.close_order(order_id=41)
    assert result['results'][0]['action'] == ('closed' if closed else 'unconfirmed')


@pytest.mark.parametrize('virtual', [False, True])
def test_known_exit_proceeds_while_unknown_leg_keeps_retrying(tmp_path, virtual):
    eng, ex, client, clk = opened(tmp_path, CASES[0])
    ids = [41, 'p1234567']
    if virtual:
        ex._vfired[1] = list(ids)
        ids = ['v1']
    st = eng.setup
    st.ids = ids
    calls = []
    def close(**kwargs):
        calls.append(kwargs['order_id'])
        client.open_orders.pop(41)
        return {'action': 'closed', 'order_id': 41}
    client.close_order = close
    run(eng._close_ids(ids, [st], clk.t))
    assert calls == [41]
    assert st in eng.live and not st.closed
    assert eng.close_retry['ids'] == (['v1'] if virtual else ['p1234567'])


def test_expired_guard_marker_does_not_suppress_channel_exit(tmp_path):
    import time
    eng, ex, client, clk = opened(tmp_path, CASES[0])
    ex._be_closed_at[41] = time.time() - 121
    calls = []
    def close(**kwargs):
        calls.append(kwargs['order_id'])
        client.open_orders.pop(41)
        return {'action': 'closed'}
    client.close_order = close
    run(ex.close('XAUUSD', order_ids=[41]))
    assert calls == [41] and 41 not in ex._be_closed_at


def test_guard_rearms_after_partial_broker_ack(tmp_path, monkeypatch):
    eng, ex, client, clk = opened(tmp_path, CASES[0], virtual=True)
    client.quote = CASES[0][2]
    run(eng.handle('فریش کن', msg_id=2, ts=clk.t))
    broker = TrendoClient(SimpleNamespace(fxtrendo={}))
    broker.open_orders = client.open_orders
    broker.open_orders[41].update(size=.02, token='test')
    monkeypatch.setattr(broker, '_ensure_socket', lambda: None)
    monkeypatch.setattr(broker, '_emit_user', lambda p: None)
    def partial(rec, seconds):
        broker.open_orders[41]['size'] = .01
        rec['result'] = {'closed': False}
        return 'confirmed'
    monkeypatch.setattr(broker, '_wait_ack', partial)
    client.close_order = broker.close_order
    client.tick(ex, CASES[0][4])
    assert 41 in client.open_orders and client.open_orders[41]['size'] == .01
    assert 41 in ex.guards() and 41 not in ex._be_closed_at
    assert not ex._be_closing
