"""Conservative durable delivery ledger: record before any order can be sent.

After an unexpected process crash an uncertain message is NOT replayed; the
broker book must be reconciled. A callback cancelled before execution is kept
as seen, preferring a missed entry over duplicating an already emitted order.
"""
import json
from signal_trader.fastpoll import Seen

class DurableSeen(Seen):
    def __init__(self, path):
        super().__init__()
        self.path = path
        if path.exists():
            for key, mid, text in json.loads(path.read_text(encoding='utf8')):
                super().first(key, mid, text)

    def first(self, key, msg_id, text):
        if not super().first(key, msg_id, text):
            return False
        rows = [[k, mid, self._text.get((k, mid), '')] for k, mid in self._new]
        tmp = self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps(rows, ensure_ascii=False), encoding='utf8')
        tmp.replace(self.path)
        return True

    def forget(self, key, msg_id):
        pass  # An interrupted process must not replay an uncertain order.
