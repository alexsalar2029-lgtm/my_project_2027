import asyncio
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace
import pytest
sys.path[:0] = [str(Path(__file__).parent), str(Path(__file__).parent.parent / 'engine')]
import mobile_bridge
from mobile_bridge import Runtime
from mobile_seen import DurableSeen
from mobile_executor import MobileExecutor

@pytest.fixture
def runtime(tmp_path):
    r = Runtime()
    yield r
    r.call(r.stop())
    r.loop.call_soon_threadsafe(r.loop.stop)
    r.thread.join(2)
    r.loop.close()

@pytest.fixture
def config(tmp_path):
    return dict(storage_dir=str(tmp_path), api_id=123, api_hash='hash-secret', phone='+1000000',
                broker_username='test-user', broker_password='secret-pass', risk_pct=2, max_daily_loss=8,
                execution_mode='automatic', confirm_automatic_trading=True, wallet_id='12')

def test_invalid_boolean_risk_and_private_path(runtime, config):
    for patch in ({'real_wallet':'false'}, {'risk_pct':float('nan')}, {'storage_dir':'relative'}):
        with pytest.raises(ValueError):
            runtime.configure(json.dumps({**config, **patch}))

def test_real_requires_explicit_confirmation(runtime, config):
    result = runtime.call(runtime.start(json.dumps({**config, 'real_wallet':True})))
    assert result['error'] == 'real_trading_not_confirmed'
    assert runtime.broker is None

def test_preview_never_places_order():
    r = json.loads(mobile_bridge.preview('Xau Buy Enter:4184/4185 SL:4181'))
    assert r['side'] == 'BUY' and r['stop_loss'] == 4181
    assert 'سفارشی ارسال نشده' in r['reason']

def test_startup_and_stopped_messages_rejected(runtime):
    runtime.active = True
    runtime.started_at = 1000
    assert not runtime.accept_new(999)
    assert not runtime.accept_new(None)
    assert runtime.accept_new(1001)
    runtime.active = False
    assert not runtime.accept_new(1001)

def test_durable_message_cannot_repeat_after_restart(tmp_path):
    path = tmp_path / 'seen.json'
    one = DurableSeen(path)
    assert one.first('lordxau', 123, 'signal')
    assert not one.first('lordxau', 123, 'signal')
    two = DurableSeen(path)
    assert not two.first('lordxau', 123, 'changed')
    assert two.first('lordxau', 124, 'new')

def test_journal_redacts_secrets(runtime, config):
    runtime.configure(json.dumps(config))
    runtime.log('error secret-pass hash-secret test-user +1000000')
    assert 'secret-pass' not in str(runtime.events)
    assert 'hash-secret' not in str(runtime.events)

def test_unknown_profit_is_not_zero(runtime, config):
    runtime.configure(json.dumps(config))
    runtime.broker = SimpleNamespace(my_order_ids={41}, wallet={'id':'demo'}, disconnect=lambda: None)
    runtime.order_event({'id':41, 'close_time_current':1, 'profit':None, 'type':0})
    assert runtime.closed['demo:41']['profit'] is None
    assert json.loads((runtime.root / 'closed.json').read_text())['demo:41']['profit'] is None

def test_close_unknown_manual_order_refused(runtime):
    runtime.config['execution_mode'] = 'automatic'
    runtime.active = True
    runtime.engine = SimpleNamespace()
    runtime.broker = SimpleNamespace(my_order_ids={41}, disconnect=lambda: None)
    assert runtime.call(runtime.close_signal('42'))['error'] == 'not_bot_order'

def test_real_engine_constructor_and_stop_start(monkeypatch, runtime, config):
    import android_trendo
    import mobile_executor
    import signal_trader.fastpoll
    class TG:
        async def is_user_authorized(self): return True
        async def get_entity(self, channel): return 'lordxau'
        async def disconnect(self): pass
        def add_event_handler(self, *a): pass
        def remove_event_handler(self, *a): pass
        def is_connected(self): return True
    tg = TG()
    async def telegram():
        runtime.tg = tg
        return tg
    runtime.telegram = telegram
    class Broker:
        def __init__(self, cfg):
            self.wallet = {'id':12,'currency':'USD'}
            self.user_id=1
            self.use_real=False
            self.my_order_ids=set()
        def login(self): pass
        def connect(self): pass
        def disconnect(self): pass
        def subscribe_prices(self, *args): pass
        def is_alive(self): return True
    class Ex:
        def __init__(self, cfg, broker): self.live=True
        def remember_orders(self, path): self.path=path
        def retire(self, why): pass
        def stop_watchdog(self): pass
    async def poll(self, stop):
        while not stop(): await asyncio.sleep(.01)
    monkeypatch.setattr(android_trendo, 'AndroidTrendoClient', Broker)
    monkeypatch.setattr(mobile_executor, 'MobileExecutor', Ex)
    monkeypatch.setattr(signal_trader.fastpoll.ChannelPoller, 'run', poll)
    result = runtime.call(runtime.start(json.dumps(config)))
    assert result.get('ok'), result
    assert runtime.status()['connected']
    assert runtime.engine.on_event == runtime.decision
    assert runtime.call(runtime.start(json.dumps(config)))['error']=='already_started'
    result=runtime.call(runtime.stop())
    assert result['ok'] and not runtime.status()['connected']
    assert runtime.call(runtime.start(json.dumps(config)))['ok']

def test_mobile_sizing_rejects_min_lot_exceeding_budget(monkeypatch):
    from signal_trader.executors.fxtrendo import FxTrendoExecutor
    monkeypatch.setattr(FxTrendoExecutor, '_plan', lambda *a: ([(.01,4190)], 'minimum lot'))
    executor = object.__new__(MobileExecutor)
    executor.risk = SimpleNamespace(contracts={'XAUUSD':100}, risk_pct=2)
    executor._balance = lambda: 100
    sig = SimpleNamespace(symbol='XAUUSD', entries=[4185], stop_loss=4182)
    plan, reason = executor._plan(sig, 4185)
    assert not plan and 'بودجه' in reason

def test_closed_history_preserves_unknown_profit(runtime, config):
    runtime.configure(json.dumps(config))
    runtime.closed = {'demo:41': {'id':'41','wallet':'demo','profit':None}}
    rows = runtime.signals()['items']
    assert rows[0]['status']=='closed' and rows[0]['pnl'] is None

def test_month_media_never_claims_full_analysis(runtime, config):
    import datetime as dt
    runtime.configure(json.dumps(config))
    now = dt.datetime.now(dt.timezone.utc)
    class TG:
        async def is_user_authorized(self): return True
        async def disconnect(self): pass
        async def iter_messages(self, *a, **k):
            yield SimpleNamespace(id=1,date=now,edit_date=None,media=True,message='Xau Buy Enter:4184/4185 SL:4181')
    tg = TG()
    async def telegram(): return tg
    runtime.telegram = telegram
    result = runtime.call(runtime.audit_month())
    assert result['ok'] and result['accessible_messages_fetched']
    assert result['coverage_complete'] is False
    assert result['net_pnl'] is None and result['media_count']==1
    runtime.month = {}
    runtime.configure(json.dumps(config))
    assert runtime.month['message_count']==1


def test_rejected_close_is_requested_not_success(runtime):
    runtime.config['execution_mode'] = 'automatic'
    from contextlib import asynccontextmanager
    class Engine:
        @asynccontextmanager
        async def _get_lock(self): yield
        async def _close_ids(self, *a): return ['بستن تأیید نشد']
    runtime.active=True
    runtime.engine=Engine()
    runtime.broker=SimpleNamespace(my_order_ids={41}, disconnect=lambda:None)
    result=runtime.call(runtime.close_signal(41))
    assert result['status']=='close_requested'
    assert 'closed' not in result


def test_automatic_requires_explicit_start_confirmation(runtime, config):
    result = runtime.call(runtime.start(json.dumps({**config, 'confirm_automatic_trading': False})))
    assert result['error'] == 'automatic_trading_not_confirmed'
    assert runtime.broker is None


def test_default_manual_starts_without_broker_and_never_executes(monkeypatch, runtime, config):
    import android_trendo
    import signal_trader.fastpoll
    manual = {k:v for k,v in config.items() if k not in ('execution_mode', 'confirm_automatic_trading', 'broker_username', 'broker_password')}
    class TG:
        def is_connected(self): return True
        async def is_user_authorized(self): return True
        async def get_entity(self, channel): return channel
        async def disconnect(self): pass
        def add_event_handler(self, *args): pass
        def remove_event_handler(self, *args): pass
    tg = TG()
    async def telegram(): runtime.tg = tg; return tg
    runtime.telegram = telegram
    def forbidden(*args, **kwargs): raise AssertionError('manual mode constructed broker')
    async def poll(self, stop):
        while not stop(): await asyncio.sleep(.01)
    monkeypatch.setattr(android_trendo, 'AndroidTrendoClient', forbidden)
    monkeypatch.setattr(signal_trader.fastpoll.ChannelPoller, 'run', poll)
    result = runtime.call(runtime.start(json.dumps(manual)))
    assert result['ok'] and result['mode'] == 'manual'
    assert runtime.status()['connected']
    now = time.time() + 1
    runtime.manual_message(123, now, 'Xau Buy Enter:4184/4185 SL:4181')
    runtime.manual_message(124, now, 'ببندش')
    rows = runtime.signals()['items']
    assert len(rows) == 2
    assert rows[0]['status'] == 'manual_review'
    assert rows[0]['opened_at'] is None
    assert runtime.broker is runtime.executor is runtime.engine is None
    assert runtime.call(runtime.close_signal('123'))['error'] == 'manual_mode_no_orders'


def test_manual_updates_same_message_and_ignores_old_unknown_edit(runtime):
    runtime.active = True
    runtime.started_at = 100
    runtime.manual_message(1, 99, 'Xau Buy Enter:4184/4185 SL:4181')
    assert not runtime.manual_messages
    runtime.manual_message(1, 101, 'Xau Buy Enter:4184/4185 SL:4181')
    runtime.manual_message(1, 101, 'Xau Buy Enter:4184/4185 SL:4182', edited=True)
    runtime.manual_message(2, 90, 'Xau Buy Enter:4184/4185 SL:4181', edited=True)
    rows = runtime.signals()['items']
    assert len(rows) == 1 and rows[0]['stop_loss'] == 4182


@pytest.mark.parametrize("real", [False, True])
def test_android_wallet_selection_is_exact(real):
    from android_trendo import AndroidTrendoClient
    client = object.__new__(AndroidTrendoClient)
    client.use_real = real
    client.wallet_id_cfg = None
    client.wallets = [dict(id=1, is_real=False, currency='USD'),
                      dict(id=2, is_real=True, currency='USD')]
    assert client._choose_wallet()['id'] == (2 if real else 1)
    client.wallet_id_cfg = 1 if real else 2
    with pytest.raises(ValueError): client._choose_wallet()
    client.wallet_id_cfg = None
    client.wallets.append(dict(id=3, is_real=real, currency='USD'))
    with pytest.raises(ValueError): client._choose_wallet()
    client.wallet_id_cfg = 3
    assert client._choose_wallet()['id'] == 3

@pytest.mark.parametrize("metadata", [None, 'false', 'true', 2])
def test_android_wallet_rejects_ambiguous_kind(metadata):
    from android_trendo import AndroidTrendoClient
    client = object.__new__(AndroidTrendoClient)
    client.use_real = False
    client.wallet_id_cfg = None
    client.wallets = [dict(id=1, is_real=metadata, currency='USD')]
    with pytest.raises(ValueError): client._choose_wallet()


def test_partial_legacy_config_status_never_echoes_error(runtime, tmp_path):
    runtime.configure(json.dumps({'storage_dir': str(tmp_path)}))
    result = runtime.call(runtime.audit_month())
    assert result['error'] == 'telegram_settings_missing'
    assert 'API ID' in result['notice']
    status = runtime.status()
    assert status['ok'] and 'error' not in status
    assert status['last_error']['code'] == 'telegram_settings_missing'
    assert not status['running']


def test_verify_before_request_is_actionable(runtime):
    result = runtime.call(runtime.verify_code('12345'))
    assert result['error'] == 'code_request_required'
    assert 'KeyError' not in str(result)


def test_invalid_configuration_is_atomic(runtime, config):
    runtime.configure(json.dumps(config))
    before = dict(runtime.config)
    with pytest.raises(ValueError):
        runtime.configure(json.dumps({**config, 'real_wallet': 'true', 'phone': 'other'}))
    assert runtime.config == before


def test_bad_report_file_does_not_break_connection_setup(runtime, config):
    Path(config['storage_dir'], 'closed.json').write_text('{broken')
    runtime.configure(json.dumps(config))
    assert runtime.config['phone'] == config['phone']
    assert runtime.status()['ok']


def test_wallet_discovery_does_not_need_telegram_or_open_socket(monkeypatch, runtime, tmp_path):
    import android_trendo
    class ReadOnlyBroker:
        def __init__(self, cfg): pass
        def login(self, select_wallet=True):
            assert select_wallet is False
            assert self.username == 'email'
        def available_wallets(self): return [{'id': 'demo-example', 'kind': 'demo', 'currency': 'EUR', 'supported': True}]
        def connect(self): raise AssertionError('discovery opened trading socket')
    monkeypatch.setattr(android_trendo, 'AndroidTrendoClient', ReadOnlyBroker)
    result = runtime.call(runtime.list_wallets(json.dumps(dict(storage_dir=str(tmp_path), broker_username='email', broker_password='pass'))))
    assert result['ok'] and result['wallets'][0]['currency'] == 'EUR'
    assert runtime.broker is runtime.engine is runtime.executor is None
    assert not runtime.active


def test_channel_history_is_visible_but_never_routed(monkeypatch, runtime, config):
    import datetime as dt
    class TG:
        async def is_user_authorized(self): return True
        def is_connected(self): return True
        async def get_entity(self, channel): return channel
        async def disconnect(self): pass
        async def iter_messages(self, entity, limit):
            yield SimpleNamespace(id=80, date=dt.datetime.now(dt.timezone.utc), message='Xau Buy Enter:3908 SL:3906')
    tg = TG()
    async def telegram(): runtime.tg = tg; return tg
    runtime.telegram = telegram
    result = runtime.call(runtime.check_telegram(json.dumps(config)))
    assert result['ok'] and result['count'] == 1
    row = runtime.signals()['messages'][0]
    assert row['history_only'] and row['id'] == 80
    assert not runtime.active and runtime.engine is runtime.executor is runtime.broker is None
    assert runtime.status()['telegram_authorized']
    assert not runtime.status()['connected']


@pytest.mark.parametrize('real', [True, False])
def test_eur_wallet_is_selectable_and_id_is_exact(real):
    from android_trendo import AndroidTrendoClient
    client = object.__new__(AndroidTrendoClient)
    client.use_real = real
    client.wallet_id_cfg = 'eur-example'
    client.wallets = [dict(id='eur-example', is_real=real, currency='EUR', balance=100),
                      dict(id='usd-example', is_real=real, currency='USD', balance=100)]
    assert client._choose_wallet()['id'] == 'eur-example'
    client.wallet_id_cfg = 'missing'
    with pytest.raises(ValueError): client._choose_wallet()
    assert all('token' not in row for row in client.available_wallets())


def _eur_executor(monkeypatch, quote=(1.10, 1.11), age=1):
    from signal_trader.executors.fxtrendo import FxTrendoExecutor
    from signal_trader.risk import RiskConfig
    e = object.__new__(MobileExecutor)
    e.client = SimpleNamespace(wallet={'currency': 'EUR'}, price=lambda s: quote,
                               price_age=lambda s: age, broker_symbol=lambda s: s)
    e.risk = RiskConfig(sizing='risk_pct', risk_pct=2)
    e._balance = lambda: 100
    e.default_lot = .01
    e._channel_multiplier = lambda source: 1
    e._tp_points = lambda source: 0
    return e


def test_eur_risk_uses_conversion_and_does_not_mutate_balance_or_contracts(monkeypatch):
    from signal_trader.models import Signal, Side, OrderType
    e = _eur_executor(monkeypatch)
    sig = Signal(symbol='XAUUSD', side=Side.BUY, order_type=OrderType.MARKET, entries=[3908], stop_loss=3906)
    plan, note = e._plan(sig, 3908)
    assert plan and plan[0][0] == .01
    assert e._balance() == 100 and e.risk.contracts['XAUUSD'] == 100
    # EUR budget is 2 EUR. A USD loss of 2 converts to <=2 EUR here.
    e.client.price = lambda s: (.8, .81)
    assert not e._plan(sig, 3908)[0]  # .01 lot would now exceed 2 EUR budget


@pytest.mark.parametrize('quote,age', [(None,1), ((1.1,1.11),16), ((1.1,1.11),None),
                                      ((float('nan'),1.11),1), ((1.2,1.1),1), ((1.1,1.11),-1)])
def test_missing_or_stale_conversion_never_uses_one_to_one(monkeypatch, quote, age):
    e = _eur_executor(monkeypatch, quote, age)
    sig = SimpleNamespace(symbol='XAUUSD', entries=[3908], stop_loss=3906)
    plan, reason = e._plan(sig,3908)
    assert not plan and 'EURUSD' in reason


def test_password_only_verification_is_supported(runtime, config):
    runtime.configure(json.dumps(config))
    class TG:
        async def sign_in(self, **kwargs): assert kwargs == {'password':'private-password'}
        async def is_user_authorized(self): return True
        async def disconnect(self): pass
    tg = TG()
    async def telegram(): return tg
    runtime.tg = tg
    runtime.telegram = telegram
    result = runtime.call(runtime.verify_code('', 'private-password'))
    assert result['authorized']


def test_automatic_requires_selected_wallet_before_any_network(runtime, config):
    result = runtime.call(runtime.start(json.dumps({**config, 'wallet_id': ''})))
    assert result['error'] == 'wallet_selection_required'
    assert runtime.tg is runtime.broker is None


def test_bonus_metadata_is_not_labeled_demo():
    from android_trendo import AndroidTrendoClient
    for patch in ({'is_bonus': True}, {'type': 'bonus'}, {'type': 'wallet'}):
        w = AndroidTrendoClient.wallet_info(dict(id='example', currency='USD', is_real=False, **patch))
        assert w['kind'] == 'unknown' and not w['supported']
