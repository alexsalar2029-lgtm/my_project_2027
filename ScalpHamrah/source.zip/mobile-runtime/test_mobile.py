import asyncio
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace
import pytest
sys.path[:0] = [str(Path(__file__).parent), str(Path(__file__).parent.parent / 'engine')]
import mobile_bridge
from mobile_bridge import Runtime
from mobile_seen import DurableSeen
from mobile_executor import MobileExecutor

@pytest.fixture
def runtime(tmp_path):
    r = Runtime()
    yield r
    r.call(r.stop())
    r.loop.call_soon_threadsafe(r.loop.stop)
    r.thread.join(2)
    r.loop.close()

@pytest.fixture
def config(tmp_path):
    return dict(storage_dir=str(tmp_path), api_id=123, api_hash='hash-secret', phone='+1000000',
                broker_username='test-user', broker_password='secret-pass', risk_pct=2, max_daily_loss=8,
                execution_mode='automatic', confirm_automatic_trading=True)

def test_invalid_boolean_risk_and_private_path(runtime, config):
    for patch in ({'real_wallet':'false'}, {'risk_pct':float('nan')}, {'storage_dir':'relative'}):
        with pytest.raises(ValueError):
            runtime.configure(json.dumps({**config, **patch}))

def test_real_requires_explicit_confirmation(runtime, config):
    result = runtime.call(runtime.start(json.dumps({**config, 'real_wallet':True})))
    assert result['error'] == 'real_trading_not_confirmed'
    assert runtime.broker is None

def test_preview_never_places_order():
    r = json.loads(mobile_bridge.preview('Xau Buy Enter:4184/4185 SL:4181'))
    assert r['side'] == 'BUY' and r['stop_loss'] == 4181
    assert 'سفارشی ارسال نشده' in r['reason']

def test_startup_and_stopped_messages_rejected(runtime):
    runtime.active = True
    runtime.started_at = 1000
    assert not runtime.accept_new(999)
    assert not runtime.accept_new(None)
    assert runtime.accept_new(1001)
    runtime.active = False
    assert not runtime.accept_new(1001)

def test_durable_message_cannot_repeat_after_restart(tmp_path):
    path = tmp_path / 'seen.json'
    one = DurableSeen(path)
    assert one.first('lordxau', 123, 'signal')
    assert not one.first('lordxau', 123, 'signal')
    two = DurableSeen(path)
    assert not two.first('lordxau', 123, 'changed')
    assert two.first('lordxau', 124, 'new')

def test_journal_redacts_secrets(runtime, config):
    runtime.configure(json.dumps(config))
    runtime.log('error secret-pass hash-secret test-user +1000000')
    assert 'secret-pass' not in str(runtime.events)
    assert 'hash-secret' not in str(runtime.events)

def test_unknown_profit_is_not_zero(runtime, config):
    runtime.configure(json.dumps(config))
    runtime.broker = SimpleNamespace(my_order_ids={41}, wallet={'id':'demo'}, disconnect=lambda: None)
    runtime.order_event({'id':41, 'close_time_current':1, 'profit':None, 'type':0})
    assert runtime.closed['demo:41']['profit'] is None
    assert json.loads((runtime.root / 'closed.json').read_text())['demo:41']['profit'] is None

def test_close_unknown_manual_order_refused(runtime):
    runtime.config['execution_mode'] = 'automatic'
    runtime.active = True
    runtime.engine = SimpleNamespace()
    runtime.broker = SimpleNamespace(my_order_ids={41}, disconnect=lambda: None)
    assert runtime.call(runtime.close_signal('42'))['error'] == 'not_bot_order'

def test_real_engine_constructor_and_stop_start(monkeypatch, runtime, config):
    import android_trendo
    import mobile_executor
    import signal_trader.fastpoll
    class TG:
        async def is_user_authorized(self): return True
        async def get_entity(self, channel): return 'lordxau'
        async def disconnect(self): pass
        def add_event_handler(self, *a): pass
        def remove_event_handler(self, *a): pass
        def is_connected(self): return True
    tg = TG()
    async def telegram():
        runtime.tg = tg
        return tg
    runtime.telegram = telegram
    class Broker:
        def __init__(self, cfg):
            self.wallet = {'id':12,'currency':'USD'}
            self.user_id=1
            self.use_real=False
            self.my_order_ids=set()
        def login(self): pass
        def connect(self): pass
        def disconnect(self): pass
        def subscribe_prices(self, *args): pass
        def is_alive(self): return True
    class Ex:
        def __init__(self, cfg, broker): self.live=True
        def remember_orders(self, path): self.path=path
        def retire(self, why): pass
        def stop_watchdog(self): pass
    async def poll(self, stop):
        while not stop(): await asyncio.sleep(.01)
    monkeypatch.setattr(android_trendo, 'AndroidTrendoClient', Broker)
    monkeypatch.setattr(mobile_executor, 'MobileExecutor', Ex)
    monkeypatch.setattr(signal_trader.fastpoll.ChannelPoller, 'run', poll)
    result = runtime.call(runtime.start(json.dumps(config)))
    assert result.get('ok'), result
    assert runtime.status()['connected']
    assert runtime.engine.on_event == runtime.decision
    assert runtime.call(runtime.start(json.dumps(config)))['error']=='already_started'
    result=runtime.call(runtime.stop())
    assert result['ok'] and not runtime.status()['connected']
    assert runtime.call(runtime.start(json.dumps(config)))['ok']

def test_mobile_sizing_rejects_min_lot_exceeding_budget(monkeypatch):
    from signal_trader.executors.fxtrendo import FxTrendoExecutor
    monkeypatch.setattr(FxTrendoExecutor, '_plan', lambda *a: ([(.01,4190)], 'minimum lot'))
    executor = object.__new__(MobileExecutor)
    executor.risk = SimpleNamespace(contracts={'XAUUSD':100}, risk_pct=2)
    executor._balance = lambda: 100
    sig = SimpleNamespace(symbol='XAUUSD', entries=[4185], stop_loss=4182)
    plan, reason = executor._plan(sig, 4185)
    assert not plan and 'بودجه' in reason

def test_closed_history_preserves_unknown_profit(runtime, config):
    runtime.configure(json.dumps(config))
    runtime.closed = {'demo:41': {'id':'41','wallet':'demo','profit':None}}
    rows = runtime.signals()['items']
    assert rows[0]['status']=='closed' and rows[0]['pnl'] is None

def test_month_media_never_claims_full_analysis(runtime, config):
    import datetime as dt
    runtime.configure(json.dumps(config))
    now = dt.datetime.now(dt.timezone.utc)
    class TG:
        async def is_user_authorized(self): return True
        async def disconnect(self): pass
        async def iter_messages(self, *a, **k):
            yield SimpleNamespace(id=1,date=now,edit_date=None,media=True,message='Xau Buy Enter:4184/4185 SL:4181')
    tg = TG()
    async def telegram(): return tg
    runtime.telegram = telegram
    result = runtime.call(runtime.audit_month())
    assert result['ok'] and result['accessible_messages_fetched']
    assert result['coverage_complete'] is False
    assert result['net_pnl'] is None and result['media_count']==1
    runtime.month = {}
    runtime.configure(json.dumps(config))
    assert runtime.month['message_count']==1


def test_rejected_close_is_requested_not_success(runtime):
    runtime.config['execution_mode'] = 'automatic'
    from contextlib import asynccontextmanager
    class Engine:
        @asynccontextmanager
        async def _get_lock(self): yield
        async def _close_ids(self, *a): return ['بستن تأیید نشد']
    runtime.active=True
    runtime.engine=Engine()
    runtime.broker=SimpleNamespace(my_order_ids={41}, disconnect=lambda:None)
    result=runtime.call(runtime.close_signal(41))
    assert result['status']=='close_requested'
    assert 'closed' not in result


def test_automatic_requires_explicit_start_confirmation(runtime, config):
    result = runtime.call(runtime.start(json.dumps({**config, 'confirm_automatic_trading': False})))
    assert result['error'] == 'automatic_trading_not_confirmed'
    assert runtime.broker is None


def test_default_manual_starts_without_broker_and_never_executes(monkeypatch, runtime, config):
    import android_trendo
    import signal_trader.fastpoll
    manual = {k:v for k,v in config.items() if k not in ('execution_mode', 'confirm_automatic_trading', 'broker_username', 'broker_password')}
    class TG:
        def is_connected(self): return True
        async def is_user_authorized(self): return True
        async def get_entity(self, channel): return channel
        async def disconnect(self): pass
        def add_event_handler(self, *args): pass
        def remove_event_handler(self, *args): pass
    tg = TG()
    async def telegram(): runtime.tg = tg; return tg
    runtime.telegram = telegram
    def forbidden(*args, **kwargs): raise AssertionError('manual mode constructed broker')
    async def poll(self, stop):
        while not stop(): await asyncio.sleep(.01)
    monkeypatch.setattr(android_trendo, 'AndroidTrendoClient', forbidden)
    monkeypatch.setattr(signal_trader.fastpoll.ChannelPoller, 'run', poll)
    result = runtime.call(runtime.start(json.dumps(manual)))
    assert result['ok'] and result['mode'] == 'manual'
    assert runtime.status()['connected']
    now = time.time() + 1
    runtime.manual_message(123, now, 'Xau Buy Enter:4184/4185 SL:4181')
    runtime.manual_message(124, now, 'ببندش')
    rows = runtime.signals()['items']
    assert len(rows) == 2
    assert rows[0]['status'] == 'manual_review'
    assert rows[0]['opened_at'] is None
    assert runtime.broker is runtime.executor is runtime.engine is None
    assert runtime.call(runtime.close_signal('123'))['error'] == 'manual_mode_no_orders'


def test_manual_updates_same_message_and_ignores_old_unknown_edit(runtime):
    runtime.active = True
    runtime.started_at = 100
    runtime.manual_message(1, 99, 'Xau Buy Enter:4184/4185 SL:4181')
    assert not runtime.manual_messages
    runtime.manual_message(1, 101, 'Xau Buy Enter:4184/4185 SL:4181')
    runtime.manual_message(1, 101, 'Xau Buy Enter:4184/4185 SL:4182', edited=True)
    runtime.manual_message(2, 90, 'Xau Buy Enter:4184/4185 SL:4181', edited=True)
    rows = runtime.signals()['items']
    assert len(rows) == 1 and rows[0]['stop_loss'] == 4182
