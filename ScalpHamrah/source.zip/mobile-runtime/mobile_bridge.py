"""Android on-device runtime. No server, no automatic startup or example fills.

Public functions return JSON strings. Network coroutines stay on one event loop;
Kotlin must invoke blocking bridge methods on Dispatchers.IO, never the UI thread.
"""
from __future__ import annotations
import asyncio
import copy
import datetime as dt
import json
import math
import hashlib
import threading
import time
from collections import Counter, deque
from pathlib import Path

from lordxau import CHANNEL, SYMBOL, __version__
from lordxau.parse import parse


def dumps(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, default=str)


class Runtime:
    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self.loop.run_forever, name='mobile-runtime', daemon=True)
        self.thread.start()
        self.lock = threading.RLock()
        self.config = {}
        self.root = None
        self.tg = None
        self.phone_hash = None
        self.broker = self.executor = self.engine = self.router = None
        self.tasks = []
        self.handlers = []
        self.active = False
        self.state = 'stopped'
        self.error = None
        self.decisions = deque(maxlen=500)
        self.closed = {}
        self.month = {'coverage_complete': False, 'message_count': 0, 'net_pnl': None,
                      'wins': 0, 'losses': 0, 'unknown': 0,
                      'notice': 'پیام‌های یک ماه اخیر هنوز دریافت نشده‌اند.'}
        self.events = deque(maxlen=100)
        self._command_lock = asyncio.Lock()
        self.started_at = 0.0
        self.explanations = {}
        self.seen = None
        self.manual_messages = {}

    def call(self, coro, timeout=90):
        future = asyncio.run_coroutine_threadsafe(coro, self.loop)
        try:
            return future.result(timeout)
        except TimeoutError:
            future.cancel()
            return {'ok': False, 'error': 'timeout', 'notice': 'پاسخ کامل نرسید؛ وضعیت اتصال را بررسی کنید.'}
        except Exception as exc:
            self.error = type(exc).__name__
            return {'ok': False, 'error': type(exc).__name__, 'notice': 'عملیات تأیید نشد؛ تنظیمات و اتصال را بررسی کنید.'}

    def configure(self, raw):
        config = json.loads(raw)
        if not isinstance(config, dict):
            raise ValueError('object required')
        mode = config.setdefault('execution_mode', 'manual')
        if mode not in ('manual', 'automatic'):
            raise ValueError('execution_mode_invalid')
        root = Path(config['storage_dir'])
        if not root.is_absolute():
            raise ValueError('private absolute storage_dir required')
        if self.active or self.state == 'starting':
            raise ValueError('stop before configuration changes')
        api_id = int(config['api_id'])
        if api_id <= 0 or not config.get('api_hash') or not config.get('phone'):
            raise ValueError('Telegram configuration incomplete')
        for key, default, low, high in [('risk_pct', 2, 0.01, 5), ('max_daily_loss', 8, 0.01, 100000)]:
            value = float(config.get(key, default))
            if not math.isfinite(value) or not low <= value <= high:
                raise ValueError(key)
        root.mkdir(parents=True, exist_ok=True)
        self.root, self.config = root, config
        for name in ('real_wallet', 'confirm_real_trading', 'confirm_automatic_trading'):
            if name in config and not isinstance(config[name], bool):
                raise ValueError(name + '_must_be_boolean')
        (root / 'logs').mkdir(exist_ok=True)
        path = root / 'closed.json'
        if path.exists():
            self.closed = json.loads(path.read_text())
        for name, attr in [('month_report.json', 'month'), ('explanations.json', 'explanations')]:
            path = root / name
            if path.exists():
                setattr(self, attr, json.loads(path.read_text(encoding='utf8')))
        return config

    async def telegram(self):
        from telethon import TelegramClient
        if self.tg is None:
            account = str(self.config['api_id']) + ':' + self.config['phone']
            session = 'telegram_' + hashlib.sha256(account.encode()).hexdigest()[:24]
            self.tg = TelegramClient(str(self.root / session), int(self.config['api_id']), self.config['api_hash'])
        if not self.tg.is_connected():
            await self.tg.connect()
        return self.tg

    async def request_code(self, raw):
        async with self._command_lock:
            return await self._request_code(raw)

    async def _request_code(self, raw):
        if self.tg is not None:
            if self.active:
                return {'ok': False, 'error': 'stop_first'}
            await self.tg.disconnect()
            self.tg = None
        self.configure(raw)
        self.phone_hash = None
        tg = await self.telegram()
        if await tg.is_user_authorized():
            return {'ok': True, 'authorized': True}
        sent = await tg.send_code_request(self.config['phone'])
        self.phone_hash = sent.phone_code_hash
        return {'ok': True, 'authorized': False, 'code_sent': True}

    async def verify_code(self, code, password=''):
        from telethon.errors import SessionPasswordNeededError
        tg = await self.telegram()
        try:
            if password:
                await tg.sign_in(password=password)
            else:
                await tg.sign_in(self.config['phone'], code=str(code), phone_code_hash=self.phone_hash)
        except SessionPasswordNeededError:
            return {'ok': False, 'password_required': True}
        return {'ok': True, 'authorized': bool(await tg.is_user_authorized())}

    def redact(self, line):
        text = str(line)
        for key in ('api_hash', 'broker_password', 'broker_username', 'phone'):
            value = self.config.get(key)
            if value:
                text = text.replace(str(value), '[private]')
        token = getattr(self.broker, 'user_token', None)
        if token:
            text = text.replace(str(token), '[private]')
        return text

    def log(self, line):
        # Engine messages may include broker IDs but never config, token or password.
        with self.lock:
            self.events.append({'t': time.time(), 'text': self.redact(line)})

    def decision(self, event):
        row = copy.deepcopy(event)
        row['lines'] = [self.redact(line) for line in row.get('lines', [])]
        with self.lock:
            self.decisions.append(row)
        with (self.root / 'decisions.jsonl').open('a', encoding='utf8') as file:
            file.write(dumps(row) + '\n')

    def order_event(self, order):
        oid = order.get('id')
        if oid is None or self.broker is None or int(oid) not in self.broker.my_order_ids:
            return
        if order.get('close_time_current') in (None, 0, '0', ''):
            return
        profit = order.get('profit')
        try:
            profit = float(profit) if profit is not None else None
            if profit is not None and not math.isfinite(profit):
                profit = None
        except (ValueError, TypeError):
            profit = None
        wallet = str((self.broker.wallet or {}).get('id'))
        row = {'id': str(oid), 'wallet': wallet, 'profit': profit, 'closed_at': time.time(),
               'symbol': order.get('symbol'), 'entry': order.get('open'),
               'stop_loss': order.get('sl'), 'take_profit': order.get('tp'),
               'opened_at': order.get('open_time_current'), 'side': 'BUY' if str(order.get('type')) == '0' else 'SELL'}
        with self.lock:
            previous = self.closed.get(wallet + ':' + str(oid), {})
            if row['profit'] is None and previous.get('profit') is not None:
                row['profit'] = previous['profit']
            self.closed[wallet + ':' + str(oid)] = row
            tmp = self.root / 'closed.tmp'
            tmp.write_text(dumps(self.closed), encoding='utf8')
            tmp.replace(self.root / 'closed.json')

    async def start(self, raw):
        async with self._command_lock:
            return await self._start(raw)

    async def _start(self, raw):
        if self.active or self.state == 'starting':
            return {'ok': False, 'error': 'already_started'}
        # A previous broker is deliberately not silently reassigned to another account.
        if self.broker is not None:
            return {'ok': False, 'error': 'restart_app_to_change_or_restart_account',
                    'notice': 'برای شروع دوباره برنامه را بازگشایی کنید؛ ابتدا معاملات باز را بررسی کنید.'}
        if self.tg is not None:
            await self.tg.disconnect()
            self.tg = None
        self.configure(raw)
        automatic = self.config['execution_mode'] == 'automatic'
        if automatic and not self.config.get('confirm_automatic_trading'):
            return {'ok': False, 'error': 'automatic_trading_not_confirmed'}
        if automatic and (not self.config.get('broker_username') or not self.config.get('broker_password')):
            return {'ok': False, 'error': 'broker_credentials_missing'}
        if automatic and self.config.get('real_wallet') and not self.config.get('confirm_real_trading'):
            return {'ok': False, 'error': 'real_trading_not_confirmed'}
        self.state = 'starting'
        try:
            tg = await self.telegram()
            if not await tg.is_user_authorized():
                self.state = 'stopped'
                return {'ok': False, 'error': 'telegram_login_required'}
            entity = await tg.get_entity(CHANNEL)
            if not automatic:
                return await self._start_manual(tg, entity)
            from lordxau import settings
            from lordxau.engine import Engine
            from mobile_executor import MobileExecutor
            from signal_trader.fastpoll import MessageRouter, ChannelPoller
            from signal_trader.risk import DailyGuard
            from signal_trader import filelog
            from telethon import events
            from android_trendo import AndroidTrendoClient
            cfg = copy.deepcopy(settings.DEFAULTS)
            cfg['fxtrendo']['use_real_wallet'] = bool(self.config.get('real_wallet', False))
            cfg['fxtrendo']['wallet_id'] = self.config.get('wallet_id') or None
            cfg['fxtrendo']['allow_sl_widening'] = False
            cfg['risk']['risk_pct'] = float(self.config.get('risk_pct', 2))
            cfg['risk']['max_daily_loss'] = float(self.config.get('max_daily_loss', 8))
            bc = settings.broker_config(cfg)
            broker = AndroidTrendoClient(bc)
            broker.username = self.config['broker_username']
            broker.password = self.config['broker_password']
            await asyncio.to_thread(broker.login)
            self.broker = broker
            await asyncio.to_thread(broker.connect)
            if str((broker.wallet or {}).get('currency') or '').upper() != 'USD':
                raise ValueError('USD_wallet_required_for_gold_risk_sizing')
            requested_wallet = self.config.get('wallet_id')
            if requested_wallet and str(requested_wallet) != str(broker.wallet.get('id')):
                raise ValueError('selected_wallet_mismatch')
            broker.subscribe_prices([SYMBOL])
            broker.on_order_event = self.order_event
            self.executor = MobileExecutor(bc, broker)
            identity = str(broker.user_id) + ':' + str(broker.wallet.get('id'))
            wallet_key = hashlib.sha256(identity.encode()).hexdigest()[:24]
            self.executor.daily = DailyGuard(max_trades=0, max_loss=cfg['risk']['max_daily_loss'],
                                            state_path=str(self.root / ('daily_' + wallet_key + '.json')))
            self.executor.remember_orders(str(self.root / ('bot_orders_' + wallet_key + '.json')))
            self.executor.on_event = self.log
            filelog.setup(str(self.root / 'logs'))
            self.engine = Engine(self.executor, settings.engine_config(cfg))
            self.engine.on_event = self.decision
            from mobile_seen import DurableSeen
            self.seen = DurableSeen(self.root / ('seen_' + wallet_key + '.json'))
            self.router = MessageRouter(self.engine, lambda key, line: self.log(line), seen=self.seen)
            self.started_at = time.time()
            self.active, self.state, self.error = True, 'running', None
            async def on_new(event):
                if self.accept_new(event.message.date.timestamp()):
                    await self.router.new(CHANNEL, event.id, event.message.date.timestamp(), event.raw_text or '')
            async def on_edit(event):
                if self.active:
                    await self.router.edit(CHANNEL, event.id, event.message.date.timestamp(), event.raw_text or '')
            for callback, builder in [(on_new, events.NewMessage(chats=entity)),
                                      (on_edit, events.MessageEdited(chats=entity))]:
                tg.add_event_handler(callback, builder)
                self.handlers.append(callback)
            async def poll_new(key, mid, ts, text, recv=None):
                if self.accept_new(ts):
                    await self.router.new(key, mid, ts, text, recv=recv)
            async def poll_edit(*args, **kwargs):
                if self.active:
                    await self.router.edit(*args, **kwargs)
            poller = ChannelPoller(tg, lambda: {CHANNEL: '@' + CHANNEL}, poll_new, poll_edit,
                                   interval=1, max_wait=1.5, edit_max_age=300, on_line=self.log)
            self.tasks = [asyncio.create_task(poller.run(lambda: not self.active)),
                          asyncio.create_task(self.ticker())]
            return {'ok': True, 'state': self.state, 'mode': 'real' if broker.use_real else 'broker_demo'}
        except BaseException:
            self.active, self.state = False, 'failed'
            if self.executor:
                self.executor.retire('شروع ناموفق')
                self.executor.stop_watchdog()
            if self.broker:
                await asyncio.to_thread(self.broker.disconnect)
            self.broker = self.executor = self.engine = None
            raise

    def manual_message(self, mid, ts, text, edited=False):
        """Display-only path: deliberately has no broker/executor reference or call."""
        key = str(mid)
        if not self.active or (edited and key not in self.manual_messages):
            return
        if not edited and not self.accept_new(ts):
            return
        p = parse(text)
        if p.kind == 'NOISE':
            return
        self.manual_messages[key] = {
            'id': 'message_' + key, 'side': p.side, 'symbol': SYMBOL,
            'entry': p.entries, 'stop_loss': p.sl, 'take_profit': p.tps,
            'status': 'manual_review', 'kind': p.kind, 'source_message_id': mid,
            'source_message': text, 'opened_at': None, 'received_at': ts, 'pnl': None,
            'reason': ('این پیام فقط برای بررسی دستی نمایش داده شده؛ سفارشی ارسال نشده است. '
                       + (p.reason or 'جهت، ناحیهٔ ورود، استاپ و دستور مدیریت را با متن اصلی تطبیق دهید.')),
            'edited': edited,
        }
        if len(self.manual_messages) > 300:
            self.manual_messages.pop(next(iter(self.manual_messages)))

    async def _start_manual(self, tg, entity):
        from telethon import events
        from signal_trader.fastpoll import ChannelPoller
        self.manual_messages = {}
        self.started_at = time.time()
        self.active, self.state, self.error = True, 'manual_listening', None

        async def on_new(event):
            self.manual_message(event.id, event.message.date.timestamp(), event.raw_text or '')

        async def on_edit(event):
            self.manual_message(event.id, event.message.date.timestamp(), event.raw_text or '', edited=True)

        for callback, builder in [(on_new, events.NewMessage(chats=entity)),
                                  (on_edit, events.MessageEdited(chats=entity))]:
            tg.add_event_handler(callback, builder)
            self.handlers.append(callback)

        async def poll_new(key, mid, ts, text, recv=None):
            self.manual_message(mid, ts, text)

        async def poll_edit(key, mid, ts, text, recv=None):
            self.manual_message(mid, ts, text, edited=True)

        poller = ChannelPoller(tg, lambda: {CHANNEL: '@' + CHANNEL}, poll_new, poll_edit,
                               interval=2, max_wait=2, edit_max_age=300, on_line=self.log)
        self.tasks = [asyncio.create_task(poller.run(lambda: not self.active))]
        return {'ok': True, 'state': self.state, 'mode': 'manual',
                'notice': 'دریافت پیام فعال شد؛ هیچ اتصال معاملاتی به بروکر ایجاد نمی‌شود.'}

    def accept_new(self, ts):
        return self.active and ts is not None and float(ts) >= self.started_at

    async def ticker(self):
        while self.active:
            try:
                for line in await self.engine.tick():
                    self.log(line)
                self.signals()  # Capture the opening explanation even when UI is not on this tab.
            except Exception as exc:
                self.error = type(exc).__name__
            await asyncio.sleep(1)

    async def stop(self):
        async with self._command_lock:
            return await self._stop()

    async def _stop(self):
        self.active, self.state = False, 'stopped'
        if self.executor:
            self.executor.retire('توقف در موبایل')
            self.executor.stop_watchdog()
        for task in self.tasks:
            task.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        self.tasks = []
        if self.tg:
            for callback in self.handlers:
                self.tg.remove_event_handler(callback)
            self.handlers = []
            await self.tg.disconnect()
        if self.router:
            await self.router.drain()
        if self.broker:
            await asyncio.to_thread(self.broker.disconnect)
        self.broker = self.executor = self.engine = self.router = self.tg = None
        return {'ok': True, 'state': self.state,
                'notice': 'موتور متوقف شد؛ فقط استاپ و حد سود ثبت‌شدهٔ بروکر باقی می‌ماند. گارد مجازی به برنامهٔ فعال نیاز دارد.'}

    async def close_signal(self, oid):
        if self.config.get('execution_mode', 'manual') != 'automatic':
            return {'ok': False, 'error': 'manual_mode_no_orders'}
        if not self.active or self.engine is None:
            return {'ok': False, 'error': 'engine_not_running'}
        try:
            target = int(oid)
        except (TypeError, ValueError):
            return {'ok': False, 'error': 'invalid_order'}
        if target not in self.broker.my_order_ids:
            return {'ok': False, 'error': 'not_bot_order'}
        async with self.engine._get_lock():
            lines = await self.engine._close_ids([target], [], time.time())
        return {'ok': True, 'status': 'close_requested', 'lines': lines}

    async def audit_month(self):
        tg = await self.telegram()
        if not await tg.is_user_authorized():
            return {'ok': False, 'error': 'telegram_login_required'}
        end = dt.datetime.now(dt.timezone.utc)
        start = end - dt.timedelta(days=30)
        kinds, total, media = Counter(), 0, 0
        path = self.root / 'month_messages.jsonl'
        tmp = path.with_suffix('.tmp')
        complete = False
        try:
            with tmp.open('w', encoding='utf8') as file:
                async for msg in tg.iter_messages(CHANNEL, offset_date=end):
                    if msg.date < start:
                        break
                    body = msg.message or ''
                    p = parse(body)
                    kinds[p.kind] += 1
                    media += bool(msg.media)
                    total += 1
                    file.write(dumps({'id': msg.id, 'date': msg.date.isoformat(),
                                      'edit_date': msg.edit_date.isoformat() if msg.edit_date else None,
                                      'text': body, 'has_media': bool(msg.media), 'kind': p.kind,
                                      'entries': p.entries, 'sl': p.sl, 'tps': p.tps}) + '\n')
            tmp.replace(path)
            complete = True
        finally:
            self.month = {'period_start': start.isoformat(), 'period_end': end.isoformat(),
                          'message_count': total, 'coverage_complete': False,
                          'accessible_messages_fetched': complete,
                          'media_count': media, 'kinds': dict(kinds), 'net_pnl': None,
                          'wins': 0, 'losses': 0, 'unknown': kinds['ZONE'] + kinds['SIGNAL'],
                          'notice': 'پوشش پیام‌های قابل‌دسترسی حساب؛ پیام حذف‌شده و تاریخچهٔ ویرایش قابل بازیابی نیست. '
                                    'صدا/تصویر تحلیل نشده است. بدون تاریخچهٔ قیمت bid/ask، کارمزد و لغزش، بازده کانال قابل تأیید نیست.'}
            (self.root / 'month_report.json').write_text(dumps(self.month), encoding='utf8')
        return {'ok': complete, **self.month}

    def status(self):
        automatic = self.config.get('execution_mode', 'manual') == 'automatic'
        telegram_connected = bool(self.active and self.tg and self.tg.is_connected())
        connected = telegram_connected and (not automatic or bool(self.broker and self.broker.is_alive()))
        return {'mode': (('real' if self.broker.use_real else 'broker_demo') if self.broker else 'offline') if automatic else 'manual',
                'execution_mode': 'automatic' if automatic else 'manual',
                'wallet_id': (self.broker.wallet or {}).get('id') if automatic and self.broker else None,
                'connected': connected, 'running': self.active, 'state': self.state,
                'channel': '@' + CHANNEL, 'version': __version__, 'error': self.error,
                'events': list(self.events)}

    def pending_exit(self, oid):
        if self.engine and self.executor:
            for request in self.engine.close_retries.values():
                if str(oid) in [str(x) for x in self.executor.broker_ids([request['id']])]:
                    return True
        return False

    def signals(self):
        if self.config.get('execution_mode', 'manual') != 'automatic':
            return {'items': list(reversed(list(self.manual_messages.values()))), 'decisions': []}
        items = []
        broker, executor = self.broker, self.executor
        if broker and executor:
            by_id = {}
            for decision in list(self.decisions):
                setup = decision.get('setup') or {}
                for oid in executor.broker_ids(setup.get('ids') or []):
                    if setup.get('placed') and decision.get('lines'):
                        by_id.setdefault(str(oid), decision)
            for oid, ev in by_id.items():
                key = str((broker.wallet or {}).get('id')) + ':' + oid
                self.explanations.setdefault(key, ev)
            for order in list(broker.orders_for(SYMBOL)):
                oid = str(order['id'])
                if int(oid) not in broker.my_order_ids:
                    continue
                ev = by_id.get(oid)
                wallet_key = str((broker.wallet or {}).get('id')) + ':' + oid
                if ev and wallet_key not in self.explanations:
                    self.explanations[wallet_key] = ev
                ev = self.explanations.get(wallet_key)
                reason = ('\n'.join(ev['lines']) if ev else
                          'سفارش متعلق به ربات در بروکر بازیابی شد؛ توضیح ورود در این نشست موجود نیست.')
                items.append({'id': oid, 'side': 'BUY' if str(order.get('type')) == '0' else 'SELL',
                              'symbol': SYMBOL, 'entry': order.get('open'), 'stop_loss': order.get('sl'),
                              'take_profit': order.get('tp'), 'status': ('close_pending' if self.pending_exit(oid) else 'open'), 'reason': reason,
                              'source_message': ev.get('text') if ev else None,
                              'source_message_id': ev.get('id') if ev else None,
                              'opened_at': order.get('open_time_current'), 'pnl': order.get('profit')})
        for key, closed in list(self.closed.items()):
            if broker and closed['wallet'] != str((broker.wallet or {}).get('id')):
                continue
            ev = self.explanations.get(key)
            items.append({**closed, 'pnl': closed.get('profit'), 'status': 'closed',
                          'reason': ('\n'.join(ev.get('lines', [])) if ev else 'توضیح ورود ثبت نشده؛ بسته‌شدن از رویداد بروکر تأیید شده است.'),
                          'source_message': ev.get('text') if ev else None,
                          'source_message_id': ev.get('id') if ev else None})
        if self.root and self.explanations:
            with self.lock:
                tmp = self.root / 'explanations.tmp'
                tmp.write_text(dumps(self.explanations), encoding='utf8')
                tmp.replace(self.root / 'explanations.json')
        return {'items': items, 'decisions': list(self.decisions)}


_runtime = Runtime()

def status():
    return dumps(_runtime.status())

def signals():
    async def snapshot():
        return _runtime.signals()
    return dumps(_runtime.call(snapshot()))

def report():
    with _runtime.lock:
        return dumps(_runtime.month)

def preview(text):
    p = parse(str(text))
    return dumps({'kind': p.kind, 'side': p.side, 'entries': p.entries, 'stop_loss': p.sl,
                  'take_profits': p.tps, 'reason': p.reason or 'فقط پیش‌نمایش خواندن متن؛ سفارشی ارسال نشده است.'})

def start(config_json):
    return dumps(_runtime.call(_runtime.start(config_json)))

def stop():
    return dumps(_runtime.call(_runtime.stop()))

def request_code(config_json):
    return dumps(_runtime.call(_runtime.request_code(config_json)))

def verify_code(code, password=''):
    return dumps(_runtime.call(_runtime.verify_code(code, password)))

def close_signal(signal_id):
    return dumps(_runtime.call(_runtime.close_signal(signal_id)))

def audit_month():
    return dumps(_runtime.call(_runtime.audit_month(), timeout=600))
