"""Live-only channel delivery. No network or broker actions in this policy.

Use the Telegram publication date for new messages and edit_date for edits.
Re-check under the engine lock: a fresh arrival can expire while queued.
"""
import hashlib
import math
import time
from contextvars import ContextVar
from collections import OrderedDict

# Propagates into asyncio.to_thread, but not to later independent price ticks.
submission_deadline = ContextVar('mobile_submission_deadline', default=None)


class LiveDelivery:
    MAX_AGE = 10.0

    def __init__(self, started_at, clock=time.time):
        self.started_at = started_at
        self.clock = clock
        self.known = OrderedDict()
        self.revisions = OrderedDict()
        self.counts = {'accepted': 0, 'expired': 0, 'before_start': 0,
                       'duplicate': 0, 'invalid': 0, 'unknown_edit': 0}
        self.last_delay = None
        self.last_arrival = None

    @staticmethod
    def key(mid, text, edited):
        return str(mid), hashlib.sha256((text or '').encode()).hexdigest(), edited

    def freshness(self, ts):
        try:
            stamp = float(ts)
            age = self.clock() - stamp
            if not math.isfinite(age) or age < -2:
                return 'invalid'
            if stamp < self.started_at:
                return 'before_start'
            return 'expired' if age > self.MAX_AGE else 'accepted'
        except (ValueError, TypeError):
            return 'invalid'

    def offer(self, mid, ts, text, edited=False, edited_at=None, received_at=None):
        key = self.key(mid, text, edited)
        # Reaction edits and push/poll copies do not change the receipt time.
        if key in self.revisions or (edited and self.known.get(str(mid)) == key[1]):
            self.counts['duplicate'] += 1
            return 'duplicate'
        stamp = edited_at if edited else ts
        verdict = self.freshness(stamp)
        if edited and str(mid) not in self.known:
            verdict = 'unknown_edit'
        self.revisions[key] = (stamp, verdict)
        while len(self.revisions) > 2000:
            self.revisions.popitem(last=False)
        self.counts[verdict] += 1
        if verdict not in ('before_start', 'unknown_edit', 'invalid'):
            arrival = self.clock() if received_at is None else received_at
            self.last_arrival = arrival
            self.last_delay = max(0.0, arrival - float(stamp))
        if verdict == 'accepted':
            self.known[str(mid)] = key[1]
            while len(self.known) > 1000:
                self.known.popitem(last=False)
        return verdict

    def guard(self, text, msg_id, ts, edited=False):
        record = self.revisions.get(self.key(msg_id, text, edited))
        if record is None or record[1] != 'accepted':
            return 'این پیام در دریافت زندهٔ همین نشست تأیید نشده؛ اجرا نشد.'
        reason = self.freshness(record[0])
        if reason != 'accepted':
            if record[1] != 'expired':
                self.revisions[self.key(msg_id, text, edited)] = (record[0], reason)
                self.counts[reason] += 1
            return 'پیام پیش از اجرای دستور از مهلت ۱۰ ثانیه گذشت یا زمان آن معتبر نیست؛ اجرا نشد.'
        submission_deadline.set(float(record[0]) + self.MAX_AGE)
        return None

    def snapshot(self):
        return {'max_age_seconds': self.MAX_AGE, 'counts': dict(self.counts),
                'last_delay_seconds': self.last_delay, 'last_arrival_at': self.last_arrival}
