"""Trendo REST transport without curl_cffi native desktop libraries.

Uses verified TLS with requests. Server compatibility must be tested on demo;
a broker requiring browser TLS impersonation can reject this transport.
"""
from signal_trader.brokers.trendo_client import TrendoClient

class AndroidTrendoClient(TrendoClient):
    def _choose_wallet(self):
        # Fail closed on missing/ambiguous wallet metadata; never fall back to
        # another account after the user supplies an explicit wallet ID.
        pool = [w for w in self.wallets
                if not w.get('is_archive')
                and type(w.get('is_real')) in (bool, int)
                and w['is_real'] in (0, 1)
                and bool(w['is_real']) == self.use_real
                and str(w.get('currency', '')).upper() == 'USD']
        if self.wallet_id_cfg not in (None, ''):
            pool = [w for w in pool if str(w.get('id')) == str(self.wallet_id_cfg)]
        if len(pool) != 1:
            raise ValueError('کیف پول دلاری انتخاب‌شده موجود نیست یا چند حساب دارید؛ شناسه دقیق کیف پول را وارد کنید')
        return pool[0]

    def login(self):
        import requests
        if not self.username or not self.password:
            raise ValueError('broker_credentials_missing')
        body = {'email': self.username, 'password': self.password,
                'device_id': self.device['device_id'], 'device': self.device['device'],
                'versionName': self.device['version_name'], 'buildNumber': self.device['build_number'],
                'lang': self.device['lang'], 'os': self.device['os'], 'theme': 'true',
                'packageName': self.device['package_name']}
        response = requests.post(self.login_url, data=body, timeout=(15, 30))
        response.raise_for_status()
        data = response.json()
        token = data
        for part in self.token_path.split('.'):
            token = token.get(part) if isinstance(token, dict) else None
        if not token:
            raise ValueError('broker_token_missing')
        self.user_token = token
        self.user_id = (data.get('user') or {}).get('id')
        self.wallets = data.get('wallets') or []
        self.wallet = self._choose_wallet()
        if self.wallet is None:
            raise ValueError('selected_wallet_unavailable')
        self.needs_relogin = False
        return data
