"""Trendo REST transport without curl_cffi native desktop libraries.

Uses verified TLS with requests. Server compatibility must be tested on demo;
a broker requiring browser TLS impersonation can reject this transport.
"""
from signal_trader.brokers.trendo_client import TrendoClient

class AndroidTrendoClient(TrendoClient):
    @staticmethod
    def wallet_info(w):
        # Unknown account kinds must never be guessed to be demo or real.
        real = w.get('is_real')
        kind = ('real' if bool(real) else 'demo') if type(real) in (bool, int) and real in (0, 1) else 'unknown'
        if w.get('is_bonus') in (True, 1, '1') or str(w.get('type', '')).lower() in ('bonus', 'wallet'):
            kind = 'unknown'
        currency = str(w.get('currency') or '').upper()
        archived = w.get('is_archive') not in (None, False, 0, '0', '')
        supported = kind != 'unknown' and currency in ('USD', 'EUR') and not archived and w.get('id') is not None
        return {'id': str(w.get('id', '')), 'kind': kind, 'currency': currency,
                'balance': str(w.get('balance', '—')), 'supported': supported,
                'reason': '' if supported else 'نوع حساب یا ارز پشتیبانی نمی‌شود، یا حساب بایگانی شده است'}

    def available_wallets(self):
        return [self.wallet_info(w) for w in self.wallets if isinstance(w, dict)]

    def _choose_wallet(self):
        # Fail closed on missing/ambiguous wallet metadata; never fall back to
        # another account after the user supplies an explicit wallet ID.
        pool = [w for w in self.wallets if isinstance(w, dict)
                and self.wallet_info(w)['supported']
                and bool(w['is_real']) == self.use_real]
        if self.wallet_id_cfg not in (None, ''):
            pool = [w for w in pool if str(w.get('id')) == str(self.wallet_id_cfg)]
        if len(pool) != 1:
            raise ValueError('wallet_selection_required')
        return pool[0]

    def login(self, select_wallet=True):
        import requests
        if not self.username or not self.password:
            raise ValueError('broker_credentials_missing')
        body = {'email': self.username, 'password': self.password,
                'device_id': self.device['device_id'], 'device': self.device['device'],
                'versionName': self.device['version_name'], 'buildNumber': self.device['build_number'],
                'lang': self.device['lang'], 'os': self.device['os'], 'theme': 'true',
                'packageName': self.device['package_name']}
        response = requests.post(self.login_url, data=body, timeout=(15, 30))
        if response.status_code in (401, 403):
            raise ValueError('broker_login_rejected')
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            raise ValueError('broker_response_changed')
        token = data
        for part in self.token_path.split('.'):
            token = token.get(part) if isinstance(token, dict) else None
        if not token:
            raise ValueError('broker_token_missing')
        self.user_token = token
        self.user_id = (data.get('user') or {}).get('id')
        self.wallets = data.get('wallets') or []
        if not isinstance(self.wallets, list):
            raise ValueError('broker_response_changed')
        self.wallet = self._choose_wallet() if select_wallet else None
        self.needs_relogin = False
        return data
