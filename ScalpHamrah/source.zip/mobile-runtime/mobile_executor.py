"""Android-only sizing policy: do not raise risk to broker minimum volume."""
from signal_trader.executors.fxtrendo import FxTrendoExecutor
import copy
import math
import time
from live_delivery import submission_deadline
from signal_trader.models import Side

class MobileExecutor(FxTrendoExecutor):
    def _be_ref(self, order, entry, ref_price):
        # The supplied channel rule is three of its gold pips (0.30 price
        # units) on the profit side of OUR fill, never the leader's entry.
        # Use the fill each time; repeated BE must not ratchet another 0.30.
        side = self._order_side(order)
        fill = float(entry)
        if side is None or not math.isfinite(fill) or fill <= 0:
            return super()._be_ref(order, entry, None)
        target = fill + (.3 if side == Side.BUY else -.3)
        current = self._as_float(order.get('sl'), 0.0)
        if math.isfinite(current) and current > 0:
            target = max(target, current) if side == Side.BUY else min(target, current)
        return target

    @staticmethod
    def _message_expired():
        deadline = submission_deadline.get()
        return deadline is not None and time.time() > deadline

    def _place_live(self, sig, lot, tp, stop=None):
        # The socket may reconnect after planning; include the deadline in the
        # client's final emit guard, not only the initial Python queue check.
        if self._message_expired():
            return {'action': 'rejected', 'reason': 'مهلت پیام پیش از ارسال به بروکر تمام شد'}
        stopped = stop or (lambda: self._retired)
        return super()._place_live(sig, lot, tp, stop=lambda: stopped() or self._message_expired())

    def _add_virtual(self, signal, edge, quote=FxTrendoExecutor._FETCH):
        if self._message_expired():
            return None
        return super()._add_virtual(signal, edge, quote)

    def _plan(self, signal, fill=None):
        # Convert the sizing contract only, not balance/equity: the daily guard
        # and broker ledger must stay in the wallet's own currency.
        planner = self
        client = getattr(self, 'client', None)
        currency = str((getattr(client, 'wallet', None) or {}).get('currency', 'USD')).upper()
        if currency == 'EUR':
            try:
                symbol = client.broker_symbol('EURUSD')
                age = float(client.price_age(symbol))
                bid, ask = map(float, client.price(symbol))
                if not all(math.isfinite(x) for x in (age, bid, ask)) or not (0 <= age <= 15 and 0 < bid <= ask):
                    raise ValueError('stale conversion')
            except (AttributeError, TypeError, ValueError):
                return [], 'حساب یورویی: قیمت تازهٔ EURUSD برای محاسبهٔ ریسک نرسیده؛ سفارش ارسال نشد'
            planner = copy.copy(self)
            planner.risk = copy.copy(self.risk)
            # Bid plus a 2% conversion buffer is conservative for a USD loss.
            planner.risk.contracts = {s: v / bid * 1.02 for s, v in self.risk.contracts.items()}
        elif currency != 'USD':
            return [], 'ارز حساب برای محاسبهٔ ریسک پشتیبانی نمی‌شود'
        plan, note = FxTrendoExecutor._plan(planner, signal, fill)
        if not plan:
            return plan, note
        balance = self._balance()
        contract = planner.risk.contracts.get(signal.symbol.upper())
        prices = [fill] if fill is not None else signal.entries
        if not balance or not contract or not prices or signal.stop_loss is None:
            return [], 'اندازه‌گیری ریسک کامل نیست؛ سفارش ارسال نشد'
        distance = max(abs(float(p) - float(signal.stop_loss)) for p in prices)
        actual = sum(lot for lot, _ in plan) * distance * contract
        budget = balance * self.risk.risk_pct / 100
        if not all(math.isfinite(x) and x > 0 for x in (balance, distance, contract, budget, actual)):
            return [], 'عدد نامعتبر در محاسبهٔ ریسک؛ سفارش ارسال نشد'
        if actual > budget + 1e-8:
            return [], 'حداقل حجم بروکر از بودجهٔ ریسک بیشتر است؛ سفارش ارسال نشد'
        return plan, note
