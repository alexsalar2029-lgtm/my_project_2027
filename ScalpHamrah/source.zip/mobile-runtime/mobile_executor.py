"""Android-only sizing policy: do not raise risk to broker minimum volume."""
from signal_trader.executors.fxtrendo import FxTrendoExecutor

class MobileExecutor(FxTrendoExecutor):
    def _plan(self, signal, fill=None):
        plan, note = super()._plan(signal, fill)
        if not plan:
            return plan, note
        balance = self._balance()
        contract = self.risk.contracts.get(signal.symbol.upper())
        prices = [fill] if fill is not None else signal.entries
        if not balance or not contract or not prices or signal.stop_loss is None:
            return [], 'اندازه‌گیری ریسک کامل نیست؛ سفارش ارسال نشد'
        distance = max(abs(float(p) - float(signal.stop_loss)) for p in prices)
        actual = sum(lot for lot, _ in plan) * distance * contract
        budget = balance * self.risk.risk_pct / 100
        if actual > budget + 1e-8:
            return [], 'حداقل حجم بروکر از بودجهٔ ریسک بیشتر است؛ سفارش ارسال نشد'
        return plan, note
