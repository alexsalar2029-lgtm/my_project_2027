"""Android-only sizing policy: do not raise risk to broker minimum volume."""
from signal_trader.executors.fxtrendo import FxTrendoExecutor
import copy
import math

class MobileExecutor(FxTrendoExecutor):
    def _plan(self, signal, fill=None):
        # Convert the sizing contract only, not balance/equity: the daily guard
        # and broker ledger must stay in the wallet's own currency.
        planner = self
        client = getattr(self, 'client', None)
        currency = str((getattr(client, 'wallet', None) or {}).get('currency', 'USD')).upper()
        if currency == 'EUR':
            try:
                symbol = client.broker_symbol('EURUSD')
                age = float(client.price_age(symbol))
                bid, ask = map(float, client.price(symbol))
                if not all(math.isfinite(x) for x in (age, bid, ask)) or not (0 <= age <= 15 and 0 < bid <= ask):
                    raise ValueError('stale conversion')
            except (AttributeError, TypeError, ValueError):
                return [], 'حساب یورویی: قیمت تازهٔ EURUSD برای محاسبهٔ ریسک نرسیده؛ سفارش ارسال نشد'
            planner = copy.copy(self)
            planner.risk = copy.copy(self.risk)
            # Bid plus a 2% conversion buffer is conservative for a USD loss.
            planner.risk.contracts = {s: v / bid * 1.02 for s, v in self.risk.contracts.items()}
        elif currency != 'USD':
            return [], 'ارز حساب برای محاسبهٔ ریسک پشتیبانی نمی‌شود'
        plan, note = FxTrendoExecutor._plan(planner, signal, fill)
        if not plan:
            return plan, note
        balance = self._balance()
        contract = planner.risk.contracts.get(signal.symbol.upper())
        prices = [fill] if fill is not None else signal.entries
        if not balance or not contract or not prices or signal.stop_loss is None:
            return [], 'اندازه‌گیری ریسک کامل نیست؛ سفارش ارسال نشد'
        distance = max(abs(float(p) - float(signal.stop_loss)) for p in prices)
        actual = sum(lot for lot, _ in plan) * distance * contract
        budget = balance * self.risk.risk_pct / 100
        if not all(math.isfinite(x) and x > 0 for x in (balance, distance, contract, budget, actual)):
            return [], 'عدد نامعتبر در محاسبهٔ ریسک؛ سفارش ارسال نشد'
        if actual > budget + 1e-8:
            return [], 'حداقل حجم بروکر از بودجهٔ ریسک بیشتر است؛ سفارش ارسال نشد'
        return plan, note
