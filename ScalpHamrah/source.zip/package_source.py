"""Package only source and sanitized reports; never include sessions/build caches."""
import hashlib
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
out = root.parent / 'github-publish'
out.mkdir(exist_ok=True)
files = set()
for name in ('README_FA.md', 'RELEASE_NOTES_FA.md', 'requirements-mobile.lock',
             'prepare_wheels.py', 'package_source.py', 'verify_apk.py', 'capture_ui.py', 'USER_GUIDE_FA.md', '.gitignore'):
    files.add(root / name)
for part in ('engine', 'mobile-runtime', 'audit'):
    files.update(p for p in (root / part).rglob('*.py') if '__pycache__' not in p.parts)
for name in ('engine/lordxau/dashboard.html', 'engine/FIXES_FA.md', 'engine/VALIDATION_2.0.12.txt',
             'mobile-runtime/README_FA.md', 'audit/README_FA.md', 'audit/current_month.json',
             'android/README_FA.md'):
    files.add(root / name)
for p in (root / 'android').rglob('*'):
    rel = p.relative_to(root / 'android')
    if not p.is_file() or any(x in rel.parts for x in ('build', '.gradle', 'python-wheels')):
        continue
    if p.name == 'local.properties':
        continue
    if p.suffix in ('.kt', '.kts', '.xml') or p.name in ('gradlew', 'gradlew.bat', 'gradle-wrapper.jar', 'gradle-wrapper.properties', 'gradle.properties'):
        files.add(p)
for path in files:
    assert path.is_file(), path
    assert not any(word in path.name for word in ('.session', '.keystore', '.jks', '.env')), path
archive = out / 'source.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files):
        name = p.relative_to(root).as_posix()
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 20, 0, 0, 0))
        info.external_attr = (0o100755 if p.name == 'gradlew' else 0o100644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, p.read_bytes())
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(out / 'source.sha256').write_text(digest + '  source.zip\n')
print(f'{len(files)} source files; archive {archive.stat().st_size} bytes; SHA256 {digest}')
