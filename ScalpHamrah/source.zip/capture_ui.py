"""Capture fresh offline screens using accessibility text, not fixed coordinates."""
from pathlib import Path
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)

def adb(*args):
    return subprocess.check_output(['adb', *args], timeout=30)

def capture(name):
    (out / (name + '.png')).write_bytes(adb('exec-out', 'screencap', '-p'))

def tap(text):
    for attempt in range(5):
        adb('shell', 'uiautomator', 'dump', '/sdcard/lionxsec-ui.xml')
        root = ET.fromstring(adb('shell', 'cat', '/sdcard/lionxsec-ui.xml'))
        for node in root.iter('node'):
            if node.get('text') == text:
                x1, y1, x2, y2 = map(int, re.findall(r'\d+', node.get('bounds')))
                adb('shell', 'input', 'tap', str((x1+x2)//2), str((y1+y2)//2))
                time.sleep(2)
                return
        dims = re.findall(r'(\d+)x(\d+)', adb('shell', 'wm', 'size').decode())
        if dims:
            width, height = map(int, dims[-1])
            adb('shell', 'input', 'swipe', str(width//2), str(int(height*.78)), str(width//2), str(int(height*.35)), '350')
        time.sleep(1)
    raise RuntimeError('UI text missing: ' + text)

adb('shell', 'am', 'start', '-n', 'app.lordxau.mobile/.MainActivity')
time.sleep(3)
capture('home')
tap('آموزش')
tap('Trendo')
capture('academy')
tap('انتخاب حساب')
tap('تصویر بعد  ←')
capture('wallet-lesson')
tap('بستن درس ×')
tap('فری کردن استاپ')
for _ in range(3): tap('تصویر بعد  ←')
capture('trendo-lesson')
tap('بستن درس ×')
tap('تنظیمات')
tap('۲ حساب ترندو')
capture('connection-setup')
