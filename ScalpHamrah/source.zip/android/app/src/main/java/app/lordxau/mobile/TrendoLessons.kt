package app.lordxau.mobile

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private data class WalkStep(val title: String, val explanation: String, val focus: String, val screen: String = "form")
private data class WalkCourse(val label: String, val steps: List<WalkStep>)
private val walkthroughs = listOf(
    WalkCourse("سفارش لیمیت", listOf(
        WalkStep("۱. طلا را پیدا کن", "در صفحهٔ خانهٔ تصویر، GOLD همان نماد طلای مثال است. مشخصات قرارداد نماد را هم بررسی کن.", "symbol", "home"),
        WalkStep("۲. سفارش جدید", "از بخش معامله، علامت + را انتخاب کن. هنوز هیچ معامله‌ای باز نشده است.", "new", "trade"),
        WalkStep("۳. حجم را بررسی کن", "۰٫۰۱ فقط حجم نمونهٔ تصویر است. حجم مناسب به بودجهٔ ریسک، فاصلهٔ استاپ و مشخصات قرارداد بستگی دارد؛ مقدار ۱۰٫۰۰ بعضی تصاویر را کپی نکن.", "volume"),
        WalkStep("۴. نوع سفارش", "برای نمونهٔ کانال، Buy Limit را انتخاب کن: خرید در قیمتی پایین‌تر از قیمت فعلی Ask. آن را با Market یا Buy Stop اشتباه نگیر.", "type"),
        WalkStep("۵. قیمت ورود", "Enter:2900 یعنی قیمت سفارش ۲۹۰۰. این عدد از آموزش قدیمی است و سیگنال امروز نیست.", "entry"),
        WalkStep("۶. حد سود", "TP:2910 یعنی قیمت حد سود ۲۹۱۰؛ این عدد مبلغ سود دلاری نیست.", "tp"),
        WalkStep("۷. حد ضرر", "Stop:2898 یعنی قیمت حد ضرر ۲۸۹۸. در این مثال خرید، استاپ پایین‌تر از ورود است.", "sl"),
        WalkStep("۸. ثبت سفارش", "نماد، جهت، حجم و قیمت‌ها را دوباره بخوان. دکمهٔ «مکان» در تصاویر، سفارش را ثبت می‌کند.", "submit"),
        WalkStep("۹. هنوز در انتظار", "نمایش سفارش در انتظار یعنی شرط ورود هنوز اجرا نشده؛ آن را معاملهٔ باز یا سود قطعی حساب نکن.", "pending", "pending")
    )),
    WalkCourse("ورود بازار", listOf(
        WalkStep("۱. معنی پیام سریع", "Gold buy now یعنی درخواست خرید بازار و Gold sell now یعنی فروش بازار. متن ناقص بدون استاپ، بودجهٔ زیان مشخصی ندارد؛ در تمرین ابتدا اطلاعات را کامل کن.", "type"),
        WalkStep("۲. اجرا در قیمت بازار", "Market درخواست اجرا با قیمت قابل‌دسترسی است. قیمت ورود تو ممکن است با پیام کانال متفاوت باشد؛ چند ثانیه صبر هم تطابق را تضمین نمی‌کند.", "type"),
        WalkStep("۳. حجم متناسب", "حجم را با استاپ و بودجهٔ ریسک حساب کن. این شبیه‌سازی پول واقعی ندارد؛ برای افراد کم‌سن هم فقط تمرین مجازی است.", "volume"),
        WalkStep("۴. حفاظت قبل از ارسال", "در مثال کامل‌شده، SL و TP را قبل از ارسال وارد کن. صفر یا خط تیره ممکن است یعنی حفاظت ثبت نشده است.", "sl"),
        WalkStep("۵. جهت صحیح", "در نمونه خرید دکمهٔ Buy را می‌زنی؛ اگر پیام فروش است Sell. همین صفحهٔ آموزشی هیچ سفارشی ارسال نمی‌کند.", "submit"),
        WalkStep("۶. اجرای تأییدشده", "شناسه، ورود واقعی، حجم و SL/TP پذیرفته‌شده را بخوان. رسیدن پیام یا لمس دکمه، اثبات اجرای سفارش نیست.", "position", "position")
    )),
    WalkCourse("تغییر و فری", listOf(
        WalkStep("۱. معاملهٔ درست", "در بخش معامله، نماد و جهت و شناسهٔ همان سفارش را پیدا کن. دستور مربوط به سفارش دیگر را روی این معامله اعمال نکن.", "position", "position"),
        WalkStep("۲. گزینهٔ تغییر", "در تصویر مدیر کانال، روی معامله بزن و «تغییر» را انتخاب کن.", "change", "position"),
        WalkStep("۳. SL و TP", "عددها را در فیلد قیمت حد ضرر و حد سود وارد کن. در خرید SL معمولاً پایین‌تر از قیمت جاری و در فروش بالاتر از آن است؛ حداقل فاصلهٔ بروکر هم مهم است.", "sl"),
        WalkStep("۴. فری به زبان ساده", "مدیر کانال مثال خرید ۳۹۰۸ و استاپ ۳۹۰۸٫۳ را گفته است. برای فروش جهت برعکس است؛ ورود واقعی خودت، هزینه‌ها و قیمت فعلی را بررسی کن. این جابه‌جایی تضمین بی‌ضررشدن نیست.", "sl"),
        WalkStep("۵. تأیید تغییر", "پس از تأیید، مقدار ذخیره‌شدهٔ SL/TP را در معامله ببین. اگر بروکر رد کرد، حفاظت جدید فعال نشده؛ استاپ را برای فرار از زیان دورتر نبر.", "submit")
    )),
    WalkCourse("بستن معامله", listOf(
        WalkStep("۱. سفارش هدف", "روی معاملهٔ موردنظر بزن و شناسه و حجم باز را بخوان. بستن همهٔ معاملات با خروج از یک سفارش فرق دارد.", "position", "position"),
        WalkStep("۲. بستن", "در تصویر، دکمهٔ «بستن» مرحلهٔ اول خروج است. هنوز نباید نتیجه را بسته‌شده نشان داد.", "close", "position"),
        WalkStep("۳. تأیید دوم", "دکمهٔ تأیید خروج را هم بزن. اگر مهلت تأیید تمام شده یا خطا دیده‌ای، اول وضعیت سفارش را بررسی کن.", "confirm", "confirm"),
        WalkStep("۴. پیگیری حجم باقی‌مانده", "مثلاً اگر از ۰٫۰۲ لات فقط ۰٫۰۱ بسته شده، هنوز ۰٫۰۱ باز است. تا تأیید بروکر، پیام خروج کامل نده.", "remaining", "remaining"),
        WalkStep("۵. خروج تأییدشده", "وقتی حجم باز همان شناسه صفر شد و نتیجه در تاریخچه ثبت شد، خروج کامل است. این صفحه فقط پایان یک سناریوی فرضی را نمایش می‌دهد.", "closed", "closed")
    ))
)

@Composable fun AnimatedTrendoLesson(reduced: Boolean) {
    var course by rememberSaveable { mutableIntStateOf(0) }
    var step by rememberSaveable { mutableIntStateOf(0) }
    var playing by rememberSaveable { mutableStateOf(false) }
    val selected = walkthroughs[course]
    LaunchedEffect(playing, course, step, reduced) {
        if (playing && !reduced) {
            delay(6500)
            if (step < selected.steps.lastIndex) step++ else playing = false
        }
    }
    Text("آموزش متحرک ترندو", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("بازسازی سادهٔ تصاویر ارسالی و توضیح مدیر کانال؛ عددها قدیمی و آموزشی‌اند. هیچ لمس این بخش، معامله‌ای ارسال نمی‌کند.")
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        walkthroughs.forEachIndexed { i, c -> FilterChip(selected = course == i, onClick = { course = i; step = 0; playing = false }, label = { Text(c.label) }, modifier = Modifier.testTag("lesson-course-$i")) }
    }
    CardBlock {
        val progress by animateFloatAsState((step + 1f) / selected.steps.size, tween(if (reduced) 0 else 450), label = "lesson progress")
        Text("گام ${step + 1} از ${selected.steps.size} • فقط تمرین", color = MaterialTheme.colorScheme.primary)
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        if (reduced) LessonScreen(selected.steps[step], course)
        else AnimatedContent(targetState = Pair(course, step), label = "trendo walkthrough") { (c, s) -> LessonScreen(walkthroughs[c].steps[s], c) }
        Text(selected.steps[step].title, fontWeight = FontWeight.Bold, fontSize = 19.sp, modifier = Modifier.testTag("lesson-title"))
        Text(selected.steps[step].explanation, lineHeight = 26.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { playing = false; step = if (step == selected.steps.lastIndex) 0 else step + 1 }, modifier = Modifier.testTag("lesson-next")) { Text(if (step == selected.steps.lastIndex) "مرور از ابتدا" else "گام بعد") }
            OutlinedButton(onClick = { playing = false; step-- }, enabled = step > 0) { Text("گام قبل") }
        }
        TextButton(onClick = { playing = !playing }, enabled = !reduced && step < selected.steps.lastIndex, modifier = Modifier.testTag("lesson-play")) { Text(if (playing) "توقف پخش" else "پخش خودکار آموزش") }
        if (reduced) Text("حرکت خاموش است؛ با گام بعد ادامه بده.")
    }
    Text("تصاویر مربوط به نسخهٔ زمان آموزش‌اند؛ جای دکمه‌ها در نسخهٔ نصب‌شده ممکن است متفاوت باشد.", style = MaterialTheme.typography.bodySmall)
    LessonSourceLinks()
}

@Composable private fun LessonScreen(s: WalkStep, course: Int) {
    Surface(color = Color(0xFF080D15), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("شبیه‌سازی تصویری • حساب مجازی", color = Color(0xFF8EA3BA), fontSize = 12.sp)
            DemoRow("symbol", s.focus, "GOLD", "طلا")
            when (s.screen) {
                "home" -> Text("خانه  •  معامله  •  نمودار  •  تاریخچه", fontSize = 12.sp)
                "trade" -> DemoRow("new", s.focus, "+", "سفارش جدید")
                "pending" -> DemoRow("pending", s.focus, "Buy Limit · 2900", "در انتظار؛ هنوز باز نشده")
                "position", "confirm", "remaining", "closed" -> {
                    DemoRow("position", s.focus, "GOLD · BUY", "شناسهٔ نمونه: ۱۲۳")
                    DemoRow("remaining", s.focus, if (s.screen == "closed") "0.00" else if (s.screen == "remaining") "0.01 / 0.02" else "0.01", "حجم باز")
                    when (s.screen) {
                        "confirm" -> DemoRow("confirm", s.focus, "تأیید خروج", "مرحلهٔ دوم")
                        "closed" -> DemoRow("closed", s.focus, "خروج کامل", "ثبت در تاریخچهٔ فرضی")
                        else -> { DemoRow("change", s.focus, "تغییر", "SL / TP"); DemoRow("close", s.focus, "بستن", "همین سفارش") }
                    }
                }
                else -> {
                    DemoRow("volume", s.focus, "0.01", "حجم نمونه")
                    DemoRow("type", s.focus, if (course == 0) "Buy Limit" else "اجرای قیمت بازار", "نوع سفارش")
                    DemoRow("entry", s.focus, "2900", "ورود نمونه")
                    DemoRow("tp", s.focus, "2910", "حد سود TP")
                    DemoRow("sl", s.focus, "2898", "حد ضرر SL")
                    DemoRow("submit", s.focus, if (course == 0) "مکان" else if (course == 2) "تأیید تغییر" else "خرید Buy", "بازبینی نهایی")
                }
            }
        }
    }
}

@Composable private fun DemoRow(id: String, focus: String, value: String, label: String) {
    val active = id == focus
    Surface(color = if (active) Color(0xFF143D57) else Color(0xFF121C29), shape = RoundedCornerShape(9.dp), modifier = Modifier.fillMaxWidth().border(if (active) 2.dp else 0.dp, if (active) Color(0xFF52CE94) else Color.Transparent, RoundedCornerShape(9.dp))) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
            Text(value, modifier = Modifier.weight(1f), fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, color = if (active) Color(0xFF8BD9FF) else Color.White, fontSize = 14.sp)
        }
    }
}

@Composable private fun LessonSourceLinks() {
    val ctx = LocalContext.current
    var error by remember { mutableStateOf("") }
    val sources = listOf(
        "راهنمای رسمی سفارش شرطی" to "https://help.trendo.com/portal/fa/kb/articles/trendo-pending-orders-buy-sell-limit",
        "راهنمای رسمی SL و TP" to "https://help.trendo.com/portal/fa/kb/articles/trendo-take-profit-stop-loss-guide",
        "تمرین بازپخش بدون معامله" to "https://help.trendo.com/portal/fa/kb/articles/trendo-replay-mode-guide"
    )
    CardBlock {
        Text("ادامهٔ یادگیری", fontWeight = FontWeight.Bold)
        Text("متن و تصاویر ارسالی کانال خلاصه شده‌اند؛ ویدئوهای پیوست در اختیار برنامه نبوده‌اند. برای جزئیات به راهنمای رسمی بروکر مراجعه کن.")
        sources.forEach { (title, url) -> TextButton(onClick = { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { error = "مرورگر برای بازکردن راهنما پیدا نشد" } }) { Text(title) } }
        if (error.isNotBlank()) Text(error)
    }
}
