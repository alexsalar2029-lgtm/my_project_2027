package app.lordxau.mobile

import kotlin.math.abs

/** Educational state only: deliberately has no Context, Python, network or broker. */
internal data class PracticeSession(
    val scenario: String = "buy", val phase: Int = 0,
    val remaining: Double = .02, val stop: Double = 3906.0,
    val feedback: String = "", val closedBy: String = "", val realized: Double = 0.0
) {
    val sell get() = scenario == "sell"
    val direction get() = if (sell) "SELL" else "BUY"
    val fill get() = if (sell) 3907.8 else 3908.2
    val initialStop get() = if (sell) 3910.0 else 3906.0
    val target get() = if (sell) 3904.0 else 3912.0
    val freeStop get() = if (sell) fill - .3 else fill + .3
    val quote get() = when {
        phase < 2 -> 3908.0
        scenario == "stop" -> initialStop
        scenario == "free_hit" && phase >= 3 -> freeStop
        else -> if (sell) 3906.2 else 3910.2
    }
    private fun profit(volume: Double) = (quote - fill) * (if (sell) -1 else 1) * volume * 100
    val floating get() = if (phase in 2..4) profit(remaining) else 0.0
    val balance get() = 1000 + realized
    val equity get() = balance + floating
    val message get() = when (phase) {
        0, 1 -> "XAUUSD $direction\nEnter: 3908   Stop: $initialStop   TP: $target"
        2 -> if (scenario == "stop") "استاپ خورد" else "سوده، فری کن"
        3, 4 -> if (scenario == "free_hit") "فری خورد" else "ببندش"
        else -> "پایان تمرین؛ بدون دستور جدید دوباره وارد نشو."
    }
    val hint get() = when (phase) {
        0 -> "اول حساب آزمایشی را انتخاب کن. این تمرین فقط پول فرضی دارد."
        1 -> "روی طلا بمان. حجم نمونه دو صدم لات است. استاپ $initialStop و تارگت $target را وارد کن و دکمهٔ ${if (sell) "فروش" else "خرید"} را بزن."
        2 -> if (scenario == "stop") "استاپ خورد گزارش خروج است، دستور ورود تازه نیست. در تاریخچه تأیید کن حجم باز صفر شده است."
             else "ورود واقعی تو $fill است. فری کن یعنی استاپ خرید سه پیپ بالاتر، و استاپ فروش سه پیپ پایین‌تر از ورود خودت باشد. اینجا $freeStop را در تغییر استاپ ثبت کن."
        3 -> if (scenario == "free_hit") "فری خورد یعنی قیمت به استاپ منتقل‌شده برگشته است. بسته‌شدن معامله را در تاریخچه بررسی کن. بدون دستور جدید باز نکن."
             else "ببندش یعنی خروج کامل از همین معامله. حجم باقی‌مانده را ببین؛ بعد از درخواست، تأیید را هم انجام بده."
        4 -> "اکنون تأیید بستن همین سفارش را بزن. صرف لمس بستن کافی نبود."
        else -> "حجم باز صفر است. در معاملهٔ واقعی هزینه و لغزش هم بر نتیجه اثر می‌گذارند. می‌توانی سناریوی بعدی را تمرین کنی."
    }
    fun wallet(demo: Boolean) = if (phase != 0) this else if (demo) copy(phase = 1, feedback = "حساب تمرینی انتخاب شد؛ حالا فرم سفارش را پر کن.")
        else copy(feedback = "برای یادگیری حساب آزمایشی را بزن؛ اینجا حساب واقعی وجود ندارد.")
    fun order(side: String, symbol: String, lots: Double, sl: Double, tp: Double): PracticeSession {
        if (phase != 1) return this
        val error = when {
            symbol != "XAUUSD" -> "GOLD همان XAUUSD است؛ سیگنال طلا را در EURUSD وارد نکن."
            side != direction -> "جهت پیام $direction است. ${if (sell) "فروش" else "خرید"} را انتخاب کن."
            !lots.isFinite() || abs(lots - .02) > .000001 -> "حجم این تمرین ۰٫۰۲ لات است؛ حجم زیاد، سود و زیان را با هم بزرگ می‌کند."
            !sl.isFinite() || abs(sl - initialStop) > .001 -> "Stop یعنی حد ضرر؛ مقدار $initialStop را از پیام در حد ضرر وارد کن."
            !tp.isFinite() || abs(tp - target) > .001 -> "TP یعنی حد سود؛ مقدار $target را در حد سود وارد کن."
            else -> null
        }
        return if (error != null) copy(feedback = error) else copy(phase = 2, stop = initialStop,
            feedback = "اجرای فرضی تأیید شد؛ ورود تو $fill است، نه 3908 نوشته‌شده در پیام.")
    }
    fun free(value: Double): PracticeSession {
        if (phase != 2 || scenario == "stop") return this
        return if (!value.isFinite() || abs(value - freeStop) > .001) copy(feedback = "ورود خودت $fill است؛ استاپ درست این تمرین $freeStop است. استاپ را بزرگ‌تر نکن.")
        else copy(phase = 3, stop = value, feedback = "تغییر استاپ در شبیه‌ساز تأیید شد؛ فری به معنی تضمین صفرشدن زیان واقعی نیست.")
    }
    fun close(half: Boolean): PracticeSession {
        if (phase != 3 || scenario == "free_hit") return this
        return if (half && remaining > .010001) copy(remaining = .01, realized = realized + profit(remaining - .01), feedback = "فقط ۰٫۰۱ لات بسته شد؛ هنوز ۰٫۰۱ لات باز است. دستور «ببندش» خروج کامل می‌خواهد.")
        else copy(phase = 4, feedback = "درخواست خروج آماده است؛ تأیید نهایی را بزن.")
    }
    fun confirmClose() = if (phase == 4) copy(phase = 5, remaining = 0.0, realized = realized + profit(remaining), closedBy = "دستور بستن", feedback = "خروج فرضی تأیید شد؛ حجم باز صفر است.") else this
    fun checkHistory(): PracticeSession = when {
        phase == 2 && scenario == "stop" -> copy(phase = 5, remaining = 0.0, realized = realized + profit(remaining), closedBy = "حد ضرر", feedback = "خروج با حد ضرر در تاریخچهٔ تمرینی ثبت است. این پیام مجوز ورود دوباره نیست.")
        phase == 3 && scenario == "free_hit" -> copy(phase = 5, remaining = 0.0, realized = realized + profit(remaining), closedBy = "استاپ فری", feedback = "خروج با استاپ منتقل‌شده ثبت است. برای ورود بعدی دستور تازه لازم است.")
        else -> this
    }
    fun reenter() = copy(feedback = "«استاپ خورد» و «فری خورد» گزارش‌اند؛ بدون دستور تازه، معاملهٔ جدید باز نکن.")
}
