package app.lordxau.mobile
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.dp

@Composable fun PaperPractice() {
    var price by remember { mutableIntStateOf(100) }
    var entry by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    CardBlock {
        Text("🦁 آزمایشگاه پول مجازی", style = MaterialTheme.typography.titleLarge)
        Text("برای یادگیری از صفر؛ قیمت‌ها ساختگی‌اند و هیچ ارتباطی با حساب یا بازار زنده ندارند. برای کاربران کم‌سن، تمرین در همین محیط مجازی انجام می‌شود.")
        Text("قیمت فرضی: $price • امتیاز تمرینی: $score")
        Text(if (entry == null) "هنوز خرید تمرینی باز نکرده‌ای." else "ورود: $entry • تغییر قیمت: ${price - entry!!} واحد فرضی")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { price -= 1 }) { Text("قیمت −۱") }
            OutlinedButton(onClick = { price += 1 }) { Text("قیمت +۱") }
        }
        Button(onClick = { if (entry == null) entry = price else { score += price - entry!!; entry = null } }) { Text(if (entry == null) "خرید با پول مجازی" else "بستن خرید تمرینی") }
        Text("اگر بعد از خرید قیمت بالا برود، تفاوت مثبت می‌شود؛ اگر پایین برود، زیان فرضی داری. در بازار واقعی هزینه و لغزش هم وجود دارد. این مثال توصیهٔ خرید نیست.")
        TextButton(onClick = { price = 100; entry = null; score = 0 }) { Text("شروع دوبارهٔ تمرین") }
    }
}
