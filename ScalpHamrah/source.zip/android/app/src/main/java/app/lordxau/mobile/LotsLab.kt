package app.lordxau.mobile

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import java.util.Locale

@Composable internal fun LotsLab(reduced: Boolean) {
    var selected by rememberSaveable { mutableIntStateOf(0) }
    val sizes = listOf(.01, .1, 1.0)
    val lots = sizes[selected]
    val amount by animateFloatAsState(lots.toFloat(), tween(if (reduced) 0 else 700), label = "lots-size")
    CardBlock {
        Text("لات یعنی اندازهٔ معامله", style = MaterialTheme.typography.titleLarge)
        Text("روی یک حجم بزن و تفاوت را ببین. این مثال: هر ۱ لات طلا = ۱۰۰ اونس.")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            sizes.forEachIndexed { i, n -> FilterChip(selected = i == selected, onClick = { selected = i },
                label = { Text("$n لات") }, modifier = Modifier.testTag("lot-$i")) }
        }
        LinearProgressIndicator(progress = { amount }, modifier = Modifier.fillMaxWidth().height(14.dp))
        Text("اندازهٔ فرضی: %.0f اونس طلا".format(Locale.US, lots * 100), modifier = Modifier.testTag("lot-ounces"))
        Text("اگر قیمت ۲ دلار به ضررت حرکت کند:")
        Text("زیان نظری: %.2f دلار".format(Locale.US, lots * 100 * 2), color = Color(0xFFFFABAB),
            style = MaterialTheme.typography.headlineSmall, modifier = Modifier.testTag("lot-risk"))
        Text("لات با دلار یا پیپ یکی نیست. ۰٫۱ لات، ده برابر ۰٫۰۱ لات است؛ اثر حرکت قیمت هم ده برابر می‌شود.")
        Text("این حساب قبل از هزینه و لغزش است. اندازهٔ قرارداد و حداقل حجم را از نماد بروکر بخوان؛ حجم مناسب فقط از روی موجودی تعیین نمی‌شود.", style = MaterialTheme.typography.bodySmall)
    }
}
