package app.lordxau.mobile

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

private val Teal = Color(0xFF34D3AA)
private val Blue = Color(0xFF369FFF)
private val Red = Color(0xFFFF686D)
private val Muted = Color(0xFF9AA8B8)
private data class VisualStep(val title: String, val caption: String, val focus: String)
private data class VisualCourse(val id: String, val icon: String, val name: String, val steps: List<VisualStep>)
private val courses = listOf(
    VisualCourse("wallet", "◉", "انتخاب حساب", listOf(
        VisualStep("۱. منوی ترندو", "منوی سه‌خط بالای ترندو را باز کن؛ فلش کنار حساب را لمس کن.", "menu"),
        VisualStep("۲. حساب آزمایشی", "برای تمرین، ردیف «آزمایشی» را انتخاب کن. بونوس و کیف پول، همان حساب دمو نیستند.", "demo"),
        VisualStep("۳. عنوان حساب", "پیش از معامله، عنوان آزمایشی و شناسهٔ حساب فعال را ببین. انتخاب LionXsec هم باید همین حساب باشد.", "selected")
    )),
    VisualCourse("market", "↗", "بازکردن سیگنال", listOf(
        VisualStep("۱. نماد طلا", "در خانهٔ ترندو GOLD را باز کن؛ نماد سفارش باید XAUUSD باشد.", "symbol"),
        VisualStep("۲. نوع سفارش", "برای Buy now یا Sell now، نوع اجرا «در قیمت بازار» است. لیمیت یعنی انتظار در قیمت مشخص.", "type"),
        VisualStep("۳. حجم", "حجم را از بودجهٔ ریسک و فاصلهٔ استاپ حساب کن. ۰٫۰۱ این تصویر فقط مثال است.", "volume"),
        VisualStep("۴. حد ضرر", "Stop یا SL، قیمت حد ضرر است. برای خرید نمونهٔ ۳۹۰۸، استاپ فرضی ۳۹۰۶ پایین‌تر از ورود است.", "sl"),
        VisualStep("۵. حد سود", "TP قیمت هدف است؛ مبلغ سود نیست. مثال خرید: ورود ۳۹۰۸ و هدف ۳۹۱۲.", "tp"),
        VisualStep("۶. خرید یا فروش", "جهت را با متن پیام تطبیق بده؛ سپس حساب، حجم و استاپ را بازبینی کن. لمس این آموزش سفارش نمی‌فرستد.", "buy"),
        VisualStep("۷. ورود واقعی", "بعد از اجرا، قیمت پرشدن و SL پذیرفته‌شده را در معامله بخوان؛ عدد پیام کانال لزوماً قیمت ورود تو نیست.", "filled")
    )),
    VisualCourse("limit", "⌛", "سفارش لیمیت", listOf(
        VisualStep("۱. سفارش در انتظار", "مثال خرید در ۳۹۰۰؛ قیمت فعلی ۳۹۰۸ است. این سفارش تا رسیدن شرط قیمت، معاملهٔ باز نیست.", "type"),
        VisualStep("۲. قیمت ورود Enter", "Buy Limit را انتخاب کن و Enter نمونه، یعنی ۳۹۰۰ را در قیمت سفارش بنویس.", "entry"),
        VisualStep("۳. حد ضرر و حجم", "برای خرید فرضی ۳۹۰۰، SL نمونه ۳۸۹۸ است؛ حجم را با فاصلهٔ همین استاپ حساب کن.", "sl"),
        VisualStep("۴. هدف و ثبت", "TP نمونه ۳۹۱۰ است. پس از بازبینی، ثبت می‌کنی؛ هنوز باید وضعیت سفارش در انتظار را بررسی کنی.", "tp")
    )),
    VisualCourse("free", "◇", "فری کردن استاپ", listOf(
        VisualStep("۱. ورود خودت", "مرجع، قیمت واقعی ورود خودت است. مثال فرضی: ۳۹۰۸؛ استاپ اولیهٔ خرید ۳۹۰۶.", "entry"),
        VisualStep("۲. حرکت به سود", "مدیر کانال می‌گوید پس از ۱ تا ۲ واحد حرکت به سود، استاپ را بررسی کن؛ منتظر پیام بعدی نمان.", "profit"),
        VisualStep("۳. استاپ روی ورود", "در معاملهٔ درست، «تغییر» را بزن و SL را روی ورود واقعی تنظیم کن؛ فقط اگر قیمت فعلی و فاصلهٔ مجاز بروکر اجازه می‌دهد.", "entryStop"),
        VisualStep("۴. مثال سه پیپ", "در قرارداد لفظی کانال، ۳ پیپ = ۰٫۳ واحد: خرید ۳۹۰۸ → SL ۳۹۰۸٫۳. برای فروش: SL ۳۹۰۷٫۷.", "buffer"),
        VisualStep("۵. تأیید بروکر", "SL ذخیره‌شده را دوباره ببین. «فری» تضمین نبود زیان نیست؛ کارمزد، اسپرد و لغزش باقی می‌مانند.", "verified")
    )),
    VisualCourse("close", "×", "بستن کامل معامله", listOf(
        VisualStep("۱. سفارش هدف", "شناسه و حجم همان معامله را پیدا کن. «بستن همه» با بستن یک معامله فرق دارد.", "position"),
        VisualStep("۲. بستن", "دکمهٔ بستن را بزن؛ هنوز خروج کامل تأیید نشده است.", "close"),
        VisualStep("۳. تأیید دوم", "اگر ترندو تأیید دوم نشان داد، همان درخواست را تأیید کن و پاسخ را بررسی کن.", "confirm"),
        VisualStep("۴. پیگیری حجم باقی‌مانده", "از ۰٫۰۲ لات، اگر ۰٫۰۱ باقی مانده، معامله هنوز باز است؛ نتیجه را «خروج کامل» حساب نکن.", "remaining"),
        VisualStep("۵. خروج تأییدشده", "حجم باز همان سفارش صفر و خروج در تاریخچه تأیید شده است؛ اکنون این سناریوی فرضی تمام است.", "closed")
    )),
    VisualCourse("terms", "Aa", "واژه‌های سیگنال", listOf(
        VisualStep("۱. جهت معامله", "Buy یعنی خرید: حرکت صعودی به نفع معامله است. Sell یعنی فروش: حرکت نزولی به نفع آن است.", "side"),
        VisualStep("۲. ورود و استاپ", "Enter یعنی قیمت یا ناحیهٔ ورود. Stop یا SL یعنی قیمت حد ضرر؛ مبلغ زیان دلاری نیست.", "entry"),
        VisualStep("۳. هدف قیمت", "TP یعنی قیمت هدف برای دریافت سود. سود خالص به حجم، قیمت اجرا و هزینه‌ها وابسته است.", "tp")
    )),
    VisualCourse("delay", "◷", "اختلاف زمان ورود", listOf(
        VisualStep("۱. رسیدن پیام", "پیام کانال و قیمت روی گوشی هم‌زمان نیستند؛ سرعت اینترنت و زمان ارسال اثر دارند.", "message"),
        VisualStep("۲. پیشنهاد مدیر کانال", "مدیر پیشنهاد می‌کند ۵ تا ۱۰ ثانیه بعد از پیام صبر کنی؛ این فقط روش پیشنهادی اوست، تضمین یکسان‌شدن ورود نیست.", "wait"),
        VisualStep("۳. قیمت را دوباره ببین", "پس از انتظار، قیمت و استاپ را دوباره بررسی کن. این آموزش تأخیر اجباری به ربات اضافه نمی‌کند.", "compare")
    )),
    VisualCourse("oldstop", "⊘", "استاپ را دور نکن", listOf(
        VisualStep("۱. معاملهٔ قبلی", "اگر فریِ مدیر خورده ولی معاملهٔ تو هنوز باز است، مرجع تو ورود و استاپ همان معامله است.", "old"),
        VisualStep("۲. ورود جدید، معاملهٔ جدید", "استاپ قبلی را با ورود سیگنال جدید عوض نکن؛ دو معامله را با شناسه از هم جدا کن.", "new"),
        VisualStep("۳. زیان را بزرگ نکن", "دورکردن استاپ، زیان احتمالی را بیشتر می‌کند. استاپ قبلی را برای فرار از زیان بزرگ نکن.", "keep")
    )),
    VisualCourse("cost", "$", "۲۰ پیپ چند دلار؟", listOf(
        VisualStep("۱. معنی پیپ کانال", "در مثال مدیر: ۲۰ پیپ = ۲ واحد قیمت طلا؛ تعریف پیپ بین بروکرها یکسان نیست.", "pip"),
        VisualStep("۲. حجم و زیان", "با فرض ۱۰۰ اونس در هر لات: زیان نظری = ۲ × ۱۰۰ × لات. حجم را لمس کن و تغییر عدد را ببین.", "cost"),
        VisualStep("۳. هزینه‌های اجرا", "این عدد قبل از کارمزد و لغزش است. قرارداد واقعی نماد را بررسی کن؛ استاپ سقف قطعی زیان نیست.", "fees")
    )),
    VisualCourse("table", "%", "جدول حجم کانال", listOf(
        VisualStep("۱. مثال‌های مدیر", "موجودی نمونه را انتخاب کن؛ حجم گفته‌شدهٔ مدیر و ریسک نظری آن نمایش داده می‌شود.", "table"),
        VisualStep("۲. موجودی تنها کافی نیست", "این جدول توصیهٔ خودکار حجم نیست. فاصلهٔ استاپ و هزینه‌ها را هم حساب کن؛ تمرین محاسبه در بخش تمرین است.", "risk")
    ))
)

@Composable fun VisualAcademy(reduced: Boolean, trendo: Boolean) {
    var opened by rememberSaveable { mutableStateOf<String?>(null) }
    Text(if (trendo) "آموزش متحرک ترندو" else "ببین، لمس کن، یاد بگیر", fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Text("هر درس: یک تصویر، یک کار • تمرین بدون پول واقعی", color = Muted)
    val list = courses.filter { if (trendo) it.id in listOf("wallet", "market", "limit", "free", "close") else it.id in listOf("terms", "delay", "free", "oldstop", "cost", "table") }
    list.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { course ->
                Surface(onClick = { opened = course.id }, color = Color(0xFF172434), shape = RoundedCornerShape(20.dp), modifier = Modifier.weight(1f).heightIn(min = 138.dp).testTag("visual-${course.id}")) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(course.icon, fontSize = 32.sp, color = Teal)
                        Text(course.name, fontWeight = FontWeight.Bold)
                        Text("${course.steps.size} تصویر  ›", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
    Text("بازسازی آموزشی از تصاویر و متن ارسالی؛ اعداد فرضی‌اند و هیچ لمس این بخش معامله نمی‌فرستد.", color = Muted, style = MaterialTheme.typography.bodySmall)
    opened?.let { id -> VisualPlayer(courses.first { it.id == id }, reduced) { opened = null } }
}

@Composable private fun VisualPlayer(course: VisualCourse, reduced: Boolean, onClose: () -> Unit) {
    var step by rememberSaveable(course.id) { mutableIntStateOf(0) }
    var playing by rememberSaveable(course.id) { mutableStateOf(false) }
    var sell by rememberSaveable { mutableStateOf(false) }
    var amount by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(playing, step, reduced) {
        if (playing && !reduced) { delay(6500); if (step < course.steps.lastIndex) step++ else playing = false }
    }
    val s = course.steps[step]
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF0A111B)) {
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(course.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onClose, modifier = Modifier.testTag("visual-dismiss")) { Text("بستن درس ×") }
                }
                LinearProgressIndicator(progress = { (step + 1f) / course.steps.size }, color = Teal, modifier = Modifier.fillMaxWidth())
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("${step + 1} / ${course.steps.size}   •   مثال آموزشی", color = Muted, fontSize = 12.sp)
                    if (course.id == "free") Row {
                        FilterChip(!sell, { sell = false }, label = { Text("خرید BUY") })
                        Spacer(Modifier.width(10.dp))
                        FilterChip(sell, { sell = true }, label = { Text("فروش SELL") })
                    }
                    if (reduced || course.id == "free") VisualScene(course.id, s.focus, step, sell, amount, { amount = it }, reduced)
                    else AnimatedContent(targetState = step, label = "visual-scene") { index -> VisualScene(course.id, course.steps[index].focus, index, sell, amount, { amount = it }, false) }
                    Text(s.title, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.testTag("lesson-title"))
                    Text(s.caption, lineHeight = 27.sp, fontSize = 16.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { playing = false; step = if (step == course.steps.lastIndex) 0 else step + 1 }, modifier = Modifier.weight(1f).testTag("lesson-next")) { Text(if (step == course.steps.lastIndex) "دوباره ببین" else "تصویر بعد  ←") }
                    OutlinedButton(onClick = { playing = false; step-- }, enabled = step > 0) { Text("قبلی") }
                }
                TextButton(onClick = { playing = !playing }, enabled = !reduced && step < course.steps.lastIndex, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text(if (playing) "توقف پخش" else if (reduced) "نمایش ثابت؛ حرکت خاموش است" else "▷ پخش خودکار تصاویر") }
            }
        }
    }
}

@Composable private fun VisualScene(id: String, focus: String, step: Int, sell: Boolean, amount: Int, onAmount: (Int) -> Unit, reduced: Boolean) {
    Surface(color = Color(0xFF111715), shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, Color(0xFF34423F)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("ترندو • نمونهٔ آموزشی", color = Teal, fontSize = 12.sp); Text("☰", color = Muted) }
            when (id) {
                "wallet" -> {
                    Text("حساب‌های نمونه", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    SceneRow("بونوس", "نمونه A", false, reduced)
                    SceneRow("کیف پول", "نمونه B", false, reduced)
                    SceneRow("واقعی", "نمونه C  •  EUR", false, reduced)
                    SceneRow("آزمایشی", "نمونه D  •  EUR", focus != "menu", reduced)
                    if (focus == "selected") Text("✓ حساب فعال: آزمایشی D", color = Teal, fontWeight = FontWeight.Bold)
                    else Text("⌄  فهرست حساب‌ها", color = Muted)
                }
                "terms" -> {
                    Text("BUY  ↑     SELL  ↓", fontSize = 29.sp, fontWeight = FontWeight.Bold, color = Blue)
                    SceneRow("TP — هدف بالاترِ خرید", "3912", focus == "tp", reduced)
                    SceneRow("Enter — ورود نمونه", "3908", focus == "entry", reduced)
                    SceneRow("Stop — حد ضرر خرید", "3906", focus == "entry", reduced)
                    Text("در فروش، جهت هدف و استاپ برعکس است.", color = Muted)
                }
                "market", "limit" -> {
                    SceneRow("XAUUSD", "🟨 GOLD", focus == "symbol", reduced)
                    SceneRow("حجم", "−       0.01       +", focus == "volume", reduced)
                    SceneRow("نوع اجرا", if (id == "limit") "Buy Limit  ⌄" else "قیمت بازار  ⌄", focus == "type", reduced)
                    if (id == "limit") SceneRow("قیمت Enter", "3900.00", focus == "entry", reduced)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("ASK 3908.00", color = Blue); Text("BID 3907.90", color = Red) }
                    SceneRow("حد سود TP", if (id == "limit") "3910.00" else "3912.00", focus == "tp", reduced)
                    SceneRow("حد ضرر SL", if (id == "limit") "3898.00" else "3906.00", focus == "sl", reduced)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(color = Blue, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) { Text(if (id == "limit") "ثبت انتظار" else if (focus == "buy") "☝ خرید" else "خرید", Modifier.padding(15.dp), fontWeight = FontWeight.Bold) }
                        Surface(color = Red.copy(alpha = .75f), shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) { Text("فروش", Modifier.padding(15.dp), fontWeight = FontWeight.Bold) }
                    }
                    if (focus == "filled") Text("✓ ورود تأییدشدهٔ نمونه: 3908.10\nSL پذیرفته‌شده: 3906.00", color = Teal)
                }
                "free" -> {
                    Text(if (sell) "SELL  •  ورود 3908" else "BUY  •  ورود 3908", fontSize = 22.sp, color = if (sell) Red else Blue, fontWeight = FontWeight.Bold)
                    val dest = when (step) { 0, 1 -> if (sell) .18f else .82f; 2 -> .5f; else -> if (sell) .58f else .42f }
                    val y by animateFloatAsState(dest, tween(if (reduced) 0 else 1100), label = "stop move")
                    Canvas(Modifier.fillMaxWidth().height(180.dp).testTag("stop-chart")) {
                        for (i in 1..4) drawLine(Color(0xFF2B3538), Offset(0f, size.height*i/5), Offset(size.width, size.height*i/5), 1f)
                        val values = if (sell) listOf(.45f,.4f,.56f,.51f,.7f,.76f,.73f,.88f) else listOf(.55f,.6f,.44f,.49f,.30f,.24f,.27f,.12f)
                        values.zipWithNext().forEachIndexed { i, pair -> drawLine(Teal, Offset(size.width*i/7, size.height*pair.first), Offset(size.width*(i+1)/7,size.height*pair.second),5f,StrokeCap.Round) }
                        drawLine(Blue, Offset(0f,size.height*.5f),Offset(size.width,size.height*.5f),3f)
                        drawLine(if(step<2) Red else Teal,Offset(0f,size.height*y),Offset(size.width,size.height*y),5f)
                        drawCircle(if(step<2) Red else Teal,9f,Offset(size.width*.85f,size.height*y))
                    }
                    SceneRow("ورود خودت — خط آبی", "3908.00", focus == "entry", reduced)
                    val stop = if (step < 2) (if (sell) "3910.00" else "3906.00") else if (step == 2) "3908.00" else if (sell) "3907.70" else "3908.30"
                    SceneRow("حد ضرر — خط متحرک", stop, step >= 2, reduced)
                    Text(if (step == 4) "✓ پاسخ فرضی بروکر: SL ثبت شد" else "↑ حرکت استاپ را ببین", color = Teal, fontSize = 13.sp)
                }
                "close" -> {
                    Text("GOLD  •  BUY", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("شناسهٔ نمونه: A123", color = Muted)
                    SceneRow("حجم باز", when (focus) { "closed" -> "0.00"; "remaining" -> "0.01"; else -> "0.02" }, focus in listOf("remaining", "closed"), reduced)
                    if (focus == "closed") { Text("✓", color = Teal, fontSize = 58.sp); Text("خروج کامل در تاریخچه", color = Teal) }
                    else {
                        SceneRow("همین معامله", "بستن ×", focus == "close", reduced)
                        if (focus == "confirm") SceneRow("مرحلهٔ دوم", "تأیید خروج", true, reduced)
                        if (focus == "remaining") Text("۰٫۰۱ از ۰٫۰۲ بسته شد\n۰٫۰۱ هنوز باز است", color = Red, fontWeight = FontWeight.Bold)
                    }
                }
                "delay" -> {
                    SceneRow("پیام کانال", "BUY NOW", focus == "message", reduced)
                    Text(if (focus == "wait") "۵  …  ۱۰" else "◷", fontSize = 58.sp, color = Teal)
                    Text("ثانیهٔ انتظارِ پیشنهادی مدیر", color = Muted)
                    SceneRow("قیمت زمان پیام", "3908.00", false, reduced)
                    SceneRow("قیمت بعد از انتظار", "3909.20 ؟", focus == "compare", reduced)
                    Text("زمان برابر ≠ قیمت برابر", color = Red)
                }
                "oldstop" -> {
                    Text("دو معامله، دو شناسه", fontSize = 21.sp)
                    SceneRow("معاملهٔ قبلی A", "ورود 3908", focus == "old", reduced)
                    SceneRow("استاپ قبلی A", "3906  ✓", focus == "keep", reduced)
                    SceneRow("معاملهٔ جدید B", "ورود 3904", focus == "new", reduced)
                    Text("×  انتقال استاپ A به 3904", color = Red, fontSize = 20.sp)
                    Text("استاپ دورتر = زیان بالقوهٔ بیشتر", color = Muted)
                }
                "cost" -> {
                    val lots = listOf(.01, .1, 1.0, 10.0, 100.0)
                    val lot = lots[amount.coerceIn(0,4)]
                    Text("۲۰ پیپِ کانال = ۲ واحد", fontWeight = FontWeight.Bold, fontSize = 21.sp)
                    Text("حجم نمونه را لمس کن", color = Muted)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        lots.forEachIndexed { i, value -> FilterChip(amount == i, { onAmount(i) }, label = { Text("$value") }) }
                    }
                    Text("${formatValue(200*lot)} USD", color = if(lot >= 1) Red else Teal, fontSize = 39.sp, fontWeight = FontWeight.Bold)
                    Text("زیان نظری تا استاپ", color = Muted)
                    SceneRow("۲ × ۱۰۰ × لات", "$lot lot", true, reduced)
                    Text("فرض: ۱۰۰ اونس/لات • بدون هزینه‌ها", fontSize = 12.sp, color = Muted)
                }
                "table" -> {
                    val balances = listOf(50,100,200,500,1000,2000,5000,10000,20000,50000,100000)
                    val lots = listOf(.01,.01,.01,.01,.05,.05,.05,.2,.2,.4,1.0)
                    val i = amount.coerceIn(0,10)
                    Text("جدول ارسالی مدیر کانال", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        balances.forEachIndexed { index, b -> FilterChip(i == index, { onAmount(index) }, label = { Text(if(index == 0) "زیر 100" else "$b") }) }
                    }
                    SceneRow("موجودی نمونه USD", "${balances[i]}", false, reduced)
                    SceneRow("حجم جدول", "${lots[i]} lot", true, reduced)
                    val risk = 200*lots[i]
                    Text("${formatValue(risk)} USD", color = if (risk/balances[i] >= .02) Red else Teal, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    Text("حدود ${formatValue(risk/balances[i]*100)}٪ با استاپ ۲ واحدی", color = Muted)
                    Text("نمونهٔ زیر ۱۰۰، با موجودی ۵۰ محاسبه شده. فرض ۱۰۰ اونس/لات؛ هزینه‌ها جدا.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}
private fun formatValue(value: Double) = String.format(java.util.Locale.US, "%.2f", value)

@Composable private fun SceneRow(label: String, value: String, focused: Boolean, reduced: Boolean) {
    val transition = rememberInfiniteTransition(label = "focus pointer")
    val pulse by transition.animateFloat(.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pointer")
    Surface(color = if (focused) Color(0xFF123C32) else Color(0xFF1B211F), shape = RoundedCornerShape(12.dp), border = if (focused) BorderStroke(2.dp, Teal) else null, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = if (focused) Teal else Color.White)
            if (focused) Text("  ☜", fontSize = 24.sp, color = Teal.copy(alpha = if (reduced) 1f else pulse))
        }
    }
}
