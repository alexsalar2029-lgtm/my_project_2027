package app.lordxau.mobile

import android.content.Intent
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay

@Composable internal fun BackgroundPanel(onError: (String) -> Unit) {
    val context = LocalContext.current
    var exempt by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            exempt = context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)
            delay(2_000)
        }
    }
    CardBlock {
        Text("هنگام خاموش بودن صفحه", style = MaterialTheme.typography.titleLarge)
        Text(if (exempt) "محدودیت بهینه‌سازی باتری برای این برنامه برداشته شده است." else "بهینه‌سازی باتری هنوز فعال است؛ ممکن است دریافت پیام در خواب گوشی عقب بیفتد.")
        OutlinedButton(onClick = {
            runCatching { context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                .onFailure { onError("تنظیمات باتری باز نشد؛ آن را از تنظیمات گوشی باز کن.") }
        }) { Text("تنظیم اجرای پس‌زمینه") }
        Text("در تنظیمات گوشی برای LionXsec باتری را روی «بدون محدودیت» بگذار. در Redmi مجوز شروع خودکار را هم بررسی کن. اینترنت و VPN تلگرام باید هنگام قفل‌بودن روشن بمانند.")
        Text("قفل صفحه مانع اتصال مستقیم موتور به بروکر نیست. اندروید می‌تواند سرویس را متوقف کند؛ در Android 15+ این نوع سرویس پس‌زمینه مهلت مجموع ۶ ساعت در ۲۴ ساعت دارد. اجرای دائمی تضمین نمی‌شود.", style = MaterialTheme.typography.bodySmall)
    }
}
