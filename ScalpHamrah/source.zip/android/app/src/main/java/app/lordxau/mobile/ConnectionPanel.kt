package app.lordxau.mobile

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@Composable internal fun ConnectionPanel(vault: SecureSettings, reduced: Boolean, onReduced: (Boolean) -> Unit, onNotice: (String) -> Unit, onError: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val saved = remember { runCatching { JSONObject(vault.config()) }.getOrDefault(JSONObject()) }
    var stage by rememberSaveable { mutableIntStateOf(0) }
    var apiId by remember { mutableStateOf(saved.optString("api_id")) }
    var hash by remember { mutableStateOf(saved.optString("api_hash")) }
    var phone by remember { mutableStateOf(saved.optString("phone")) }
    var user by remember { mutableStateOf(saved.optString("broker_username")) }
    var password by remember { mutableStateOf(saved.optString("broker_password")) }
    var real by remember { mutableStateOf(saved.optBoolean("real_wallet")) }
    var walletId by remember { mutableStateOf(saved.optString("wallet_id")) }
    var currency by remember { mutableStateOf(saved.optString("wallet_currency", "USD")) }
    var risk by remember { mutableStateOf(saved.optString("risk_pct", "2")) }
    var limit by remember { mutableStateOf(saved.optString("max_daily_loss", "8")) }
    var code by remember { mutableStateOf("") }
    var twofa by remember { mutableStateOf("") }
    var wallets by remember { mutableStateOf(JSONArray()) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    var failed by remember { mutableStateOf(false) }
    val active by LocalEngine.serviceActive.collectAsState()
    fun draft(): JSONObject {
        require(!active) { "ابتدا موتور را متوقف کنید" }
        val r = lessonNumber(risk); val l = lessonNumber(limit)
        require(r.isFinite() && r in .01..5.0 && l.isFinite() && l in .01..100000.0) { "ریسک بین ۰٫۰۱ تا ۵ درصد و سقف روزانه مثبت باشد" }
        return JSONObject().put("storage_dir", ctx.filesDir.absolutePath)
            .put("api_id", apiId.map { if (it.isDigit()) Character.getNumericValue(it).toString() else it.toString() }.joinToString("").trim())
            .put("api_hash", hash.trim()).put("phone", phone.trim())
            .put("broker_username", user.trim()).put("broker_password", password)
            .put("wallet_id", walletId).put("wallet_currency", currency).put("real_wallet", real)
            .put("risk_pct", r).put("max_daily_loss", l)
            .put("execution_mode", if (vault.automatic) "automatic" else "manual")
    }
    fun save() { vault.saveConfig(draft().toString()) }
    fun action(name: String) {
        scope.launch {
            busy = true; result = ""; failed = false
            try {
                save()
                val reply = if (name == "verify_code") LocalEngine.call(ctx, name, code, twofa)
                    else LocalEngine.call(ctx, name, draft().toString())
                when (name) {
                    "list_wallets" -> { wallets = reply.optJSONArray("wallets") ?: JSONArray(); result = if (wallets.length() == 0) "ترندو هیچ حسابی برنگرداند؛ ایجاد حساب را در خود ترندو بررسی کنید." else "حساب‌ها دریافت شد؛ روی حساب موردنظر بزن." }
                    "request_code" -> result = if (reply.optBoolean("authorized")) "قبلاً وارد شده‌ای؛ حالا بررسی کانال را بزن." else "کد ارسال شد؛ پیام ورود را در تلگرام بررسی کن."
                    "verify_code" -> {
                        result = if (reply.optBoolean("password_required")) "رمز دومرحله‌ای لازم است؛ آن را وارد و تأیید ورود را بزن." else if (reply.optBoolean("authorized")) "ورود تأیید شد؛ حالا بررسی کانال را بزن." else "ورود هنوز تأیید نشده است."
                        if (reply.optBoolean("authorized")) { code = ""; twofa = "" }
                    }
                    else -> result = reply.optString("notice", "عملیات انجام شد")
                }
            } catch (e: Exception) { result = e.message ?: "این مرحله انجام نشد"; failed = true }
            finally { busy = false }
        }
    }
    Text("اتصال، قدم به قدم", fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("۱ تلگرام", "۲ حساب ترندو", "۳ اجرای گوشی").forEachIndexed { i, label ->
            FilterChip(selected = stage == i, onClick = { stage = i; result = "" }, enabled = !busy, label = { Text(label) }, modifier = Modifier.testTag("setup-$i"))
        }
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    if (result.isNotBlank()) CardBlock { Text(result, color = if (failed) Color(0xFFFFABAB) else Color(0xFF77DECE), modifier = Modifier.testTag("setup-result")) }
    if (active) Text("موتور فعال است؛ برای ویرایش اتصال ابتدا در خانه توقف را بزن.")
    when (stage) {
        0 -> CardBlock {
            Text("تلگرامِ خودت را وارد کن", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("نصب بودن تلگرام کافی نیست؛ این اتصال ورود جداگانه می‌خواهد.", style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://my.telegram.org/apps"))) }.onFailure { onError("مرورگر پیدا نشد") } }) { Text("گرفتن API ID و Hash از سایت رسمی تلگرام") }
            OutlinedTextField(apiId, { apiId = it }, enabled = !busy && !active, label = { Text("API ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(hash, { hash = it }, enabled = !busy && !active, label = { Text("API Hash") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(phone, { phone = it }, enabled = !busy && !active, label = { Text("شماره، مثلاً +98912…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = { action("request_code") }, enabled = !busy && !active, modifier = Modifier.fillMaxWidth()) { Text("دریافت کد تلگرام") }
            OutlinedTextField(code, { code = it }, enabled = !busy && !active, label = { Text("آخرین کد ورود") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(twofa, { twofa = it }, enabled = !busy && !active, label = { Text("رمز دومرحله‌ای؛ اگر تلگرام درخواست کرد") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { action("verify_code") }, enabled = !busy && !active && (code.isNotBlank() || twofa.isNotBlank()), modifier = Modifier.fillMaxWidth()) { Text("تأیید ورود") }
            Button(onClick = { action("check_telegram") }, enabled = !busy && !active, modifier = Modifier.fillMaxWidth()) { Text("بررسی دسترسی به کانال") }
            Text("از خانه دریافت را شروع کن. فقط پیام‌های بعد از شروع و با حداکثر ۱۰ ثانیه تأخیر پذیرفته می‌شوند. اینترنت و دسترسی تلگرام همچنان لازم است.", style = MaterialTheme.typography.bodySmall)
        }
        1 -> {
            CardBlock {
                Text("ورود ترندو و دریافت حساب‌ها", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("همان ایمیل و رمز ورود Trendo را وارد کن. انتخاب حساب در اینجا از حساب بازشده در رابط خود ترندو مستقل است.")
                OutlinedTextField(user, { user = it; walletId = ""; wallets = JSONArray() }, enabled = !busy && !active, label = { Text("ایمیل Trendo") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(password, { password = it; walletId = ""; wallets = JSONArray() }, enabled = !busy && !active, label = { Text("رمز Trendo") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Button(onClick = { action("list_wallets") }, enabled = !busy && !active, modifier = Modifier.fillMaxWidth()) { Text("دریافت حساب‌های من از ترندو") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !real, enabled = !active && !busy, onClick = { real = false; walletId = "" }, label = { Text("مجازی • دمو") })
                    FilterChip(selected = real, enabled = !active && !busy, onClick = { real = true; walletId = "" }, label = { Text("واقعی") })
                }
                if (walletId.isNotBlank()) Text("انتخاب ذخیره‌شده: $walletId • $currency • ${if (real) "واقعی" else "آزمایشی"}", color = MaterialTheme.colorScheme.primary)
                if (wallets.length() == 0) Text("حساب‌های قابل انتخاب پس از دریافت از بروکر اینجا نمایش داده می‌شوند؛ نیازی به تایپ شناسه نیست.")
                for (i in 0 until wallets.length()) {
                    val w = wallets.getJSONObject(i)
                    val kind = w.optString("kind")
                    if (kind == (if (real) "real" else "demo") || kind == "unknown") {
                        val allowed = w.optBoolean("supported")
                        OutlinedButton(onClick = {
                            walletId = w.optString("id"); currency = w.optString("currency"); real = kind == "real"
                            try { save(); result = "حساب انتخاب و ذخیره شد؛ هنگام شروع خودکار همین شناسه دوباره بررسی می‌شود."; failed = false }
                            catch (e: Exception) { result = e.message ?: "ذخیره نشد"; failed = true }
                        }, enabled = allowed && !active && !busy, modifier = Modifier.fillMaxWidth().testTag("wallet-${w.optString("id")}")) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = walletId == w.optString("id"), onClick = null)
                                Column {
                                    Text("${w.optString("id")} • ${w.optString("currency")} • ${w.optString("balance")}")
                                    Text(if (allowed) (if (kind == "real") "حساب واقعی" else "حساب آزمایشی") else w.optString("reason"))
                                }
                            }
                        }
                    }
                }
                Text("USD و EUR پشتیبانی می‌شوند. در حساب EUR، حجم با نرخ تازهٔ EURUSD محاسبه می‌شود؛ بدون نرخ معتبر ورود متوقف می‌ماند.", style = MaterialTheme.typography.bodySmall)
                Text("این صفحه برای انتخاب حساب معاملاتی است؛ واریز، برداشت و انتقال وجه در خود ترندو انجام می‌شود.", style = MaterialTheme.typography.bodySmall)
            }
        }
        2 -> {
            BackgroundPanel(onError)
            CardBlock { BrokerAppControl(vault, onError) }
            CardBlock {
                Text("بودجهٔ اجرای خودکار", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(risk, { risk = it }, enabled = !busy && !active, label = { Text("ریسک هر سیگنال؛ درصد") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(limit, { limit = it }, enabled = !busy && !active, label = { Text("سقف افت روزانه؛ ارز حساب ($currency)") }, modifier = Modifier.fillMaxWidth())
                Text("سقف افت، ورود بعدی را محدود می‌کند؛ سقف قطعی زیان یا بستن همهٔ معاملات نیست.")
                Button(onClick = { try { save(); result = "تنظیمات ذخیره شد؛ از خانه دریافت دستی یا اجرای خودکار را شروع کن."; failed = false; onNotice("تنظیمات اجرا ذخیره شد") } catch (e: Exception) { result = e.message ?: "ذخیره نشد"; failed = true } }, enabled = !active && !busy) { Text("ذخیرهٔ تنظیمات اجرا") }
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(reduced, onReduced); Text("کاهش حرکت آموزش") }
                Text("اینترنت، محدودیت باتری و مهلت سرویس اندروید بر اجرای پیوسته اثر دارند. توقف موتور، استاپ مجازی را متوقف می‌کند؛ استاپ ثبت‌شدهٔ بروکر را بررسی کن.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
