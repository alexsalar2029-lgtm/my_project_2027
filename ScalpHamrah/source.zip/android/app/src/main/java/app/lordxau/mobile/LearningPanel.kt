package app.lordxau.mobile

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun LearningPanel(reduced: Boolean, vault: SecureSettings, onError: (String) -> Unit) {
    var section by rememberSaveable { mutableIntStateOf(0) }
    Text("آکادمی اسکالپ همراه", fontSize = 26.sp, fontWeight = FontWeight.Bold)
    Text("از خواندن اولین پیام تا ثبت و بررسی سفارش؛ بدون نیاز به فعال‌کردن معاملهٔ خودکار.")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("سیگنال‌خوانی", "Trendo", "تمرین").forEachIndexed { index, name ->
            FilterChip(selected = section == index, onClick = { section = index }, label = { Text(name) })
        }
    }
    when (section) {
        0 -> {
            Education(reduced)
            CardBlock {
                Text("واژه‌های کانال به زبان ساده", fontWeight = FontWeight.Bold)
                Text("Buy / بای: خرید؛ سود با افزایش قیمت. Sell / سل: فروش؛ سود با کاهش قیمت.")
                Text("Enter: ناحیهٔ ورود است؛ سود تضمین‌شده یا دستور ورود در هر قیمتی نیست.")
                Text("SL / Stop: حد ضرر. TP: حد سود. عدد قیمت، پیپ و دلار سه چیز متفاوت‌اند.")
                Text("«فریش کن»: بررسی انتقال استاپ به ورود واقعی خودت. ابتدا قیمت، اسپرد و اجازهٔ بروکر برای استاپ جدید را چک کن.")
                Text("«ببندش»: دستور خروج مربوط به معامله است؛ نماد و جهت و شناسه را پیدا کن و پس از خروج، حجم باقی‌مانده را بررسی کن.")
                Text("«بگیر باز»: می‌تواند ورود دوباره باشد؛ تازگی پیام و ناحیهٔ جدید را بررسی کن. یک پیام تکراری یا ویرایش‌شده نباید خودبه‌خود معاملهٔ جدید فرض شود.")
            }
            CardBlock {
                Text("پیام ناقص یا مبهم", fontWeight = FontWeight.Bold)
                Text("اگر جهت، استاپ یا منظور عددها روشن نیست، معامله را ثبت نکن. «رو ۲۳۵۵ فری کن» ممکن است شرط قیمت باشد؛ آن را بدون روشن‌شدن منظور به فری فوری تبدیل نکن.")
                Text("در بخش سیگنال‌ها می‌توانی متن را فقط تحلیل کنی. نتیجهٔ خواندن متن، تأیید مناسب‌بودن معامله نیست.")
            }
        }
        1 -> BrokerGuide(vault, onError)
        2 -> {
            RiskPractice()
            BeginnerQuiz()
        }
    }
}

private val brokerSteps = listOf(
    "حساب و نماد" to "در Trendo حساب دمو یا واقعی را از روی عنوان حساب بررسی کن. XAUUSD را جست‌وجو و مشخصات قرارداد، حداقل حجم و گام حجم را بخوان. این اپ برای معاملات طلا با بروکر طراحی شده است؛ خرید رمزارز در کیف پول نیست.",
    "نوع سفارش و جهت" to "Buy یا Sell را با پیام تطبیق بده. Market یعنی اجرا با قیمت فعلی و احتمال لغزش؛ Limit سفارش انتظار در قیمت مشخص است. اگر قیمت از ناحیه گذشته، همان سیگنال را بدون بررسی دنبال نکن.",
    "حجم، استاپ و تارگت" to "حجم را بر اساس بودجهٔ ریسک و فاصلهٔ استاپ محاسبه کن. SL و TP را در فرم سفارش وارد کن. برای خرید، استاپ پایین‌تر و تارگت بالاتر از ورود است؛ برای فروش برعکس. صفر یا خالی‌بودن استاپ ممکن است به معنی نبود حفاظت باشد.",
    "بازبینی و ارسال دستی" to "پیش از لمس دکمهٔ نهایی در Trendo، حساب، نماد، جهت، حجم، SL و TP را دوباره بخوان. سفارش انتظار با معاملهٔ باز فرق دارد. فقط خودت تصمیم ارسال را بگیر.",
    "بررسی بعد از اجرا" to "در فهرست معاملات، شناسه، حجم واقعی، قیمت پرشدن و استاپ پذیرفته‌شده را بررسی کن. پیام ارسال موفق در اپ به‌تنهایی اثبات پرشدن سفارش نیست. برای خطا، ابتدا وضعیت سفارش قبلی را ببین تا سفارش تکراری نفرستی.",
    "فری و خروج" to "برای فری، ورود واقعی خودت را مرجع بگیر و پاسخ تغییر استاپ را بررسی کن. برای خروج، معاملهٔ درست و مقدار حجم را انتخاب کن. اگر بخشی بسته شد، حجم باقیمانده همچنان ریسک دارد؛ تا تأیید خروج کامل آن را پیگیری کن."
)

@Composable private fun BrokerGuide(vault: SecureSettings, onError: (String) -> Unit) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    Text("ورود دستی در Trendo", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("راهنمای عملی بر اساس مفاهیم سفارش است؛ جای دکمه‌ها و نام منوها ممکن است در نسخهٔ نصب‌شده متفاوت باشد.")
    CardBlock {
        Text("گام ${step + 1} از ${brokerSteps.size}", color = MaterialTheme.colorScheme.primary)
        LinearProgressIndicator(progress = { (step + 1f) / brokerSteps.size }, modifier = Modifier.fillMaxWidth())
        Text(brokerSteps[step].first, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(brokerSteps[step].second, lineHeight = 26.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { step = (step + 1) % brokerSteps.size }) { Text(if (step == brokerSteps.lastIndex) "مرور از ابتدا" else "گام بعد") }
            OutlinedButton(onClick = { step-- }, enabled = step > 0) { Text("قبلی") }
        }
    }
    CardBlock { BrokerAppControl(vault, onError) }
    CardBlock {
        Text("چک‌لیست قبل از تأیید", fontWeight = FontWeight.Bold)
        listOf("حساب و نماد را بررسی کردم", "جهت و ناحیه با پیام یکسان است", "حجم از بودجهٔ ریسک بیشتر نیست", "استاپ و تارگت را دوباره خواندم", "پیام تکراری یا قدیمی نیست").forEach { label ->
            var checked by rememberSaveable(label) { mutableStateOf(false) }
            Row { Checkbox(checked, { checked = it }); Text(label, Modifier.padding(top = 12.dp)) }
        }
        Text("تکمیل این چک‌لیست هیچ سفارشی ارسال نمی‌کند.")
    }
}

@Composable private fun RiskPractice() {
    var balance by rememberSaveable { mutableStateOf("1000") }
    var percent by rememberSaveable { mutableStateOf("1") }
    var entry by rememberSaveable { mutableStateOf("2351") }
    var stop by rememberSaveable { mutableStateOf("2347") }
    var contract by rememberSaveable { mutableStateOf("100") }
    var minimum by rememberSaveable { mutableStateOf("0.01") }
    var increment by rememberSaveable { mutableStateOf("0.01") }
    var sell by rememberSaveable { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    CardBlock {
        Text("کارگاه حجم؛ فقط تمرین", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("عددها فرضی‌اند و پیشنهاد معامله نیستند. ارزش قرارداد، حداقل حجم و گام حجم را از مشخصات همان نماد و حساب بخوان؛ این مثال حساب دلاری است.")
        Row { Switch(sell, { sell = it; result = "" }); Text(if (sell) "فروش SELL" else "خرید BUY", Modifier.padding(top = 12.dp)) }
        OutlinedTextField(balance, { balance = it; result = "" }, label = { Text("موجودی دلار") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(percent, { percent = it; result = "" }, label = { Text("درصد ریسک انتخابی") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(entry, { entry = it; result = "" }, label = { Text("قیمت ورود نمونه") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(stop, { stop = it; result = "" }, label = { Text("استاپ نمونه") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(contract, { contract = it; result = "" }, label = { Text("دلار به ازای حرکت ۱ واحد قیمت در ۱ لات") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(minimum, { minimum = it; result = "" }, label = { Text("حداقل لات بروکر") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(increment, { increment = it; result = "" }, label = { Text("گام لات بروکر") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            result = try {
                val r = LessonRisk.calculate(!sell, lessonNumber(balance), lessonNumber(percent), lessonNumber(entry), lessonNumber(stop), lessonNumber(contract), lessonNumber(minimum), lessonNumber(increment))
                if (r.lots == null) "حداقل حجم بروکر از بودجهٔ این مثال بیشتر است؛ حجم را به حداقل گرد نکن."
                else "بودجهٔ نمونه: %.2f دلار\nحجم با گردکردن رو به پایین: %.4f لات\nزیان نظری تا استاپ: %.2f دلار".format(java.util.Locale.US, r.budget, r.lots, r.estimatedRisk)
            } catch (e: IllegalArgumentException) { e.message ?: "ورودی نامعتبر" }
        }) { Text("محاسبهٔ آموزشی") }
        if (result.isNotBlank()) Text(result, color = MaterialTheme.colorScheme.primary)
        Text("کارمزد، اسپرد، گپ و لغزش می‌توانند زیان واقعی را بیشتر کنند. این محاسبه هیچ سفارش یا تنظیم ربات را تغییر نمی‌دهد.")
    }
}

@Composable private fun BeginnerQuiz() {
    var selected by rememberSaveable { mutableIntStateOf(-1) }
    CardBlock {
        Text("خودت را امتحان کن", fontWeight = FontWeight.Bold)
        Text("ربات پیام «درخواست بستن ارسال شد» داده، اما حجم معامله هنوز باز است. چه نتیجه‌ای می‌گیری؟")
        listOf("معامله قطعاً بسته شده است", "باید پاسخ بروکر و حجم باقی‌مانده را بررسی کنم", "برای اطمینان یک معاملهٔ جدید باز می‌کنم").forEachIndexed { i, answer ->
            OutlinedButton(onClick = { selected = i }, modifier = Modifier.fillMaxWidth()) { Text(answer) }
        }
        if (selected >= 0) Text(if (selected == 1) "درست است. ارسال درخواست، تأیید خروج نیست؛ حجم باقی‌مانده هنوز ریسک دارد." else "دوباره فکر کن: معیار خروج، وضعیت تأییدشدهٔ سفارش و حجم باز در بروکر است.")
    }
}
