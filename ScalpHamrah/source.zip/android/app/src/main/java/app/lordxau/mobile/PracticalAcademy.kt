package app.lordxau.mobile

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale

private val practiceSaver = listSaver<PracticeSession, Any>(
    save = { listOf(it.scenario, it.phase, it.remaining, it.stop, it.feedback, it.closedBy, it.realized) },
    restore = { PracticeSession(it[0] as String, it[1] as Int, it[2] as Double, it[3] as Double, it[4] as String, it[5] as String, it[6] as Double) }
)
private fun price(n: Double) = String.format(Locale.US, "%.2f", n)

@Composable internal fun PracticalAcademy(reduced: Boolean) {
    var opened by rememberSaveable { mutableStateOf(false) }
    CardBlock {
        Text("خودت سفارش را انجام بده", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("پیام می‌رسد ← فرم را پر می‌کنی ← فری می‌کنی ← کامل می‌بندی")
        Text("شبیه‌ساز تصویری با پول فرضی، راهنمای صوتی فارسی و توضیح اشتباه‌ها. قیمت‌های تمرین واقعی و زنده نیستند.")
        Button(onClick = { opened = true }, modifier = Modifier.fillMaxWidth().testTag("practice-start")) { Text("شروع تمرین با پول فرضی") }
    }
    if (opened) Dialog(onDismissRequest = { opened = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            PracticeRoom(reduced) { opened = false }
        }
    }
}

@Composable private fun PracticeRoom(reduced: Boolean, onDismiss: () -> Unit) {
    var session by rememberSaveable(stateSaver = practiceSaver) { mutableStateOf(PracticeSession()) }
    var symbol by rememberSaveable { mutableStateOf("XAUUSD") }
    var lots by rememberSaveable { mutableStateOf("0.02") }
    var sl by rememberSaveable { mutableStateOf("") }
    var tp by rememberSaveable { mutableStateOf("") }
    var free by rememberSaveable { mutableStateOf("") }
    var automaticVoice by rememberSaveable { mutableStateOf(false) }
    val voice = rememberPersianVoice()
    val scroll = rememberScrollState()
    val s = session
    LaunchedEffect(s.phase) { scroll.animateScrollTo(0) }
    LaunchedEffect(s.hint, s.feedback, automaticVoice, voice.ready) {
        if (automaticVoice && voice.ready) voice.speak(s.feedback.ifBlank { s.hint })
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("کارگاه عملی • پول فرضی", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = onDismiss, modifier = Modifier.testTag("practice-dismiss")) { Text("خروج ×") }
        }
        Column(Modifier.weight(1f).verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("buy" to "خرید", "sell" to "فروش", "stop" to "استاپ", "free_hit" to "فری خورد").forEach { (id, title) ->
                    FilterChip(selected = s.scenario == id, onClick = {
                        session = PracticeSession(scenario = id); sl = ""; tp = ""; free = ""; lots = "0.02"; symbol = "XAUUSD"
                    }, label = { Text(title) }, modifier = Modifier.testTag("scenario-$id"))
                }
            }
            LinearProgressIndicator(progress = { (s.phase + 1f) / 6f }, modifier = Modifier.fillMaxWidth())
            Text("گام ${s.phase + 1} از ۶ • این اتاق هیچ سفارشی به بروکر نمی‌فرستد.", style = MaterialTheme.typography.bodySmall)
            CardBlock {
                Text("✉ پیام نمونهٔ کانال", color = MaterialTheme.colorScheme.primary)
                Text(s.message, style = MaterialTheme.typography.titleMedium, modifier = Modifier.testTag("practice-message"))
            }
            if (s.phase > 1) {
                CardBlock {
                    Text("GOLD  •  ${s.direction}  •  حساب تمرینی", fontWeight = FontWeight.Bold)
                    Text("ورود واقعیِ فرضی: ${price(s.fill)}", modifier = Modifier.testTag("practice-fill"))
                    Text("حجم باز: ${price(s.remaining)} لات", modifier = Modifier.testTag("practice-volume"))
                    Text("SL: ${price(s.stop)}  |  TP: ${price(s.target)}")
                    Text("موجودی فرضی: ${price(s.balance)} دلار • ارزش با سود/زیان باز: ${price(s.equity)} دلار")
                    Text("سود/زیان ثبت‌شده: ${price(s.realized)} دلار", modifier = Modifier.testTag("practice-realized"))
                    Text("محاسبهٔ سادهٔ آموزشی؛ هزینه و لغزش لحاظ نشده‌اند.", style = MaterialTheme.typography.bodySmall)
                    PracticeChart(s, reduced)
                }
            }
            CardBlock {
                when (s.phase) {
                    0 -> {
                        Text("۱. حساب را انتخاب کن", style = MaterialTheme.typography.titleLarge)
                        Button(onClick = { session = s.wallet(true) }, modifier = Modifier.fillMaxWidth().testTag("practice-demo")) { Text("آزمایشی • ۱۰۰۰ دلار فرضی") }
                        OutlinedButton(onClick = { session = s.wallet(false) }, modifier = Modifier.fillMaxWidth()) { Text("واقعی") }
                    }
                    1 -> {
                        Text("۲. فرم سفارش نمونهٔ ترندو", style = MaterialTheme.typography.titleLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("XAUUSD", "EURUSD").forEach { item -> FilterChip(selected = symbol == item, onClick = { symbol = item }, label = { Text(if (item == "XAUUSD") "GOLD • XAUUSD" else item) }) }
                        }
                        Text("نوع سفارش: اجرا در قیمت بازار • قیمت‌ها فرضی‌اند")
                        OutlinedTextField(lots, { lots = it }, label = { Text("حجم؛ نمونه ۰٫۰۲ لات") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("practice-lots"))
                        OutlinedTextField(sl, { sl = it }, label = { Text("Stop / SL • حد ضرر") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("practice-sl"))
                        OutlinedTextField(tp, { tp = it }, label = { Text("TP • حد سود") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("practice-tp"))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("BUY" to "خرید", "SELL" to "فروش").forEach { (id, label) ->
                                Button(onClick = { session = s.order(id, symbol, numberOrNaN(lots), numberOrNaN(sl), numberOrNaN(tp)) }, modifier = Modifier.weight(1f).testTag("practice-$id"),
                                    colors = ButtonDefaults.buttonColors(containerColor = if (id == "BUY") Color(0xFF197BC1) else Color(0xFFB9434C))) { Text(label) }
                            }
                        }
                    }
                    2 -> if (s.scenario == "stop") {
                        Text("قیمت نمونه به حد ضرر رسید")
                        Button(onClick = { session = s.checkHistory() }, modifier = Modifier.testTag("practice-history")) { Text("بررسی بسته‌شدن در تاریخچه") }
                        OutlinedButton(onClick = { session = s.reenter() }) { Text("دوباره باز می‌کنم") }
                    } else {
                        Text("۳. تغییر استاپِ همین معامله", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(free, { free = it }, label = { Text("حد ضرر جدید برای فری") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("practice-free-input"))
                        Button(onClick = { session = s.free(numberOrNaN(free)) }, modifier = Modifier.fillMaxWidth().testTag("practice-free")) { Text("تأیید تغییر استاپ") }
                    }
                    3 -> if (s.scenario == "free_hit") {
                        Text("قیمت به استاپ فری برگشت")
                        Button(onClick = { session = s.checkHistory() }, modifier = Modifier.testTag("practice-history")) { Text("بررسی بسته‌شدن در تاریخچه") }
                        OutlinedButton(onClick = { session = s.reenter() }) { Text("دوباره باز می‌کنم") }
                    } else {
                        Text("۴. بستن همین معامله", style = MaterialTheme.typography.titleLarge)
                        Button(onClick = { session = s.close(false) }, modifier = Modifier.fillMaxWidth().testTag("practice-close")) { Text("بستن تمام حجم باقی‌مانده") }
                        OutlinedButton(onClick = { session = s.close(true) }, enabled = s.remaining > .01, modifier = Modifier.fillMaxWidth().testTag("practice-half")) { Text("فقط نصف حجم را می‌بندم") }
                    }
                    4 -> {
                        Text("۵. تأیید بستن ${price(s.remaining)} لات")
                        Button(onClick = { session = s.confirmClose() }, modifier = Modifier.fillMaxWidth().testTag("practice-confirm")) { Text("تأیید خروج از همین سفارش") }
                    }
                    else -> {
                        Text("✓ خروج تأیید شد", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.testTag("practice-complete"))
                        Text("علت: ${s.closedBy} • حجم باز صفر")
                        Button(onClick = { session = PracticeSession(scenario = s.scenario); sl = ""; tp = ""; free = "" }, modifier = Modifier.fillMaxWidth()) { Text("دوباره تمرین می‌کنم") }
                    }
                }
            }
            CardBlock {
                Text("🦁 دستیار کنار تو", fontWeight = FontWeight.Bold)
                if (s.feedback.isNotBlank()) Text(s.feedback, color = MaterialTheme.colorScheme.primary, modifier = Modifier.testTag("practice-feedback"))
                Text(s.hint, modifier = Modifier.testTag("practice-hint"))
                VoiceControls(voice, s.hint + " " + s.feedback)
                Row { Switch(automaticVoice, { automaticVoice = it; if (!it) voice.stop() }); Text("توضیح صوتی هر مرحله", Modifier.padding(top = 12.dp)) }
            }
        }
    }
}

private fun numberOrNaN(text: String) = runCatching { lessonNumber(text) }.getOrDefault(Double.NaN)

@Composable private fun PracticeChart(session: PracticeSession, reduced: Boolean) {
    val quote by animateFloatAsState(session.quote.toFloat(), tween(if (reduced) 0 else 900), label = "practice-price")
    val stop by animateFloatAsState(session.stop.toFloat(), tween(if (reduced) 0 else 900), label = "practice-stop")
    Canvas(Modifier.fillMaxWidth().height(100.dp).semantics { contentDescription = "نمودار فرضی؛ ورود ${session.fill} و استاپ ${session.stop}" }) {
        fun y(v: Float) = size.height * (1 - (v - 3903f) / 10f)
        drawLine(Color(0xFF53ADEC), Offset(0f, y(session.fill.toFloat())), Offset(size.width, y(session.fill.toFloat())), 3f)
        drawLine(Color(0xFFF88282), Offset(0f, y(stop)), Offset(size.width, y(stop)), 4f)
        drawLine(Color(0xFF67D6B9), Offset(size.width * .15f, y(session.fill.toFloat())), Offset(size.width * .85f, y(quote)), 6f)
        drawCircle(Color(0xFF67D6B9), 9f, Offset(size.width * .85f, y(quote)))
    }
    Text("آبی: ورود تو  •  قرمز: استاپ  •  سبز: حرکت قیمت نمونه", style = MaterialTheme.typography.bodySmall)
}
