package app.lordxau.mobile

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import org.json.JSONObject
import java.util.Locale

@Composable internal fun LiveStatusPanel(status: JSONObject) {
    val live = status.optJSONObject("live_delivery") ?: JSONObject()
    val counts = live.optJSONObject("counts") ?: JSONObject()
    CardBlock {
        Text("دریافت زندهٔ کانال", style = MaterialTheme.typography.titleLarge)
        Text(if (status.optBoolean("running")) "فقط پیام‌های بعد از شروع؛ سقف تأخیر ۱۰ ثانیه" else "دریافت متوقف است؛ برای پیام‌های تازه از خانه شروع کن.")
        val delay = live.optDouble("last_delay_seconds", Double.NaN)
        Text(if (delay.isFinite()) "تأخیر آخرین پیام: %.1f ثانیه".format(Locale.US, delay) else "هنوز پیام تازه‌ای برای اندازه‌گیری تأخیر نرسیده است.")
        Text("پذیرفته برای بررسی: ${counts.optInt("accepted")}  •  منقضی: ${counts.optInt("expired")}")
        Text("زمان‌سنج از تاریخ تلگرام و ساعت گوشی استفاده می‌کند؛ ساعت خودکار گوشی روشن باشد. دریافت پیام به معنی تأیید اجرای سفارش نیست.", style = MaterialTheme.typography.bodySmall)
    }
}

internal fun commandLabel(kind: String) = when (kind) {
    "HINT" -> "جهت اعلام شد؛ منتظر ناحیهٔ ورود"
    "ZONE", "SIGNAL" -> "ناحیه یا سیگنال ورود"
    "STOP" -> "حد ضرر"
    "BE" -> "فری کردن"
    "BE_HIT" -> "گزارش برخورد با استاپ فری"
    "SL_HIT" -> "گزارش برخورد با حد ضرر"
    "CLOSE" -> "بستن معامله"
    "REENTER" -> "درخواست ورود دوباره"
    "MARKET_NOW" -> "ورود در قیمت بازار"
    "NOISE" -> "بدون دستور قابل تشخیص"
    else -> "پیام کانال • $kind"
}
