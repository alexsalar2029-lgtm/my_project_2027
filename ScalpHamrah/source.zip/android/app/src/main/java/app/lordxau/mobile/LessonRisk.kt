package app.lordxau.mobile

import kotlin.math.abs
import kotlin.math.floor

fun lessonNumber(text: String): Double = text.trim().map { c ->
    when (c) { in '۰'..'۹' -> '0' + (c - '۰'); in '٠'..'٩' -> '0' + (c - '٠'); '٫' -> '.'; else -> c }
}.joinToString("").toDoubleOrNull() ?: throw IllegalArgumentException("عدد معتبر وارد کن؛ جداکنندهٔ اعشار نقطه یا ٫ است")

data class LessonRiskResult(val budget: Double, val lots: Double?, val estimatedRisk: Double?)

object LessonRisk {
    fun calculate(buy: Boolean, balance: Double, percent: Double, entry: Double, stop: Double,
                  contractValue: Double, minLot: Double, lotStep: Double): LessonRiskResult {
        require(listOf(balance, percent, entry, stop, contractValue, minLot, lotStep).all { it.isFinite() && it > 0 }) { "همهٔ عددها باید مثبت و معتبر باشند" }
        require(percent <= 100) { "درصد نمی‌تواند بیشتر از ۱۰۰ باشد" }
        require(if (buy) stop < entry else stop > entry) { "استاپ خرید باید زیر ورود و استاپ فروش باید بالای ورود باشد" }
        val budget = balance * percent / 100
        val lossPerLot = abs(entry - stop) * contractValue
        require(budget.isFinite() && lossPerLot.isFinite()) { "عددها خارج از محدوده‌اند" }
        val raw = budget / lossPerLot
        if (raw < minLot) return LessonRiskResult(budget, null, null)
        val lots = minLot + floor((raw - minLot) / lotStep + 1e-10) * lotStep
        val risk = lots * lossPerLot
        require(risk <= budget + 1e-8) { "حجم محاسبه‌شده از بودجه بیشتر شده است" }
        return LessonRiskResult(budget, lots, risk)
    }
}
