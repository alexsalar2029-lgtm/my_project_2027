package app.lordxau.mobile

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

object LocalEngine {
    val serviceNotice = MutableStateFlow("")
    @Synchronized fun initialize(context: Context) {
        if (!Python.isStarted()) Python.start(AndroidPlatform(context.applicationContext))
    }
    suspend fun call(context: Context, name: String, vararg args: Any): JSONObject = withContext(Dispatchers.IO) {
        initialize(context)
        val result = Python.getInstance().getModule("mobile_bridge").callAttr(name, *args).toString()
        val parsed = JSONObject(result)
        if (parsed.has("error") && !parsed.isNull("error") && parsed.optString("error").isNotBlank()) error(parsed.optString("error"))
        parsed
    }
}

class TradingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var starting = false
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("engine", "اجرای اسکالپ روی گوشی", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, "engine").setContentTitle("اسکالپ همراه • موتور روی گوشی")
            .setContentText("وضعیت اتصال و معاملات را در برنامه بررسی کنید")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(open).setOngoing(true).build())
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (starting) return START_NOT_STICKY
        starting = true
        scope.launch {
            try {
                val vault = SecureSettings(this@TradingService)
                val config = JSONObject(vault.config())
                config.put("storage_dir", filesDir.absolutePath)
                config.put("execution_mode", if (vault.automatic) "automatic" else "manual")
                config.put("confirm_automatic_trading", vault.automatic && intent?.getBooleanExtra("confirmed_automatic", false) == true)
                config.put("confirm_real_trading", intent?.getBooleanExtra("confirmed_real", false) == true)
                LocalEngine.call(this@TradingService, "start", config.toString())
                LocalEngine.serviceNotice.value = "پاسخ شروع موتور دریافت شد؛ وضعیت اتصال را بررسی کنید"
            } catch (e: Exception) {
                LocalEngine.serviceNotice.value = "شروع موتور انجام نشد: ${e.message?.take(160)}"
                try { LocalEngine.call(this@TradingService, "stop") } catch (_: Exception) { }
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }
    override fun onTimeout(startId: Int, fgsType: Int) {
        LocalEngine.serviceNotice.value = "اندروید مهلت سرویس را پایان داد؛ موتور متوقف می‌شود. معاملات باز و استاپ بروکر را بررسی کنید."
        scope.launch { try { LocalEngine.call(this@TradingService, "stop") } finally { stopSelf() } }
        stopSelf()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }
    override fun onDestroy() {
        scope.launch { try { LocalEngine.call(this@TradingService, "stop") } finally { scope.cancel() } }
        super.onDestroy()
    }
}
