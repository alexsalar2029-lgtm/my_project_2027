package app.lordxau.mobile

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

object LocalEngine {
    val serviceNotice = MutableStateFlow("")
    val serviceActive = MutableStateFlow(false)
    fun ready(): Boolean = try { Python.isStarted() } catch (_: LinkageError) { false }
    @Synchronized fun initialize(context: Context) {
        if (!Python.isStarted()) Python.start(AndroidPlatform(context.applicationContext))
    }
    suspend fun call(context: Context, name: String, vararg args: Any): JSONObject = withContext(Dispatchers.IO) {
        try { initialize(context) } catch (e: LinkageError) { throw IllegalStateException("موتور روی این دستگاه بارگذاری نشد؛ آموزش آفلاین در دسترس است", e) }
        val result = Python.getInstance().getModule("mobile_bridge").callAttr(name, *args).toString()
        val parsed = JSONObject(result)
        if (parsed.has("error") && !parsed.isNull("error") && parsed.optString("error").isNotBlank()) {
            val message = parsed.optString("notice").ifBlank { "عملیات انجام نشد؛ مرحلهٔ اتصال را بررسی کنید (${parsed.optString("error")})" }
            error(message)
        }
        parsed
    }
}

class TradingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var starting = false
    private var wake: EngineWakeLease? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        LocalEngine.serviceActive.value = true
        wake = EngineWakeLease(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("engine", "اجرای اسکالپ روی گوشی", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, TradingService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, "engine").setContentTitle("LionXsec • موتور روی گوشی")
            .setContentText("فقط پیام‌های تازهٔ کانال؛ برای دیدن اتصال لمس کنید")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "توقف موتور", stop).build()).setOngoing(true).build())
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (starting) return START_NOT_STICKY
        starting = true
        scope.launch {
            try {
                wake?.renew()
                val vault = SecureSettings(this@TradingService)
                val config = JSONObject(vault.config())
                config.put("storage_dir", filesDir.absolutePath)
                config.put("execution_mode", if (vault.automatic) "automatic" else "manual")
                config.put("confirm_automatic_trading", vault.automatic && intent?.getBooleanExtra("confirmed_automatic", false) == true)
                config.put("confirm_real_trading", intent?.getBooleanExtra("confirmed_real", false) == true)
                LocalEngine.call(this@TradingService, "start", config.toString())
                LocalEngine.serviceNotice.value = "دریافت زنده شروع شد؛ پیام عقب‌افتاده اجرا نمی‌شود"
                while (isActive) { delay(5 * 60_000L); wake?.renew() }
            } catch (e: Exception) {
                LocalEngine.serviceNotice.value = "شروع موتور انجام نشد: ${e.message?.take(160)}"
                try { LocalEngine.call(this@TradingService, "stop") } catch (_: Exception) { }
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }
    override fun onTimeout(startId: Int, fgsType: Int) {
        LocalEngine.serviceNotice.value = "اندروید مهلت سرویس را پایان داد؛ موتور متوقف می‌شود. معاملات باز و استاپ بروکر را بررسی کنید."
        scope.launch { try { LocalEngine.call(this@TradingService, "stop") } finally { stopSelf() } }
        stopSelf()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }
    override fun onDestroy() {
        wake?.release()
        wake = null
        scope.launch { try { LocalEngine.call(this@TradingService, "stop") } finally { LocalEngine.serviceActive.value = false; scope.cancel() } }
        super.onDestroy()
    }
}

/** A bounded CPU lease while the explicitly started foreground engine runs.
 * It does not unlock the screen or bypass Doze/network/FGS time limits. */
internal class EngineWakeLease(context: Context) {
    private val lock = context.getSystemService(PowerManager::class.java)
        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LionXsec:LiveEngine").apply { setReferenceCounted(false) }
    @Synchronized fun renew() { lock.acquire(10 * 60_000L) }
    @Synchronized fun release() { if (lock.isHeld) lock.release() }
    fun held() = lock.isHeld
}
