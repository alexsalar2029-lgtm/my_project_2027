package app.lordxau.mobile

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

private val Gold = Color(0xFF56B9FF)
private val Ink = Color(0xFF0B111B)
private val Panel = Color(0xFF151E2B)
private val Soft = Color(0xFF98A9BC)
private val Mint = Color(0xFF77DEFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Panel, onSurface = Color(0xFFE6EDF5), secondary = Mint)) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { TraderApp() }
        } }
    }
}

@Composable private fun TraderApp() {
    val ctx = LocalContext.current
    val vault = remember { SecureSettings(ctx) }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    val pageScroll = rememberScrollState()
    LaunchedEffect(tab) { pageScroll.scrollTo(0) }
    var status by remember { mutableStateOf(JSONObject()) }
    var signals by remember { mutableStateOf(JSONObject()) }
    var report by remember { mutableStateOf(JSONObject()) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var reduced by remember { mutableStateOf(vault.reducedMotion) }
    var automatic by remember { mutableStateOf(vault.automatic) }
    var closeId by remember { mutableStateOf<String?>(null) }
    var confirmStart by remember { mutableStateOf(false) }
    val serviceNotice by LocalEngine.serviceNotice.collectAsState()
    val serviceActive by LocalEngine.serviceActive.collectAsState()
    val engineBusy = serviceActive || status.optBoolean("running") || status.optString("state") == "starting"
    suspend fun refresh() {
        if (!LocalEngine.ready()) return
        try {
            status = LocalEngine.call(ctx, "status")
            signals = LocalEngine.call(ctx, "signals")
            report = LocalEngine.call(ctx, "report")
            error = ""
        } catch (e: Exception) { error = "دریافت وضعیت انجام نشد: ${e.message?.take(180)}" }
    }
    LaunchedEffect(Unit) { while (true) { refresh(); delay(5000) } }
    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Panel) {
            listOf("خانه", "سیگنال‌ها", "آموزش", "تنظیمات").forEachIndexed { i, label ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("◈", "↗", "▷", "⚙")[i], fontSize = 24.sp) }, label = { Text(label) })
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(pageScroll).padding(horizontal = 20.dp, vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("LionXsec", fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("LORD XAU   /   ON DEVICE", color = Gold, fontSize = 11.sp) }
                Surface(color = Panel, shape = RoundedCornerShape(14.dp)) { Text("🦁", Modifier.padding(14.dp), color = Gold, fontWeight = FontWeight.Bold) }
            }
            if (error.isNotBlank()) Info(error, Color(0xFFFFABAB))
            if (notice.isNotBlank()) Info(notice, Mint)
            if (serviceNotice.isNotBlank()) Info(serviceNotice, Gold)
            when (tab) {
                0 -> {
                    val connected = status.optBoolean("connected", false)
                    CardBlock {
                        Text("روش استفادهٔ شما", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = !automatic, enabled = !engineBusy, onClick = { automatic = false; vault.automatic = false }, label = { Text("دستی و آموزشی") })
                            FilterChip(selected = automatic, enabled = !engineBusy, onClick = { automatic = true; vault.automatic = true }, label = { Text("خودکار") })
                        }
                        Text(if (automatic) "اجرای سفارش پس از تأیید شروع شما فعال می‌شود." else "پیام‌ها را بخوان و خودت تصمیم بگیر؛ برنامه هیچ سفارشی ارسال نمی‌کند.")
                        if (engineBusy) Text("برای تغییر روش، ابتدا دریافت/اجرای فعلی را متوقف کن.", color = Soft)
                        TextButton(onClick = { tab = 2 }) { Text("تازه‌کارم؛ آموزش را شروع می‌کنم") }
                    }
                    CardBlock {
                        Text(if (automatic) "موتور معامله روی همین گوشی" else "همراه سیگنال‌خوانی؛ فقط نمایش", color = Gold)
                        Text(if (connected) "متصل" else "اتصال تأیید نشده", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = if (connected) Mint else Soft)
                        Text("کانال: ${status.optString("channel", "@lordxau")}")
                        Text("حالت: ${status.optString("mode", "متوقف")}", color = Soft)
                        if (!status.isNull("wallet_id") && status.has("wallet_id")) Text("کیف پول فعال: ${status.optString("wallet_id")} • ${if (status.optString("mode") == "real") "واقعی" else "مجازی / دمو"}", color = Gold)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = { confirmStart = true }, enabled = !busy && !engineBusy) { Text(if (automatic) "شروع خودکار" else "دریافت پیام‌ها") }
                            OutlinedButton(onClick = { scope.launch { busy = true; try { LocalEngine.call(ctx, "stop"); ctx.stopService(Intent(ctx, TradingService::class.java)); notice = "توقف موتور درخواست شد؛ سفارش‌های باز را بررسی کنید"; refresh() } catch (e: Exception) { error = e.message ?: "خطا" } finally { busy = false } } }) { Text("توقف") }
                        }
                    }
                    CardBlock { BrokerAppControl(vault) { error = it } }
                    Text("برآیند قابل بررسی", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    CardBlock {
                        Text(if (report.isNull("net_pnl") || !report.has("net_pnl")) "نتیجهٔ مالی تأیید نشده" else "${report.opt("net_pnl")} USD", fontSize = 25.sp, color = Gold)
                        Text("پیام‌ها: ${report.optInt("message_count")}   •   پوشش کامل: ${if (report.optBoolean("coverage_complete")) "بله" else "خیر"}", color = Soft)
                        Text(report.optString("notice", "برای محاسبهٔ یک ماه اخیر، ورود به تلگرام و دریافت تاریخچه لازم است."))
                        OutlinedButton(onClick = { scope.launch { busy = true; try { val r = LocalEngine.call(ctx, "audit_month"); notice = r.optString("notice", "درخواست بررسی تاریخچه ثبت شد"); refresh() } catch(e: Exception) { error = e.message ?: "خطا" } finally { busy = false } } }, enabled = !busy) { Text("بررسی یک ماه کانال") }
                    }
                    Info("اجرای مستقل روی گوشی به اینترنت و فعال‌ماندن برنامه وابسته است. اندروید و سازندهٔ گوشی ممکن است سرویس را متوقف کنند؛ وضعیت سفارش و استاپ بروکر را بررسی کنید.", Soft)
                }
                1 -> {
                    Text(if (automatic) "هر ورود، با دلیل روشن" else "سیگنال‌ها برای بررسی دستی", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("متن سیگنال، ناحیهٔ ورود و وضعیت تأیید سفارش را کنار هم ببینید.", color = Soft)
                    val rows = signals.optJSONArray("items")
                    if (rows == null || rows.length() == 0) CardBlock { Text("هنوز پیامی ثبت نشده", color = Gold); Text("دریافت پیام‌ها را از خانه فعال کن یا متن سیگنال را پایین همین صفحه وارد کن.") }
                    else for (i in 0 until rows.length()) {
                        val s = rows.getJSONObject(i)
                        CardBlock {
                            Text("${s.optString("symbol", "XAUUSD")}  •  ${s.optString("side")}", color = Gold, fontWeight = FontWeight.Bold)
                            Text("وضعیت: ${s.optString("status", "نامعلوم")}")
                            Text("ورود ${s.opt("entry") ?: "—"}   |   استاپ ${s.opt("stop_loss") ?: "—"}", color = Soft)
                            Text("تارگت ${s.opt("take_profit") ?: "—"}", color = Soft)
                            HorizontalDivider(color = Color(0xFF2A3645))
                            Text("چرا این سیگنال؟", fontWeight = FontWeight.Bold)
                            Text(s.optString("reason", "دلیل تصمیم هنوز ثبت نشده است"))
                            if (!s.isNull("source_message")) Text(s.optString("source_message"), color = Soft)
                            val sourceId = s.optLong("source_message_id", 0)
                            if (sourceId > 0) TextButton(onClick = { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/lordxau/$sourceId"))) } catch (_: Exception) { error = "برنامه‌ای برای بازکردن لینک پیدا نشد" } }) { Text("پیام اصلی در تلگرام") }
                            if (automatic && s.optString("status") in listOf("open", "close_pending")) OutlinedButton(onClick = { closeId = s.optString("id") }) { Text("درخواست بستن") }
                        }
                    }
                    val events = status.optJSONArray("events")
                    if (events != null && events.length() > 0) CardBlock {
                        Text("آخرین رویدادهای موتور", fontWeight = FontWeight.Bold)
                        for (i in (events.length() - 5).coerceAtLeast(0) until events.length()) Text(events.getJSONObject(i).optString("text"), style = MaterialTheme.typography.bodySmall)
                    }
                    PreviewTool()
                }
                2 -> LearningPanel(reduced, vault) { error = it }
                3 -> Settings(vault, reduced, { reduced = it; vault.reducedMotion = it }, { notice = it }, { error = it })
            }
            Text("نسخهٔ 0.3.0 • آزمون دمو پیش از استفاده واقعی  •  Android 8+", color = Soft, fontSize = 11.sp)
        }
    }
    if (closeId != null) AlertDialog(onDismissRequest = { closeId = null }, title = { Text("بستن سفارش") }, text = { Text("درخواست بستن همین سفارش به بروکر فرستاده می‌شود. تا تأیید بروکر، سفارش بسته محسوب نمی‌شود.") }, confirmButton = { Button(onClick = { val id = closeId!!; closeId = null; scope.launch { try { val r = LocalEngine.call(ctx, "close_signal", id); notice = r.optString("notice", "درخواست ثبت شد؛ منتظر تأیید بروکر"); refresh() } catch(e: Exception) { error = e.message ?: "خطا" } } }) { Text("ارسال درخواست") } }, dismissButton = { TextButton(onClick = { closeId = null }) { Text("انصراف") } })
    if (confirmStart) AlertDialog(
        onDismissRequest = { confirmStart = false },
        title = { Text(if (automatic) "شروع معاملهٔ خودکار" else "دریافت پیام برای بررسی دستی") },
        text = {
            val real = try { JSONObject(vault.config()).optBoolean("real_wallet", false) } catch (_: Exception) { false }
            Text(if (!automatic) "فقط پیام‌های کانال دریافت و خوانده می‌شوند. هیچ سفارش خرید، فروش یا خروجی از طرف برنامه ارسال نمی‌شود." else
                (if (real) "حساب واقعی انتخاب شده؛ این تأیید اجازهٔ ارسال سفارش واقعی طبق پیام‌های کانال است. " else "حساب دمو انتخاب شده. ") +
                "موتور روی گوشی کار می‌کند. توقف برنامه حفاظت مجازی را متوقف می‌کند؛ استاپ بروکر را بررسی کن.")
        },
        confirmButton = { Button(onClick = {
            confirmStart = false
            try {
                require(vault.config().isNotBlank()) { "ابتدا تنظیمات تلگرام را ذخیره کنید" }
                val real = JSONObject(vault.config()).optBoolean("real_wallet", false)
                if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    (ctx as? android.app.Activity)?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
                }
                val brokerIntent = if (automatic && vault.openBrokerOnStart) brokerLaunchIntent(ctx, vault.brokerPackage) else null
                LocalEngine.serviceActive.value = true
                ctx.startForegroundService(Intent(ctx, TradingService::class.java)
                    .putExtra("confirmed_automatic", automatic).putExtra("confirmed_real", automatic && real))
                notice = "درخواست شروع ثبت شد؛ وضعیت اتصال را بررسی کنید"
                if (brokerIntent != null) {
                    try { ctx.startActivity(brokerIntent) }
                    catch (_: Exception) { error = "موتور درخواست شروع گرفته، اما Trendo باز نشد؛ اتصال و معاملات را بررسی کنید" }
                }
            } catch (e: Exception) { LocalEngine.serviceActive.value = false; error = e.message ?: "شروع انجام نشد" }
        }) { Text(if (automatic) "تأیید و شروع خودکار" else "شروع دریافت") } },
        dismissButton = { TextButton(onClick = { confirmStart = false }) { Text("انصراف") } }
    )
}

@Composable internal fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content) }
}
@Composable private fun Info(text: String, color: Color) { Text(text, color = color, fontSize = 13.sp, lineHeight = 22.sp) }

@Composable private fun PreviewTool() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }; var result by remember { mutableStateOf("") }
    CardBlock {
        Text("بررسی متن، پیش از ورود دستی", fontWeight = FontWeight.Bold)
        OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("متن سیگنال") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Button(onClick = { scope.launch { result = try { val r = LocalEngine.call(ctx, "preview", text); "${r.optString("kind")} • ${r.optString("side")}\nورود: ${r.opt("entries")}\nاستاپ: ${r.opt("stop_loss")}\n${r.optString("reason")}" } catch(e: Exception) { e.message ?: "خطا" } } }, enabled = text.isNotBlank()) { Text("خواندن سیگنال") }
        Info("این بخش فقط متن را تحلیل می‌کند و سفارش نمی‌فرستد.", Soft)
        if (result.isNotBlank()) Text(result)
    }
}

@Composable private fun Settings(vault: SecureSettings, reduced: Boolean, onReduced: (Boolean)->Unit, onNotice: (String)->Unit, onError:(String)->Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val saved = remember { try { JSONObject(vault.config()) } catch (_: Exception) { JSONObject() } }
    var apiId by remember { mutableStateOf(saved.optString("api_id")) }
    var hash by remember { mutableStateOf(saved.optString("api_hash")) }
    var phone by remember { mutableStateOf(saved.optString("phone")) }
    var user by remember { mutableStateOf(saved.optString("broker_username")) }
    var password by remember { mutableStateOf(saved.optString("broker_password")) }
    var real by remember { mutableStateOf(saved.optBoolean("real_wallet", false)) }
    var riskPct by remember { mutableStateOf(saved.optString("risk_pct", "2")) }
    var dailyLoss by remember { mutableStateOf(saved.optString("max_daily_loss", "8")) }
    var walletId by remember { mutableStateOf(saved.optString("wallet_id")) }
    val engineActive by LocalEngine.serviceActive.collectAsState()
    var code by remember { mutableStateOf("") }; var twofa by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun config(): JSONObject {
        require(!engineActive) { "ابتدا موتور را متوقف کنید؛ تغییر حساب هنگام اجرا مجاز نیست" }
        require(apiId.toIntOrNull() != null && hash.isNotBlank() && phone.isNotBlank()) { "API ID، API Hash و شمارهٔ تلگرام را کامل کنید" }
        val risk = lessonNumber(riskPct)
        val limit = lessonNumber(dailyLoss)
        require(risk.isFinite() && risk in 0.01..5.0 && limit.isFinite() && limit in 0.01..100000.0) { "ریسک باید بین ۰٫۰۱ تا ۵ درصد و سقف زیان روزانه مثبت باشد" }
        return JSONObject().put("api_id", apiId.toInt()).put("api_hash", hash).put("phone", phone)
            .put("broker_username", user).put("broker_password", password).put("real_wallet", real)
            .put("wallet_id", walletId.trim())
            .put("execution_mode", if (vault.automatic) "automatic" else "manual")
            .put("risk_pct", risk).put("max_daily_loss", limit).put("storage_dir", ctx.filesDir.absolutePath)
    }
    CardBlock {
        Text("حساب تلگرام و بروکر", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Info("اطلاعات با Android Keystore رمزگذاری و فقط روی همین گوشی ذخیره می‌شود.", Soft)
        OutlinedTextField(apiId, { apiId = it }, label = { Text("Telegram API ID") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(hash, { hash = it }, label = { Text("Telegram API Hash") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("شماره با کد کشور") }, modifier = Modifier.fillMaxWidth())
        if (vault.automatic) {
            OutlinedTextField(user, { user = it }, label = { Text("نام کاربری Trendo") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(password, { password = it }, label = { Text("رمز Trendo") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Text("کیف پول اجرای سیگنال", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !real, enabled = !engineActive, onClick = { real = false; walletId = "" }, label = { Text("مجازی • دمو") })
                FilterChip(selected = real, enabled = !engineActive, onClick = { real = true; walletId = "" }, label = { Text("واقعی") })
            }
            Text(if (real) "معامله با پول واقعی؛ شروع نیاز به تأیید شما دارد." else "معامله خودکار در حساب دمو بروکر با موجودی مجازی؛ با تمرین آفلاین متفاوت است.")
            OutlinedTextField(walletId, { walletId = it }, enabled = !engineActive, label = { Text("شناسه کیف پول؛ برای چند حساب الزامی") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(riskPct, { riskPct = it }, enabled = !engineActive, label = { Text("بودجهٔ ریسک هر سیگنال؛ درصد") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(dailyLoss, { dailyLoss = it }, enabled = !engineActive, label = { Text("سقف افت روزانه؛ دلار") }, modifier = Modifier.fillMaxWidth())
            Text("این سقف نسبت به موجودی شروع روز بررسی می‌شود و مانع ورود بعدی می‌شود؛ بستن همهٔ سفارش‌ها یا سقف قطعی زیان را تضمین نمی‌کند.")
            Text("اگر فقط یک کیف پول دلاری از نوع انتخاب‌شده دارید، شناسه می‌تواند خالی باشد. در صورت نبود حساب مناسب، معامله شروع نمی‌شود.")
        } else Text("حالت دستی به رمز حساب Trendo نیاز ندارد. آموزش و پیش‌نمایش متن حتی بدون ورود تلگرام هم در دسترس‌اند.")
        Button(onClick = { try { vault.saveConfig(config().toString()); onNotice("تنظیمات رمزگذاری و ذخیره شد") } catch(e:Exception) { onError(e.message ?: "خطا") } }) { Text("ذخیرهٔ تنظیمات") }
        OutlinedButton(onClick = { scope.launch { busy = true; try { val c = config(); vault.saveConfig(c.toString()); val r = LocalEngine.call(ctx, "request_code", c.toString()); onNotice(if (r.optBoolean("authorized")) "نشست تلگرام از قبل وارد شده است" else if (r.optBoolean("code_sent")) "کد ورود درخواست شد؛ تلگرام را بررسی کنید" else "پاسخ درخواست ورود دریافت شد") } catch(e:Exception) { onError(e.message ?: "خطا") } finally { busy = false } } }, enabled = !busy) { Text("دریافت کد تلگرام") }
        OutlinedTextField(code, { code = it }, label = { Text("کد ورود") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(twofa, { twofa = it }, label = { Text("رمز دومرحله‌ای، در صورت فعال‌بودن") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Button(onClick = { scope.launch { busy = true; try { val r = LocalEngine.call(ctx, "verify_code", code, twofa); onNotice(if (r.optBoolean("password_required")) "رمز دومرحله‌ای لازم است؛ آن را وارد و دوباره تأیید کنید" else if (r.optBoolean("authorized")) "ورود تلگرام تأیید شد" else "ورود هنوز تأیید نشده است"); if (r.optBoolean("authorized")) { code = ""; twofa = "" } } catch(e:Exception) { onError(e.message ?: "خطا") } finally { busy = false } } }, enabled = !busy && code.isNotBlank()) { Text("تأیید کد") }
    }
    CardBlock {
        Text("نمایش و دسترسی", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(reduced, onReduced); Text("کاهش حرکت انیمیشن‌ها") }
        Info("اندروید ۱۵ و بالاتر برای سرویس dataSync محدودیت زمانی دارد. خاموشی شبکه، محدودیت باتری یا پایان مهلت سرویس می‌تواند موتور را متوقف کند. شروع دوباره فقط با اقدام شما انجام می‌شود.", Soft)
    }
}

private val lessons = listOf(
    "جهت و ناحیهٔ ورود" to "نمونهٔ آموزشی: خرید XAUUSD در ناحیهٔ ۲۳۵۰ تا ۲۳۵۱. قیمت اجرای خرید Ask است. اول نماد، جهت و ناحیه را با متن سیگنال تطبیق بده.",
    "حد ضرر پیش از ورود" to "استاپ نمونه ۲۳۴۷ است. حد ضرر خرید زیر ورود قرار می‌گیرد. سفارش بدون استاپ معتبر را ارسال نکن؛ فاصلهٔ استاپ مبنای حجم است.",
    "حجم با ریسک مشخص" to "ریسک دلاری = موجودی × درصد ریسک. حجم = ریسک دلاری ÷ (فاصلهٔ استاپ × ارزش هر واحد قیمت برای یک لات). مشخصات قرارداد و حداقل حجم بروکر را بررسی کن.",
    "حد سود و بازبینی" to "تارگت نمونه ۲۳۵۶ است. پیش از ارسال، حجم، استاپ و تارگت را دوباره بخوان. قیمت این تصویر ثابت و آموزشی است؛ سیگنال زنده نیست.",
    "تأیید بروکر و مدیریت" to "ارسال سفارش با پرشدن آن یکسان نیست. شناسه، قیمت واقعی ورود و حجم باز را از بروکر بررسی کن. بعد از بستن نیز تا تأیید صفرشدن حجم پیگیری کن."
)
@Composable internal fun Education(reduced: Boolean) {
    var step by remember { mutableIntStateOf(0) }
    val transition = rememberInfiniteTransition(label = "lesson")
    val pulse by transition.animateFloat(0.65f, 1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "pulse")
    Text("از سیگنال تا سفارش", fontSize = 25.sp, fontWeight = FontWeight.Bold)
    Info("آموزش تصویری ورود دستی • مثال فرضی خرید • بدون سفارش واقعی", Gold)
    CardBlock {
        Text("${step + 1} / 5   ${lessons[step].first}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Canvas(Modifier.fillMaxWidth().height(190.dp)) {
            val w = size.width; val h = size.height
            for (i in 1..4) drawLine(Color(0xFF253244), Offset(0f, h*i/5), Offset(w, h*i/5), 1f)
            val values = listOf(.72f,.68f,.74f,.58f,.62f,.55f,.57f,.40f,.45f,.32f,.36f,.19f)
            val path = Path(); values.forEachIndexed { i, v -> val x = i*w/(values.size-1); if(i==0) path.moveTo(x,h*v) else path.lineTo(x,h*v) }
            drawPath(path, Gold, style = Stroke(width = 5f, cap = StrokeCap.Round))
            drawLine(Mint.copy(alpha = if(reduced) 1f else pulse), Offset(0f,h*.55f),Offset(w,h*.55f),3f)
            if(step>=1) drawLine(Color(0xFFF28C96), Offset(0f,h*.85f),Offset(w,h*.85f),3f)
            if(step>=3) drawLine(Mint, Offset(0f,h*.15f),Offset(w,h*.15f),3f)
            drawCircle(Gold, if(reduced) 8f else 8f*pulse, Offset(w*.46f,h*.55f))
        }
        Text("ورود ۲۳۵۰–۲۳۵۱   •   استاپ ۲۳۴۷   •   تارگت ۲۳۵۶", color = Soft, fontSize = 12.sp)
        Text(lessons[step].second, lineHeight = 28.sp)
        LinearProgressIndicator(progress = { (step+1)/5f }, modifier = Modifier.fillMaxWidth(), color = Gold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { step = (step+1)%5 }) { Text(if(step==4) "از ابتدا" else "مرحلهٔ بعد") }
            OutlinedButton(onClick = { step-- }, enabled = step>0) { Text("قبلی") }
        }
    }
    CardBlock { Text("فری یعنی چه؟", color = Gold, fontWeight = FontWeight.Bold); Text("انتقال استاپ به ورود واقعی معامله، پس از رسیدن قیمت به شرط مناسب. قیمت ورود کانال ممکن است با ورود شما متفاوت باشد. کارمزد و لغزش می‌توانند حتی در خروج سربه‌سر، زیان کوچکی ایجاد کنند.") }
}
