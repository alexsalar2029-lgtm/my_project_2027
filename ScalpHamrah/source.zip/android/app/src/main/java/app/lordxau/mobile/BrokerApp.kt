package app.lordxau.mobile

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

data class BrokerApp(val packageName: String, val label: String)

@Suppress("DEPRECATION")
fun brokerCandidates(context: Context): List<BrokerApp> = context.packageManager
    .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
    .map { BrokerApp(it.activityInfo.packageName, it.loadLabel(context.packageManager).toString()) }
    .filter { it.packageName != context.packageName }.distinctBy { it.packageName }
    .sortedBy { it.label.lowercase() }

fun openBroker(context: Context, packageName: String) {
    require(packageName.isNotBlank()) { "ابتدا برنامهٔ Trendo نصب‌شده را انتخاب کنید" }
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        ?: error("برنامهٔ انتخاب‌شده نصب نیست یا قابل بازشدن نیست؛ دوباره آن را انتخاب کنید")
    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable fun BrokerAppControl(vault: SecureSettings, onError: (String) -> Unit) {
    val context = LocalContext.current
    var selected by remember { mutableStateOf(vault.brokerPackage) }
    var selecting by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(emptyList<BrokerApp>()) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("برنامهٔ بروکر روی گوشی")
        Text("نسخهٔ نصب‌شدهٔ Trendo را انتخاب کنید. بازکردن این برنامه، به‌تنهایی سفارشی ارسال نمی‌کند.")
        if (selected.isNotBlank()) Text(selected, style = MaterialTheme.typography.labelSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                try { apps = brokerCandidates(context); selecting = true }
                catch (_: Exception) { onError("فهرست برنامه‌ها خوانده نشد") }
            }) { Text("انتخاب برنامه") }
            Button(onClick = {
                try { openBroker(context, selected) }
                catch (e: Exception) { onError(e.message ?: "برنامه باز نشد") }
            }, enabled = selected.isNotBlank()) { Text("بازکردن Trendo") }
        }
    }
    if (selecting) AlertDialog(onDismissRequest = { selecting = false }, title = { Text("Trendo را از برنامه‌های نصب‌شده انتخاب کنید") }, text = {
        if (apps.isEmpty()) Text("برنامهٔ قابل انتخاب پیدا نشد. ابتدا Trendo را نصب کنید.")
        else LazyColumn(Modifier.heightIn(max = 360.dp)) { items(apps, key = { it.packageName }) { app ->
            TextButton(onClick = { vault.brokerPackage = app.packageName; selected = app.packageName; selecting = false }) {
                Column(Modifier.fillMaxWidth()) { Text(app.label); Text(app.packageName, style = MaterialTheme.typography.labelSmall) }
            }
        } }
    }, confirmButton = { TextButton(onClick = { selecting = false }) { Text("بستن") } })
}
