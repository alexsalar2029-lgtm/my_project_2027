package app.lordxau.mobile

import android.content.Context
import android.content.Intent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import java.util.Locale

internal class PersianVoice(context: Context) {
    var notice by mutableStateOf("آماده‌سازی صدای فارسی…")
        private set
    var ready by mutableStateOf(false)
        private set
    private var engine: TextToSpeech? = null
    private var closed = false
    private var initialized = false
    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            // OnInit is delivered asynchronously on the application's main thread.
            if (!closed) {
                initialized = status == TextToSpeech.SUCCESS
                refreshLanguage()
                engine?.setSpeechRate(.88f)
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { }
                    override fun onDone(id: String?) { }
                    @Deprecated("Android callback") override fun onError(id: String?) {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            if (!closed) notice = "پخش صدا انجام نشد؛ موتور گفتار یا اینترنت صدای انتخاب‌شده را بررسی کن."
                        }
                    }
                })
            }
        }
    }
    fun refreshLanguage() {
        val result = if (initialized) engine?.setLanguage(Locale.forLanguageTag("fa-IR")) else null
        ready = !closed && result != null && result >= TextToSpeech.LANG_AVAILABLE
        notice = if (ready) "صدای فارسی آماده است" else "صدای فارسی روی این گوشی نصب یا پشتیبانی نشده است؛ دادهٔ صدای فارسی را در تنظیمات گفتار بررسی کن."
    }
    fun speak(text: String) {
        if (ready) {
            val result = engine?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "lionxsec-lesson")
            if (result == TextToSpeech.ERROR) notice = "موتور گفتار نتوانست متن را بخواند."
        }
    }
    fun stop() { engine?.stop() }
    fun close() { closed = true; ready = false; engine?.stop(); engine?.shutdown(); engine = null }
}

@Composable internal fun rememberPersianVoice(): PersianVoice {
    val context = LocalContext.current
    val voice = remember { PersianVoice(context) }
    DisposableEffect(voice) {
        val owner = context as? androidx.lifecycle.LifecycleOwner
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) voice.refreshLanguage()
            if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) voice.stop()
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose { owner?.lifecycle?.removeObserver(observer); voice.close() }
    }
    return voice
}

@Composable internal fun VoiceControls(voice: PersianVoice, text: String) {
    val context = LocalContext.current
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { voice.speak(text) }, enabled = voice.ready, modifier = Modifier.testTag("speak-persian")) { Text("🔊 توضیح فارسی") }
        TextButton(onClick = { voice.stop() }) { Text("قطع صدا") }
    }
    Text(voice.notice, style = MaterialTheme.typography.bodySmall)
    if (!voice.ready) TextButton(onClick = {
        runCatching { context.startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            .recoverCatching { context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
    }) { Text("تنظیم صدای فارسی گوشی") }
}
