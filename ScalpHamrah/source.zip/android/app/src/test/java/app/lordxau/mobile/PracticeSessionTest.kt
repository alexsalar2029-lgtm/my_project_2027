package app.lordxau.mobile

import org.junit.Assert.*
import org.junit.Test

class PracticeSessionTest {
    private fun entered(scenario: String = "buy"): PracticeSession {
        val s = PracticeSession(scenario).wallet(true)
        return s.order(s.direction, "XAUUSD", .02, s.initialStop, s.target)
    }
    @Test fun wrongWalletDirectionAndStopNeverAdvance() {
        assertEquals(0, PracticeSession().wallet(false).phase)
        val s = PracticeSession().wallet(true)
        assertEquals(1, s.order("SELL", "XAUUSD", .02, 3906.0, 3912.0).phase)
        assertEquals(1, s.order("BUY", "EURUSD", .02, 3906.0, 3912.0).phase)
        assertEquals(1, s.order("BUY", "XAUUSD", 10.0, 3906.0, 3912.0).phase)
        assertEquals(1, s.order("BUY", "XAUUSD", .02, Double.NaN, 3912.0).phase)
    }
    @Test fun buyFreeUsesOwnFillAndPartialCloseStaysOpen() {
        val s = entered()
        assertEquals(2, s.free(3908.3).phase)
        val free = s.free(3908.5)
        assertEquals(3, free.phase)
        val half = free.close(true)
        assertEquals(.01, half.remaining, .000001)
        assertEquals(3, half.phase)
        assertEquals(1002.0, half.balance, .000001)
        assertEquals(1004.0, half.equity, .000001)
        val pending = half.close(false)
        assertTrue(pending.remaining > 0)
        assertEquals(0.0, pending.confirmClose().remaining, .000001)
        assertEquals(5, pending.confirmClose().phase)
        assertEquals(1004.0, pending.confirmClose().balance, .000001)
    }
    @Test fun sellFreeGoesBelowActualEntry() {
        val s = entered("sell")
        assertEquals(2, s.free(3908.1).phase)
        assertEquals(3907.5, s.freeStop, .000001)
        assertEquals(3, s.free(3907.5).phase)
    }
    @Test fun stopAndFreeHitAreNotNewEntryCommands() {
        val s = entered("stop")
        assertEquals(2, s.reenter().phase)
        assertEquals(0.0, s.checkHistory().remaining, .000001)
        assertEquals(995.6, s.checkHistory().balance, .000001)
        val f = entered("free_hit").free(3908.5)
        assertEquals(3, f.reenter().phase)
        assertEquals("استاپ فری", f.checkHistory().closedBy)
    }
    @Test fun noDoubleSubmissionOrPrematureCloseConfirmation() {
        val s = entered()
        assertEquals(s, s.order("BUY", "XAUUSD", .02, 3906.0, 3912.0))
        assertEquals(s, s.confirmClose())
        assertEquals(s, s.close(false))
    }
}
