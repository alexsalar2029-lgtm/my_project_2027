package app.lordxau.mobile
import org.junit.Assert.*
import org.junit.Test

class LessonRiskTest {
    @Test fun roundsDownToLotStep() {
        val r = LessonRisk.calculate(true, 1000.0, 1.0, 2351.0, 2347.0, 100.0, .01, .01)
        assertEquals(.02, r.lots!!, 1e-9)
        assertEquals(8.0, r.estimatedRisk!!, 1e-9)
    }
    @Test fun minimumExceedingBudgetIsRejected() {
        assertNull(LessonRisk.calculate(true, 100.0, 1.0, 2351.0, 2347.0, 100.0, .01, .01).lots)
    }
    @Test fun sellDirectionIsSupported() {
        assertEquals(.02, LessonRisk.calculate(false, 1000.0, 1.0, 2347.0, 2351.0, 100.0, .01, .01).lots!!, 1e-9)
    }
    @Test(expected = IllegalArgumentException::class) fun invertedStopIsRejected() {
        LessonRisk.calculate(false, 1000.0, 1.0, 2351.0, 2347.0, 100.0, .01, .01)
    }
    @Test(expected = IllegalArgumentException::class) fun nanIsRejected() {
        LessonRisk.calculate(true, Double.NaN, 1.0, 2351.0, 2347.0, 100.0, .01, .01)
    }
    @Test fun persianDecimalInput() { assertEquals(1.25, lessonNumber("۱٫۲۵"), 1e-9) }
}
