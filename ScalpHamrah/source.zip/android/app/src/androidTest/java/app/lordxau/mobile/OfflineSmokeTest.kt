package app.lordxau.mobile

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.chaquo.python.Python
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Runs without account credentials, broker login or Telegram traffic. */
@RunWith(AndroidJUnit4::class)
class OfflineSmokeTest {
    @get:Rule val ui = createAndroidComposeRule<MainActivity>()

    @Test fun defaultsToManualAndOffersEducation() {
        assertFalse(SecureSettings(ui.activity).automatic)
        ui.onNodeWithText("دستی و آموزشی").assertExists()
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithText("آکادمی LionXsec").assertExists()
        ui.onNodeWithTag("practice-start").assertExists()
        ui.onNodeWithText("Trendo").performClick()
        ui.onNodeWithText("آموزش متحرک ترندو").assertExists()
        ui.onNodeWithText("کارگاه حجم").performScrollTo().performClick()
        ui.onNodeWithText("کارگاه حجم؛ فقط تمرین").assertExists()
    }

    @Test fun embeddedPythonReadsSignalWithoutOpeningAnOrder() {
        LocalEngine.initialize(ui.activity)
        val python = Python.getInstance()
        val bridge = python.getModule("mobile_bridge")
        val reading = JSONObject(bridge.callAttr("preview", "Xau Buy Enter:4184/4185 SL:4181").toString())
        assertEquals("BUY", reading.getString("side"))
        assertEquals(4181.0, reading.getDouble("stop_loss"), .001)
        val status = JSONObject(bridge.callAttr("status").toString())
        assertEquals("manual", status.getString("execution_mode"))
        assertFalse(status.getBoolean("running"))
        python.getModule("android_trendo")
        python.getModule("mobile_executor")
        python.getModule("telethon")
        python.getModule("socketio")
    }

    @Test fun animatedCloseLessonRequiresConfirmationAndShowsRemainingVolume() {
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithText("Trendo").performClick()
        ui.onNodeWithTag("visual-close").performScrollTo().performClick()
        ui.onNodeWithTag("lesson-next").performClick()
        ui.onNodeWithTag("lesson-title").assertTextEquals("۲. بستن")
        ui.onNodeWithTag("lesson-next").performClick()
        ui.onNodeWithTag("lesson-title").assertTextEquals("۳. تأیید دوم")
        ui.onNodeWithTag("lesson-next").performClick()
        ui.onNodeWithTag("lesson-title").assertTextEquals("۴. پیگیری حجم باقی‌مانده")
        ui.onNodeWithTag("lesson-next").performClick()
        ui.onNodeWithTag("lesson-title").assertTextEquals("۵. خروج تأییدشده")
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun brokerLauncherRejectsMissingAppBeforeAnyEngineStart() {
        assertThrows(IllegalArgumentException::class.java) { brokerLaunchIntent(ui.activity, "") }
        assertThrows(IllegalStateException::class.java) { brokerLaunchIntent(ui.activity, "invalid.lionxsec.missing") }
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun demoAndRealWalletSelectionIsExplicit() {
        try {
            ui.onNodeWithText("خودکار").performScrollTo().performClick()
            ui.onNodeWithText("تنظیمات").performClick()
            ui.onNodeWithTag("setup-1").performClick()
            ui.onNodeWithText("مجازی • دمو").performScrollTo().assertIsSelected()
            ui.onNodeWithText("واقعی").performClick().assertIsSelected()
            ui.onNodeWithText("مجازی • دمو").performClick().assertIsSelected()
            assertFalse(LocalEngine.serviceActive.value)
        } finally { SecureSettings(ui.activity).automatic = false }
    }

    @Test fun modeSelectionIsLockedBeforeConnectionFinishes() {
        try {
            ui.runOnUiThread { LocalEngine.serviceActive.value = true }
            ui.onNodeWithText("خودکار").assertIsNotEnabled()
            ui.onNodeWithText("دستی و آموزشی").assertIsNotEnabled()
        } finally {
            ui.runOnUiThread { LocalEngine.serviceActive.value = false }
        }
    }
    @Test fun staleFailureDoesNotBreakStatusOrReport() {
        LocalEngine.initialize(ui.activity)
        val bridge = Python.getInstance().getModule("mobile_bridge")
        val config = JSONObject().put("storage_dir", ui.activity.filesDir.absolutePath).toString()
        bridge.callAttr("initialize", config)
        val failed = JSONObject(bridge.callAttr("audit_month").toString())
        assertEquals("telegram_settings_missing", failed.getString("error"))
        val status = JSONObject(bridge.callAttr("status").toString())
        assertTrue(status.getBoolean("ok"))
        assertFalse(status.has("error"))
        assertTrue(status.has("last_error"))
        JSONObject(bridge.callAttr("report").toString())
        bridge.callAttr("initialize", config)
    }

    @Test fun walletSetupIsAvailableInManualModeWithoutTelegramFields() {
        ui.onNodeWithText("تنظیمات").performClick()
        ui.onNodeWithTag("setup-1").performClick()
        ui.onNodeWithText("دریافت حساب‌های من از ترندو").performScrollTo().assertIsEnabled()
        ui.onNodeWithText("ایمیل Trendo").assertExists()
        ui.onNodeWithText("API ID").assertDoesNotExist()
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun passwordOnlyTelegramVerificationButtonIsAvailable() {
        ui.onNodeWithText("تنظیمات").performClick()
        ui.onNodeWithText("رمز دومرحله‌ای؛ اگر تلگرام درخواست کرد").performScrollTo().performTextInput("offline-example")
        ui.onNodeWithText("تأیید ورود").performScrollTo().assertIsEnabled()
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun visualBreakevenUsesOppositeOffsetForSellWithoutTrading() {
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithText("سیگنال‌خوانی").performScrollTo().performClick()
        ui.onNodeWithTag("visual-free").performScrollTo().performClick()
        repeat(3) { ui.onNodeWithTag("lesson-next").performClick() }
        ui.onNodeWithText("3908.30").assertExists()
        ui.onNodeWithText("فروش SELL").performScrollTo().performClick()
        ui.onNodeWithText("3907.70").assertExists()
        assertFalse(LocalEngine.serviceActive.value)
        ui.onNodeWithTag("visual-dismiss").performClick()
    }

    @Test fun practicalTradeRejectsWrongSideAndTeachesFullExit() {
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithTag("practice-start").performScrollTo().performClick()
        ui.onNodeWithTag("practice-demo").performScrollTo().performClick()
        ui.onNodeWithTag("practice-sl").performScrollTo().performTextInput("3906")
        ui.onNodeWithTag("practice-tp").performScrollTo().performTextInput("3912")
        ui.onNodeWithTag("practice-SELL").performScrollTo().performClick()
        ui.onNodeWithTag("practice-fill").assertDoesNotExist()
        ui.onNodeWithTag("practice-BUY").performScrollTo().performClick()
        ui.onNodeWithTag("practice-fill").assertTextEquals("ورود واقعیِ فرضی: 3908.20")
        ui.onNodeWithTag("practice-free-input").performScrollTo().performTextInput("3908.3")
        ui.onNodeWithTag("practice-free").performScrollTo().performClick()
        ui.onNodeWithTag("practice-close").assertDoesNotExist()
        ui.onNodeWithTag("practice-free-input").performScrollTo().performTextReplacement("3908.5")
        ui.onNodeWithTag("practice-free").performScrollTo().performClick()
        ui.onNodeWithTag("practice-half").performScrollTo().performClick()
        ui.onNodeWithTag("practice-volume").assertTextEquals("حجم باز: 0.01 لات")
        ui.onNodeWithTag("practice-close").performScrollTo().performClick()
        ui.onNodeWithTag("practice-confirm").performScrollTo().performClick()
        ui.onNodeWithTag("practice-complete").assertExists()
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun assistantExplainsStopHitAndOffersPersianVoice() {
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithText("دستیار فارسی").performScrollTo().performClick()
        ui.onNodeWithTag("term-استاپ خورد").performScrollTo().performClick()
        ui.onNodeWithTag("coach-answer").assertTextContains("دستور خرید یا فروش تازه نیست", substring = true)
        ui.onNodeWithTag("speak-persian").assertExists()
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun lotsLabShowsTenfoldRiskForTenfoldVolume() {
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithTag("lot-risk").performScrollTo().assertTextEquals("زیان نظری: 2.00 دلار")
        ui.onNodeWithTag("lot-1").performScrollTo().performClick()
        ui.onNodeWithTag("lot-ounces").assertTextEquals("اندازهٔ فرضی: 10 اونس طلا")
        ui.onNodeWithTag("lot-risk").assertTextEquals("زیان نظری: 20.00 دلار")
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun wakeLeaseHasExplicitLifetimeWithoutUnlockingDevice() {
        val lease = EngineWakeLease(ui.activity)
        try { lease.renew(); assertTrue(lease.held()); lease.renew(); assertTrue(lease.held()) }
        finally { lease.release() }
        assertFalse(lease.held())
        lease.release()
    }

    @Test fun syntheticFreshSignalRunsOnPythonLoopWithScreenOff() {
        // This proves local processing with the screen off, NOT real network
        // delivery or OEM endurance. No Telegram or broker login takes place.
        LocalEngine.initialize(ui.activity)
        val automation = androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().uiAutomation
        val lease = EngineWakeLease(ui.activity)
        fun shell(command: String) {
            val descriptor = automation.executeShellCommand(command)
            android.os.ParcelFileDescriptor.AutoCloseInputStream(descriptor).use { it.readBytes() }
        }
        try {
            lease.renew()
            shell("input keyevent KEYCODE_SLEEP")
            val power = ui.activity.getSystemService(android.os.PowerManager::class.java)
            val deadline = System.currentTimeMillis() + 3000
            while (power.isInteractive && System.currentTimeMillis() < deadline) Thread.sleep(50)
            assertFalse(power.isInteractive)
            val py = Python.getInstance()
            val ns = py.builtins.callAttr("dict")
            ns.callAttr("__setitem__", "scratch", java.io.File(ui.activity.cacheDir, "screen-probe").absolutePath)
            py.builtins.callAttr("exec", """
import json, time
from mobile_bridge import Runtime
from lordxau.engine import Engine, EngineConfig
from signal_trader.fastpoll import MessageRouter
class DemoOnly:
    def __init__(self): self.calls = []
    def live_quote_mid(self, symbol): return 3908.0
    async def execute(self, signal):
        self.calls.append(signal.side.value)
        return {'action': 'placed', 'order_id': 1}
r = Runtime()
try:
    r.configure(json.dumps({'storage_dir': scratch}))
    r.begin_live_session()
    r.active = True
    demo = DemoOnly()
    r.engine = Engine(demo, EngineConfig())
    r.engine.message_gate = r.message_gate
    r.router = MessageRouter(r.engine, lambda key, line: None)
    r.call(r.deliver(1, time.time(), 'Xau Buy Enter:3908 SL:3906'))
    received = len(demo.calls)
finally:
    r.call(r.stop())
    r.loop.call_soon_threadsafe(r.loop.stop)
    r.thread.join(2)
    r.loop.close()
""".trimIndent(), ns)
            assertEquals(1, ns.callAttr("__getitem__", "received").toInt())
        } finally {
            shell("input keyevent KEYCODE_WAKEUP")
            shell("wm dismiss-keyguard")
            lease.release()
        }
    }

    @Test fun onlineTutorHasNoTradingToolsAndDoesNotSaveResponses() {
        val request = OnlineEducation.request("فری یعنی چه؟")
        assertFalse(request.getBoolean("store"))
        assertFalse(request.has("tools"))
        assertFalse(request.has("api_key"))
        assertEquals("فری یعنی چه؟", request.getString("input"))
        val body = JSONObject("""{"status":"completed","output":[{"type":"message","content":[{"type":"output_text","text":"پاسخ آموزشی"}]}]}""")
        assertEquals("پاسخ آموزشی", OnlineEducation.response(body))
        assertThrows(IllegalStateException::class.java) { OnlineEducation.response(JSONObject("""{"status":"incomplete"}""")) }
    }

}
