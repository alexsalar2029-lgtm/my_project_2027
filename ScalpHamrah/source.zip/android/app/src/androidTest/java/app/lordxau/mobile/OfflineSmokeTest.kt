package app.lordxau.mobile

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.chaquo.python.Python
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Runs without account credentials, broker login or Telegram traffic. */
@RunWith(AndroidJUnit4::class)
class OfflineSmokeTest {
    @get:Rule val ui = createAndroidComposeRule<MainActivity>()

    @Test fun defaultsToManualAndOffersEducation() {
        assertFalse(SecureSettings(ui.activity).automatic)
        ui.onNodeWithText("دستی و آموزشی").assertExists()
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithText("آکادمی LionXsec").assertExists()
        ui.onNodeWithText("Trendo").performClick()
        ui.onNodeWithText("آموزش متحرک ترندو").assertExists()
        ui.onNodeWithText("تمرین").performClick()
        ui.onNodeWithText("کارگاه حجم؛ فقط تمرین").assertExists()
    }

    @Test fun embeddedPythonReadsSignalWithoutOpeningAnOrder() {
        LocalEngine.initialize(ui.activity)
        val python = Python.getInstance()
        val bridge = python.getModule("mobile_bridge")
        val reading = JSONObject(bridge.callAttr("preview", "Xau Buy Enter:4184/4185 SL:4181").toString())
        assertEquals("BUY", reading.getString("side"))
        assertEquals(4181.0, reading.getDouble("stop_loss"), .001)
        val status = JSONObject(bridge.callAttr("status").toString())
        assertEquals("manual", status.getString("execution_mode"))
        assertFalse(status.getBoolean("running"))
        python.getModule("android_trendo")
        python.getModule("mobile_executor")
        python.getModule("telethon")
        python.getModule("socketio")
    }

    @Test fun animatedCloseLessonRequiresConfirmationAndShowsRemainingVolume() {
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithText("Trendo").performClick()
        ui.onNodeWithTag("visual-close").performScrollTo().performClick()
        ui.onNodeWithTag("lesson-next").performClick()
        ui.onNodeWithTag("lesson-title").assertTextEquals("۲. بستن")
        ui.onNodeWithTag("lesson-next").performClick()
        ui.onNodeWithTag("lesson-title").assertTextEquals("۳. تأیید دوم")
        ui.onNodeWithTag("lesson-next").performClick()
        ui.onNodeWithTag("lesson-title").assertTextEquals("۴. پیگیری حجم باقی‌مانده")
        ui.onNodeWithTag("lesson-next").performClick()
        ui.onNodeWithTag("lesson-title").assertTextEquals("۵. خروج تأییدشده")
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun brokerLauncherRejectsMissingAppBeforeAnyEngineStart() {
        assertThrows(IllegalArgumentException::class.java) { brokerLaunchIntent(ui.activity, "") }
        assertThrows(IllegalStateException::class.java) { brokerLaunchIntent(ui.activity, "invalid.lionxsec.missing") }
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun demoAndRealWalletSelectionIsExplicit() {
        try {
            ui.onNodeWithText("خودکار").performScrollTo().performClick()
            ui.onNodeWithText("تنظیمات").performClick()
            ui.onNodeWithTag("setup-1").performClick()
            ui.onNodeWithText("مجازی • دمو").performScrollTo().assertIsSelected()
            ui.onNodeWithText("واقعی").performClick().assertIsSelected()
            ui.onNodeWithText("مجازی • دمو").performClick().assertIsSelected()
            assertFalse(LocalEngine.serviceActive.value)
        } finally { SecureSettings(ui.activity).automatic = false }
    }

    @Test fun modeSelectionIsLockedBeforeConnectionFinishes() {
        try {
            ui.runOnUiThread { LocalEngine.serviceActive.value = true }
            ui.onNodeWithText("خودکار").assertIsNotEnabled()
            ui.onNodeWithText("دستی و آموزشی").assertIsNotEnabled()
        } finally {
            ui.runOnUiThread { LocalEngine.serviceActive.value = false }
        }
    }
    @Test fun staleFailureDoesNotBreakStatusOrReport() {
        LocalEngine.initialize(ui.activity)
        val bridge = Python.getInstance().getModule("mobile_bridge")
        val config = JSONObject().put("storage_dir", ui.activity.filesDir.absolutePath).toString()
        bridge.callAttr("initialize", config)
        val failed = JSONObject(bridge.callAttr("audit_month").toString())
        assertEquals("telegram_settings_missing", failed.getString("error"))
        val status = JSONObject(bridge.callAttr("status").toString())
        assertTrue(status.getBoolean("ok"))
        assertFalse(status.has("error"))
        assertTrue(status.has("last_error"))
        JSONObject(bridge.callAttr("report").toString())
        bridge.callAttr("initialize", config)
    }

    @Test fun walletSetupIsAvailableInManualModeWithoutTelegramFields() {
        ui.onNodeWithText("تنظیمات").performClick()
        ui.onNodeWithTag("setup-1").performClick()
        ui.onNodeWithText("دریافت حساب‌های من از ترندو").performScrollTo().assertIsEnabled()
        ui.onNodeWithText("ایمیل Trendo").assertExists()
        ui.onNodeWithText("API ID").assertDoesNotExist()
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun passwordOnlyTelegramVerificationButtonIsAvailable() {
        ui.onNodeWithText("تنظیمات").performClick()
        ui.onNodeWithText("رمز دومرحله‌ای؛ اگر تلگرام درخواست کرد").performScrollTo().performTextInput("offline-example")
        ui.onNodeWithText("تأیید ورود").performScrollTo().assertIsEnabled()
        assertFalse(LocalEngine.serviceActive.value)
    }

    @Test fun visualBreakevenUsesOppositeOffsetForSellWithoutTrading() {
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithTag("visual-free").performScrollTo().performClick()
        repeat(3) { ui.onNodeWithTag("lesson-next").performClick() }
        ui.onNodeWithText("3908.30").assertExists()
        ui.onNodeWithText("فروش SELL").performScrollTo().performClick()
        ui.onNodeWithText("3907.70").assertExists()
        assertFalse(LocalEngine.serviceActive.value)
        ui.onNodeWithTag("visual-dismiss").performClick()
    }

}
