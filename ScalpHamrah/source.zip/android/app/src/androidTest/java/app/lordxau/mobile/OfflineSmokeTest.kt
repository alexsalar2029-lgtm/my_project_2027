package app.lordxau.mobile

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.chaquo.python.Python
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Runs without account credentials, broker login or Telegram traffic. */
@RunWith(AndroidJUnit4::class)
class OfflineSmokeTest {
    @get:Rule val ui = createAndroidComposeRule<MainActivity>()

    @Test fun defaultsToManualAndOffersEducation() {
        assertFalse(SecureSettings(ui.activity).automatic)
        ui.onNodeWithText("دستی و آموزشی").assertExists()
        ui.onNodeWithText("آموزش").performClick()
        ui.onNodeWithText("آکادمی LionXsec").assertExists()
        ui.onNodeWithText("Trendo").performClick()
        ui.onNodeWithText("ورود دستی در Trendo").assertExists()
        ui.onNodeWithText("تمرین").performClick()
        ui.onNodeWithText("کارگاه حجم؛ فقط تمرین").assertExists()
    }

    @Test fun embeddedPythonReadsSignalWithoutOpeningAnOrder() {
        LocalEngine.initialize(ui.activity)
        val python = Python.getInstance()
        val bridge = python.getModule("mobile_bridge")
        val reading = JSONObject(bridge.callAttr("preview", "Xau Buy Enter:4184/4185 SL:4181").toString())
        assertEquals("BUY", reading.getString("side"))
        assertEquals(4181.0, reading.getDouble("stop_loss"), .001)
        val status = JSONObject(bridge.callAttr("status").toString())
        assertEquals("manual", status.getString("execution_mode"))
        assertFalse(status.getBoolean("running"))
        python.getModule("android_trendo")
        python.getModule("mobile_executor")
        python.getModule("telethon")
        python.getModule("socketio")
    }

    @Test fun modeSelectionIsLockedBeforeConnectionFinishes() {
        try {
            ui.runOnUiThread { LocalEngine.serviceActive.value = true }
            ui.onNodeWithText("خودکار").assertIsNotEnabled()
            ui.onNodeWithText("دستی و آموزشی").assertIsNotEnabled()
        } finally {
            ui.runOnUiThread { LocalEngine.serviceActive.value = false }
        }
    }
}
