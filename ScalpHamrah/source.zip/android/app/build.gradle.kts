plugins { id("com.chaquo.python"); id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android {
    namespace = "app.lordxau.mobile"
    compileSdk = 36
    buildToolsVersion = "36.0.0"
    defaultConfig { applicationId = "app.lordxau.mobile"; minSdk = 26; targetSdk = 36; versionCode = 5; versionName = "0.5.0"; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"; ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64") } }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.04.01"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation(platform("androidx.compose:compose-bom:2025.04.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}

chaquopy {
    defaultConfig {
        version = "3.11"
        providers.environmentVariable("CHAQUOPY_BUILD_PYTHON").orNull?.let { buildPython(it) }
        pip {
            // Reproducible pure-Python wheels from PyPI; avoids a native desktop wheel.
            if (rootProject.file("python-wheels").isDirectory) {
                options("--no-index", "--find-links", rootProject.file("python-wheels").absolutePath)
            }
            install("telethon==1.36.0")
            install("python-socketio[client]==5.11.4")
            install("websocket-client==1.8.0")
            install("requests==2.32.3")
        }
    }
    sourceSets { getByName("main") {
        srcDir("../../engine")
        srcDir("../../mobile-runtime")
        include("lordxau/**/*.py", "signal_trader/**/*.py", "mobile_bridge.py", "mobile_executor.py", "mobile_seen.py", "android_trendo.py", "live_delivery.py")
    } }
}
