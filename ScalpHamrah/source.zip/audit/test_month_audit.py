import json
from datetime import datetime, timezone
from types import SimpleNamespace
from month_audit import read_messages, audit, trade_report, instant

START = datetime(2026, 10, 13, tzinfo=timezone.utc)
END = datetime(2026, 11, 12, tzinfo=timezone.utc)

def parse(text):
    return SimpleNamespace(kind='RESULT' if 'pip' in text else 'NOISE')

def test_export_rich_text_requires_explicit_channel(tmp_path):
    p = tmp_path/'result.json'
    p.write_text(json.dumps({'messages': [{'id': 1, 'date_unixtime': str(START.timestamp()), 'text': ['+', {'type': 'bold', 'text': '70'}, 'pip']}]}))
    assert read_messages([p], 'lordxau')[0] == []
    rows, skipped = read_messages([p], 'lordxau', 'lordxau')
    assert rows[0]['text'] == '+70pip'

def test_edits_dedup_and_window_exclusive_no_claim_sum(tmp_path):
    p = tmp_path/'messages.jsonl'
    base = {'channel': 'lordxau', 'id': 1, 'ts': START.timestamp(), 'recv': START.timestamp(), 'text': '+50pip'}
    edit = {**base, 'recv': START.timestamp()+100, 'text': '+70pip'}
    excluded = {**base, 'id': 2, 'ts': END.timestamp()}
    p.write_text('\n'.join(json.dumps(x) for x in [base, edit, excluded]))
    rows, skipped = read_messages([p], 'lordxau')
    result = audit(rows, skipped, START, END, 'lordxau', parse)
    assert result['message_count'] == 1
    assert result['repeated_or_edited_records'] == 1
    assert result['claimed_results'][0]['claimed_pips'] == [70.0]
    assert result['channel_verified_profit'] is None
    assert result['coverage_complete'] is False

def test_wrong_channel_and_naive_timestamp_rejected(tmp_path):
    p = tmp_path/'a.jsonl'
    p.write_text('\n'.join(json.dumps(x) for x in [
        {'id': 1, 'channel': 'other', 'ts': START.timestamp()},
        {'id': 2, 'channel': 'lordxau', 'date': '2026-10-15 00:00:00'}]))
    rows, skipped = read_messages([p], 'lordxau')
    assert not rows
    assert skipped['other_channels'] == skipped['missing_unambiguous_timestamp'] == 1

def test_no_month_data_is_unknown_not_zero_profit():
    result = audit([], {}, START, END, 'lordxau', parse)
    assert result['coverage_status'] == 'no_messages_in_requested_window'
    assert result['channel_verified_profit'] is None

def test_trade_dedup_keeps_known_and_separates_currencies(tmp_path):
    p = tmp_path/'trades.jsonl'
    base = {'id': 99, 'wallet': 5, 't': START.timestamp(), 'currency': 'USD', 'profit': None}
    p.write_text('\n'.join(json.dumps(x) for x in [base, {**base, 'profit': 2}, base,
                {**base, 'id': 100, 'currency': 'EUR', 'profit': -3},
                {**base, 'id': 101, 'profit': float('nan')}]))
    result = trade_report(p, START, END)
    groups = {g['currency']: g for g in result['groups']}
    assert groups['USD']['broker_reported_profit'] == 2
    assert groups['USD']['unknown'] == 1
    assert groups['EUR']['broker_reported_profit'] == -3

def test_instant_rejects_naive_datetime():
    assert instant('2026-10-01') is None
    assert instant('2026-10-01T00:00:00+03:30').hour == 20
