#!/usr/bin/env python3
"""Offline text audit, never sends trades. Python 3.10+; bundled engine required."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
import importlib.util
import json
import math
from pathlib import Path
import re
import sys
from zoneinfo import ZoneInfo

TEHRAN = ZoneInfo('Asia/Tehran')
DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')

def instant(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        if isinstance(value, (float, int)) or str(value).replace('.', '', 1).isdigit():
            return datetime.fromtimestamp(float(value), timezone.utc)
        parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        # Telegram exports normally supply date_unixtime; local-only dates are
        # ambiguous and are never silently assigned a timezone.
        return parsed.astimezone(timezone.utc) if parsed.tzinfo else None
    except (ValueError, OverflowError, OSError):
        return None

def text_of(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ''.join(x if isinstance(x, str) else str(x.get('text', ''))
                       for x in value if isinstance(x, (str, dict)))
    return ''

def read_messages(paths, channel, desktop_channel=None):
    rows, rejected = [], Counter()
    for path in paths:
        files = sorted(path.glob('messages-*.jsonl')) if path.is_dir() else [path]
        for file in files:
            try:
                if file.suffix.lower() == '.jsonl':
                    contents = []
                    for line in file.read_text(encoding='utf-8-sig').splitlines():
                        if not line.strip():
                            continue
                        try:
                            contents.append(json.loads(line))
                        except ValueError:
                            rejected['invalid_json_records'] += 1
                    desktop = False
                else:
                    body = json.loads(file.read_text(encoding='utf-8-sig'))
                    contents = body.get('messages', []) if isinstance(body, dict) else []
                    desktop = True
                    if desktop_channel != channel:
                        rejected['desktop_channel_not_attested'] += len(contents)
                        continue
                for sequence, row in enumerate(contents):
                    if not isinstance(row, dict):
                        rejected['invalid_records'] += 1
                        continue
                    source = desktop_channel if desktop else str(row.get('channel', '')).lstrip('@').lower()
                    if source != channel:
                        rejected['other_channels'] += 1
                        continue
                    when = instant(row.get('date_unixtime') if desktop else row.get('ts'))
                    when = when or instant(row.get('date'))
                    if when is None:
                        rejected['missing_unambiguous_timestamp'] += 1
                        continue
                    if row.get('id') is None:
                        rejected['missing_message_id'] += 1
                        continue
                    edit = instant(row.get('edited_unixtime')) if desktop else instant(row.get('recv'))
                    rows.append({'id': str(row['id']), 'when': when,
                                 'seen': edit or when, 'text': text_of(row.get('text')),
                                 'media': bool(row.get('photo') or row.get('file') or row.get('media_type')),
                                 'sequence': sequence})
            except (OSError, ValueError):
                rejected['unreadable_files'] += 1
    return rows, rejected

def finite(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (ValueError, TypeError):
        return None

def trade_report(path, start, end):
    if not path:
        return {'available': False, 'groups': [], 'notice': 'Broker trade evidence was not supplied.'}
    selected, invalid = {}, 0
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
            when = instant(row.get('t'))
            if when is None or row.get('id') is None:
                invalid += 1
                continue
            if not start <= when < end:
                continue
            key = (str(row.get('wallet')), str(row['id']))
            old = selected.get(key)
            if old is None or finite(row.get('profit')) is not None:
                selected[key] = row
        except (ValueError, TypeError, AttributeError):
            invalid += 1
    groups = defaultdict(list)
    for row in selected.values():
        groups[str(row.get('currency') or 'unknown')].append(finite(row.get('profit')))
    return {'available': bool(selected), 'invalid_records': invalid,
            'groups': [{'currency': currency, 'closed_trades': len(values),
                        'known_profit_count': sum(v is not None for v in values),
                        'unknown': sum(v is None for v in values),
                        'wins': sum(v > 0 for v in values if v is not None),
                        'losses': sum(v < 0 for v in values if v is not None),
                        'broker_reported_profit': round(sum(v for v in values if v is not None), 6)
                        if any(v is not None for v in values) else None}
                       for currency, values in sorted(groups.items())],
            'notice': 'Bot broker results only; excludes separate fees and open positions. Not channel performance.'}

def load_parser(engine):
    file = Path(engine) / 'lordxau' / 'parse.py'
    spec = importlib.util.spec_from_file_location('_month_channel_parser', file)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.parse

def audit(rows, rejected, start, end, channel, parse):
    latest = {}
    for row in rows:
        old = latest.get(row['id'])
        if old is None or row['seen'] >= old['seen']:
            latest[row['id']] = row
    selected = sorted((r for r in latest.values() if start <= r['when'] < end), key=lambda r: (r['when'], r['id']))
    kinds, by_day = Counter(), Counter()
    signals, claims, parser_errors = [], [], 0
    for row in selected:
        by_day[row['when'].astimezone(TEHRAN).date().isoformat()] += 1
        try:
            p = parse(row['text'])
            kinds[p.kind] += 1
            if p.kind in ('ZONE', 'SIGNAL'):
                signals.append({'message_id': row['id'], 'date': row['when'].isoformat(),
                                'kind': p.kind, 'side': p.side, 'entries': p.entries,
                                'stop_loss': p.sl, 'take_profits': p.tps})
            text = row['text'].translate(DIGITS)
            amounts = re.findall(r'([+-]\s*\d+(?:\.\d+)?)\s*pips?\b', text, re.I)
            if amounts:
                claims.append({'message_id': row['id'], 'date': row['when'].isoformat(),
                               'claimed_pips': [float(a.replace(' ', '')) for a in amounts],
                               'aggregate_possible': bool(re.search('برایند|برآیند|مجموع|total', text, re.I))})
        except Exception:
            parser_errors += 1
    dates = [r['when'] for r in latest.values()]
    return {'channel': '@'+channel,
            'period_start': start.astimezone(TEHRAN).isoformat(), 'period_end_exclusive': end.astimezone(TEHRAN).isoformat(),
            'timezone': 'Asia/Tehran', 'coverage_complete': False,
            'coverage_status': 'no_messages_in_requested_window' if not selected else 'supplied_records_only',
            'coverage_notice': 'An export or log alone cannot prove absence of deleted, inaccessible or uncollected messages. Media bodies have not been OCR/transcribed.',
            'source_rows_for_channel': len(rows), 'source_unique_ids': len(latest),
            'repeated_or_edited_records': len(rows)-len(latest),
            'source_earliest': min(dates).astimezone(TEHRAN).isoformat() if dates else None,
            'source_latest': max(dates).astimezone(TEHRAN).isoformat() if dates else None,
            'message_count': len(selected), 'messages_by_day': dict(sorted(by_day.items())),
            'classifications': dict(sorted(kinds.items())), 'signals': signals,
            'claimed_results': claims, 'channel_verified_profit': None,
            'claims_notice': 'Do not sum overlapping daily summaries and individual pip claims. Claims are not verified trades or currency profit.',
            'missing_for_verified_performance': ['complete signal/edit chronology', 'time-aligned bid/ask ticks', 'entry and exit execution rules', 'spread, fees and slippage'],
            'media_records_in_window': sum(r['media'] for r in selected),
            'parser_errors': parser_errors, 'rejected_records': dict(rejected)}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input', type=Path, action='append', required=True)
    ap.add_argument('--engine', type=Path, default=Path(__file__).resolve().parent.parent / 'engine')
    ap.add_argument('--channel', default='lordxau')
    ap.add_argument('--desktop-channel', help='Explicitly identify the channel of a Telegram Desktop export')
    ap.add_argument('--end', default=datetime.now(timezone.utc).isoformat(), help='Exclusive ISO timestamp with timezone')
    ap.add_argument('--days', type=int, default=30)
    ap.add_argument('--trades', type=Path)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    end = instant(args.end)
    if end is None or args.days <= 0:
        ap.error('--end must have a timezone and --days must be positive')
    start = end - timedelta(days=args.days)
    channel = args.channel.lstrip('@').lower()
    desktop = args.desktop_channel.lstrip('@').lower() if args.desktop_channel else None
    rows, rejected = read_messages(args.input, channel, desktop)
    report = audit(rows, rejected, start, end, channel, load_parser(args.engine))
    report['broker_results'] = trade_report(args.trades, start, end)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: report[k] for k in ('message_count', 'coverage_status', 'source_earliest', 'source_latest')}, ensure_ascii=False))

if __name__ == '__main__':
    main()
