"""Check packaged ABIs and ARM64 ELF alignment, including Chaquopy archives.

This checks binaries, not device compatibility. Run emulator/device tests too.
"""
import io
import json
from pathlib import Path
import struct
import sys
import zipfile


def load_alignments(data):
    assert data[:5] == b'\x7fELF\x02' and data[5] == 1, 'expected little-endian ELF64'
    offset = struct.unpack_from('<Q', data, 32)[0]
    entry_size, count = struct.unpack_from('<HH', data, 54)
    return [struct.unpack_from('<Q', data, offset + i * entry_size + 48)[0]
            for i in range(count) if struct.unpack_from('<I', data, offset + i * entry_size)[0] == 1]


def verify(path):
    checked = []
    with zipfile.ZipFile(path) as apk:
        abis = sorted({n.split('/')[1] for n in apk.namelist() if n.startswith('lib/') and n.endswith('.so')})
        assert {'arm64-v8a', 'armeabi-v7a', 'x86_64'} <= set(abis), abis
        binaries = [(n, apk.read(n)) for n in apk.namelist() if '/arm64-v8a/' in n and n.endswith('.so')]
        for name in apk.namelist():
            if name.endswith('-arm64-v8a.imy'):
                with zipfile.ZipFile(io.BytesIO(apk.read(name))) as bundle:
                    binaries += [(name + ':' + n, bundle.read(n)) for n in bundle.namelist() if n.endswith('.so')]
        assert binaries
        for name, data in binaries:
            alignments = load_alignments(data)
            assert alignments and min(alignments) >= 16384, (name, alignments)
            checked.append(name)
    print(json.dumps({'apk': Path(path).name, 'abis': abis, 'arm64_elfs_checked': len(checked),
                      'arm64_load_alignment_minimum': 16384,
                      'device_execution_tested_by_this_script': False}, indent=2))


if __name__ == '__main__':
    verify(sys.argv[1])
