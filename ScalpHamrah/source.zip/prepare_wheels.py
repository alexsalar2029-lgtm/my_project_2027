"""Build universal wheels from the pinned PyPI dependencies for Android.

Run with Python 3.11 before Gradle. This script does not log in to any account.
"""
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
target = root / 'android' / 'python-wheels'
target.mkdir(parents=True, exist_ok=True)
subprocess.run([sys.executable, '-m', 'pip', 'wheel', '--no-binary=charset-normalizer',
                '--wheel-dir', str(target), '-r', str(root / 'requirements-mobile.lock')],
               check=True, env={**os.environ, 'CHARSET_NORMALIZER_USE_MYPYC': '0'})
invalid = [p.name for p in target.glob('*.whl') if not p.name.endswith('-none-any.whl')]
if invalid:
    raise SystemExit('Non-universal wheels must not ship to Android: ' + ', '.join(invalid))
print('Universal Python wheels ready.')
