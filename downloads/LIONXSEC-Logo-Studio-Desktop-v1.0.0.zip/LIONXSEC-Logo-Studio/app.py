"""Launch LIONXSEC in a native desktop window. Never opens a browser tab."""
from pathlib import Path
import sys

from desktop_api import DesktopAPI, data_directory


def main():
    try:
        import webview
    except ImportError:
        print('Run START-LIONXSEC.cmd first to install the desktop dependencies.')
        return 1

    root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
    data_dir = data_directory()
    data_dir.mkdir(parents=True, exist_ok=True)
    api = DesktopAPI(data_dir)
    webview.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER'] = False
    webview.settings['ALLOW_DOWNLOADS'] = False  # Save As is handled by the local API.
    window = webview.create_window(
        'LIONXSEC | Logo Studio Desktop',
        url=str(root / 'ui/index.html'),
        js_api=api,
        width=1360,
        height=920,
        min_size=(800, 620),
        background_color='#101113',
        text_select=True,
    )
    api._window = window
    try:
        webview.start(
            gui='edgechromium' if sys.platform == 'win32' else None,
            http_server=True,
            private_mode=False,
            storage_path=str(data_dir / 'webview'),
            debug=False,
        )
    except Exception as error:
        print('The desktop window could not start:', error)
        if sys.platform == 'win32':
            print('Install Microsoft Edge WebView2 Runtime (Evergreen), then try again.')
            print('Official download: https://developer.microsoft.com/microsoft-edge/webview2/')
        print('See README_FA.md for setup instructions.')
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
