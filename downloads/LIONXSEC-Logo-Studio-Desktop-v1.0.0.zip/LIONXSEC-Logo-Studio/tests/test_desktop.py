import base64
import json
from pathlib import Path
import tempfile
import unittest

from desktop_api import DesktopAPI, check_design

DESIGN = dict(name='LIONXSEC', tagline='MAKE YOUR MARK', style='geometric', layout='stacked',
              color='#d9b875', text='#eae8e1', font='sora', spacing=6, size=100, bg='dark')


class DesktopTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.api = DesktopAPI(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_design_and_library_survive_reopening_application(self):
        self.assertIsNone(self.api.load_state()['design'])
        self.assertTrue(self.api.save_value('lionxsec.design.v1', DESIGN)['ok'])
        library = [{'id': 'one', 'state': {**DESIGN, 'name': 'شیر پارسی'}}]
        self.assertTrue(self.api.save_value('lionxsec.saved.v1', library)['ok'])
        reopened = DesktopAPI(self.root).load_state()
        self.assertEqual(reopened['design'], DESIGN)
        self.assertEqual(reopened['saved'], library)
        self.assertEqual(list(self.root.glob('.*')), [])

    def test_invalid_state_does_not_replace_good_data(self):
        self.api.save_value('lionxsec.design.v1', DESIGN)
        original = (self.root / 'designs.json').read_bytes()
        for key, data in [('unknown', {}), ('lionxsec.design.v1', {**DESIGN, 'color': '<script>'}),
                          ('lionxsec.saved.v1', [{'id': str(n), 'state': DESIGN} for n in range(13)])]:
            self.assertFalse(self.api.save_value(key, data)['ok'])
        self.assertEqual((self.root / 'designs.json').read_bytes(), original)

    def test_corrupt_state_is_not_silently_overwritten(self):
        path = self.root / 'designs.json'
        path.write_text('{broken', encoding='utf-8')
        self.assertFalse(self.api.load_state()['ok'])
        self.assertFalse(self.api.save_value('lionxsec.design.v1', DESIGN)['ok'])
        self.assertEqual(path.read_text(), '{broken')

    def test_native_save_uses_only_path_selected_in_dialog(self):
        target = self.root / 'chosen.svg'
        calls = []
        def choose(name, extension):
            calls.append((name, extension))
            return (str(target),)
        api = DesktopAPI(self.root, choose_file=choose)
        payload = b'<svg xmlns="http://www.w3.org/2000/svg"/>'
        result = api.save_file('lion.svg', base64.b64encode(payload).decode())
        self.assertTrue(result['ok'])
        self.assertFalse(result['cancelled'])
        self.assertEqual(target.read_bytes(), payload)
        self.assertEqual(calls, [('lion.svg', '.svg')])

    def test_cancel_is_not_reported_as_saved(self):
        api = DesktopAPI(self.root, choose_file=lambda *_: None)
        result = api.save_file('lion.svg', base64.b64encode(b'<svg/>').decode())
        self.assertTrue(result['cancelled'])
        self.assertEqual(list(self.root.iterdir()), [])

    def test_save_checks_format_and_extension_before_writing(self):
        path = self.root / 'different.png'
        api = DesktopAPI(self.root, choose_file=lambda *_: (str(path),))
        for name, data in [('lion.svg', '@@@'), ('../lion.svg', 'PHN2Zy8+'),
                           ('lion.exe', 'PHN2Zy8+'), ('lion.png', 'PHN2Zy8+')]:
            self.assertFalse(api.save_file(name, data)['ok'])
        self.assertEqual(api.save_file('lion.svg', 'PHN2Zy8+')['error'], 'extension_mismatch')
        self.assertFalse(path.exists())


if __name__ == '__main__':
    unittest.main()
