"""Runs the real pywebview JS bridge with a test-only file chooser on Linux Qt.
Optional QA: pip install 'pywebview[qt]==6.2.1'. The normal Windows app uses WebView2.
"""
import json
from pathlib import Path
import struct
import sys
import tempfile
import time
import traceback
import zipfile

import webview

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from desktop_api import DesktopAPI

result = {}


def run():
    with tempfile.TemporaryDirectory() as temp:
        directory = Path(temp)
        api = DesktopAPI(directory / 'data', choose_file=lambda name, extension: str(directory / name))
        window = webview.create_window('LIONXSEC desktop QA', str(ROOT / 'ui/index.html'),
                                       js_api=api, width=1280, height=900, hidden=True)
        api._window = window

        def wait(expression, seconds=25):
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                if window.evaluate_js(expression):
                    return
                time.sleep(.1)
            raise AssertionError('Timed out: ' + expression)

        def exercise():
            try:
                assert window.events.loaded.wait(30)
                wait('desktopReady && !!fonts.sora && !!fonts.orbitron && !!fonts.serif')
                window.evaluate_js("document.getElementById('brand-name').value='DESKTOP TEST';document.getElementById('brand-name').dispatchEvent(new Event('input'))")
                wait('nativeSaving === 0')
                assert api.load_state()['design']['name'] == 'DESKTOP TEST'
                window.evaluate_js("document.getElementById('save-design').click()")
                wait('saved.length === 1 && nativeSaving === 0')
                assert len(DesktopAPI(directory / 'data').load_state()['saved']) == 1
                window.evaluate_js("document.querySelector('[data-open-export]').click();document.getElementById('download-file').click()")
                wait("!document.getElementById('download-file').disabled")
                svg = directory / 'DESKTOP-TEST-geometric.svg'
                assert svg.exists(), window.evaluate_js("document.getElementById('toast').textContent")
                assert b'<svg' in svg.read_bytes()
                window.evaluate_js("document.getElementById('export-format').value='png';document.getElementById('export-format').dispatchEvent(new Event('input'));document.getElementById('download-file').click()")
                wait("!document.getElementById('download-file').disabled")
                png = (directory / 'DESKTOP-TEST-geometric.png').read_bytes()
                assert png.startswith(b'\x89PNG\r\n\x1a\n')
                assert struct.unpack('>II', png[16:24]) == (2048, 1536)
                window.evaluate_js("document.getElementById('download-kit').click()")
                wait("!document.getElementById('download-kit').disabled")
                with zipfile.ZipFile(directory / 'DESKTOP-TEST-geometric-brand-kit.zip') as z:
                    assert z.testzip() is None
                    assert len(z.namelist()) == 10
                api._choose_file = lambda *_: None
                window.evaluate_js("document.getElementById('download-file').click()")
                wait("!document.getElementById('download-file').disabled")
                assert 'لغو' in window.evaluate_js("document.getElementById('toast').textContent")
                result.update(ok=True, checks=['native window', 'real pywebview bridge', 'disk persistence',
                                              'saved designs', 'SVG save', 'PNG dimensions', 'brand ZIP', 'cancel feedback'])
            except Exception:
                result.update(ok=False, error=traceback.format_exc())
            finally:
                window.destroy()

        webview.start(exercise, gui='qt', http_server=True, private_mode=True,
                      storage_path=str(directory / 'webview'), debug=False)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result.get('ok') else 1


if __name__ == '__main__':
    raise SystemExit(run())
