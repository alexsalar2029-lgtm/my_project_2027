"""Local project persistence and native Save As; no network service or browser launch."""
import base64
import binascii
import json
import os
from pathlib import Path
import re
import tempfile
import threading

MAX_FILE_BYTES = 32 * 1024 * 1024
KEYS = {'lionxsec.design.v1': 'design', 'lionxsec.saved.v1': 'saved'}
COLOR = re.compile(r'^#[0-9a-fA-F]{6}$')


def data_directory():
    if os.name == 'nt':
        return Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local')) / 'LIONXSEC/LogoStudio'
    return Path(os.environ.get('XDG_DATA_HOME', Path.home() / '.local/share')) / 'lionxsec-logo-studio'


def check_design(value):
    if not isinstance(value, dict):
        raise ValueError('invalid_design')
    result = {}
    for name, maximum in [('name', 28), ('tagline', 60)]:
        text = value.get(name)
        if not isinstance(text, str) or len(text) > maximum or any(ord(c) < 32 for c in text):
            raise ValueError('invalid_design')
        result[name] = text
    for name in ['color', 'text']:
        if not isinstance(value.get(name), str) or not COLOR.fullmatch(value[name]):
            raise ValueError('invalid_color')
        result[name] = value[name]
    options = {
        'style': ['geometric', 'royal', 'minimal', 'shield', 'line', 'seal'],
        'layout': ['stacked', 'horizontal', 'icon'],
        'font': ['sora', 'orbitron', 'serif'],
        'bg': ['dark', 'light', 'checker'],
    }
    for name, choices in options.items():
        if value.get(name) not in choices:
            raise ValueError('invalid_design')
        result[name] = value[name]
    for name, lower, upper in [('spacing', 0, 16), ('size', 65, 125)]:
        number = value.get(name)
        if type(number) not in (int, float) or not lower <= number <= upper:
            raise ValueError('invalid_design')
        result[name] = number
    return result


def check_saved(value):
    if not isinstance(value, list) or len(value) > 12:
        raise ValueError('invalid_saved_designs')
    result = []
    for entry in value:
        if not isinstance(entry, dict) or not isinstance(entry.get('id'), str) or not 1 <= len(entry['id']) <= 80:
            raise ValueError('invalid_saved_designs')
        result.append({'id': entry['id'], 'state': check_design(entry.get('state'))})
    return result


def atomic_write(path, payload):
    """Write beside the destination before replacing it; keep old data on failure."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='wb', dir=path.parent, prefix='.' + path.name + '.', delete=False) as out:
            temporary = Path(out.name)
            out.write(payload)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


class DesktopAPI:
    def __init__(self, directory=None, choose_file=None):
        self._directory = Path(directory) if directory else data_directory()
        self._state_file = self._directory / 'designs.json'
        self._lock = threading.RLock()
        self._dialog_lock = threading.Lock()
        self._choose_file = choose_file
        self._window = None

    def _read(self):
        if not self._state_file.exists():
            return {'design': None, 'saved': []}
        if self._state_file.stat().st_size > 128 * 1024:
            raise ValueError('state_file_invalid')
        data = json.loads(self._state_file.read_text(encoding='utf-8'))
        if not isinstance(data, dict):
            raise ValueError('state_file_invalid')
        design = data.get('design')
        return {'design': check_design(design) if design is not None else None,
                'saved': check_saved(data.get('saved', []))}

    def load_state(self):
        with self._lock:
            try:
                return {'ok': True, **self._read()}
            except (OSError, ValueError, TypeError):
                return {'ok': False, 'error': 'state_read_failed'}

    def save_value(self, key, value):
        if key not in KEYS:
            return {'ok': False, 'error': 'unknown_key'}
        with self._lock:
            try:
                validated = check_design(value) if key.endswith('design.v1') else check_saved(value)
                current = self._read()
                current[KEYS[key]] = validated
                atomic_write(self._state_file, json.dumps(current, ensure_ascii=False).encode('utf-8'))
                return {'ok': True}
            except (OSError, ValueError, TypeError):
                return {'ok': False, 'error': 'state_save_failed'}

    def _show_save_dialog(self, name, extension):
        if self._choose_file:
            return self._choose_file(name, extension)
        import webview
        if self._window is None:
            return None
        return self._window.create_file_dialog(
            webview.FileDialog.SAVE,
            save_filename=name,
            file_types=(f'{extension[1:].upper()} files (*{extension})',),
        )

    def save_file(self, name, content_base64):
        if not isinstance(name, str) or len(name) > 160 or re.search(r'[<>:"/\\|?*\x00-\x1f]', name):
            return {'ok': False, 'error': 'invalid_filename'}
        extension = Path(name).suffix.lower()
        if extension not in ('.svg', '.png', '.zip') or not isinstance(content_base64, str):
            return {'ok': False, 'error': 'invalid_format'}
        if len(content_base64) > ((MAX_FILE_BYTES + 2) // 3) * 4:
            return {'ok': False, 'error': 'file_too_large'}
        try:
            data = base64.b64decode(content_base64, validate=True)
        except (binascii.Error, ValueError):
            return {'ok': False, 'error': 'invalid_file'}
        if not data or len(data) > MAX_FILE_BYTES:
            return {'ok': False, 'error': 'file_too_large'}
        if extension == '.png' and not data.startswith(b'\x89PNG\r\n\x1a\n'):
            return {'ok': False, 'error': 'invalid_file'}
        if extension == '.zip' and not data.startswith(b'PK\x03\x04'):
            return {'ok': False, 'error': 'invalid_file'}
        if extension == '.svg' and not data.lstrip().startswith(b'<svg'):
            return {'ok': False, 'error': 'invalid_file'}
        if not self._dialog_lock.acquire(blocking=False):
            return {'ok': False, 'error': 'dialog_busy'}
        try:
            selected = self._show_save_dialog(name, extension)
            if not selected:
                return {'ok': True, 'cancelled': True}
            selected = selected if isinstance(selected, str) else selected[0]
            destination = Path(selected)
            # The native dialog owns overwrite confirmation; never silently redirect to
            # another extension after that confirmation has been shown.
            if destination.suffix.lower() != extension:
                return {'ok': False, 'error': 'extension_mismatch'}
            atomic_write(destination, data)
            return {'ok': True, 'cancelled': False, 'name': destination.name}
        except OSError:
            return {'ok': False, 'error': 'file_save_failed'}
        finally:
            self._dialog_lock.release()
