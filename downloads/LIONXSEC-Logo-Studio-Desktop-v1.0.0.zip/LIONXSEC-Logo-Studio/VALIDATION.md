# Desktop v1.0.0 validation

- Python syntax compilation and JavaScript syntax checking passed.
- Six storage/file-save unit tests passed: persisted designs and library after reopening, rejected invalid writes, preserved corrupt input, exact file chooser destination, cancellation, and output format/extension validation.
- A real pywebview 6.2.1 window was launched with the Qt WebEngine backend on Linux. The real JavaScript-to-Python bridge passed native state initialization, disk auto-save, library save/reopen, SVG save, 2048 × 1536 PNG output, integrity of all ten files in the brand ZIP, and cancellation feedback. The test injects a file chooser to avoid requiring interactive input; it does not test a real Windows Save As dialog.
- The inherited visual editor was checked in Chromium at mobile, tablet and desktop sizes, including SVG paths, Persian font embedding, transparency, layouts and colors, before adding the native shell.
- Windows WebView2 and the Windows CMD launcher could not be executed in this Linux environment. The launcher targets Windows 10/11 with Python 3.10–3.13 and the WebView2 runtime.
- The distribution contains source, bundled UI assets, font/library licenses and tests. It excludes virtual environments, personal designs, runtime profiles, Git data, Site hosting configuration, credentials and test artifacts.
