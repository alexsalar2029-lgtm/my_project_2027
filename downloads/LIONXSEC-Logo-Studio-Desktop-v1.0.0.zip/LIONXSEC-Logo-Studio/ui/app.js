'use strict';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const fa = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
const xml = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const isRTL = value => /[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff]/.test(value);

const ICONS = {
  download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/>',
  vector:'<path d="M6 5h12M5 7v10m14-10v10M6 19h12"/><rect x="2" y="2" width="5" height="5" rx="1"/><rect x="17" y="2" width="5" height="5" rx="1"/><rect x="2" y="17" width="5" height="5" rx="1"/><rect x="17" y="17" width="5" height="5" rx="1"/><path d="m8 13 4-6 4 6-4 4Z"/>',
  undo:'<path d="M8 4 3 9l5 5M3 9h11a6 6 0 0 1 0 12h-3"/>',
  redo:'<path d="m16 4 5 5-5 5m5-5H10a6 6 0 0 0 0 12h3"/>',
  reset:'<path d="M4 11a8 8 0 1 1 2 6M4 4v7h7"/>',
  stacked:'<path d="M6 17h12M8 21h8"/><path d="m12 2 5 3-1 7-4 3-4-3-1-7Z"/>',
  horizontal:'<path d="M14 9h8m-8 5h6M6 5l4 3-1 8-3 3-3-3-1-8Z"/>',
  icononly:'<path d="m12 2 8 5-2 11-6 4-6-4L4 7Z"/>',
  bookmark:'<path d="M6 3h12v19l-6-4-6 4Z"/>',
  chevron:'<path d="m6 9 6 6 6-6"/>',
  close:'<path d="m6 6 12 12M6 18 18 6"/>',
  globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
  lock:'<rect x="6" y="10" width="12" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  package:'<path d="m3 7 9-5 9 5v10l-9 5-9-5Zm0 0 9 5 9-5M12 12v10M7 4.8l10 5.5"/>',
  trash:'<path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/>'
};
function icon(name) { return `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ''}</svg>`; }
$$('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); });

const STYLES = [
  {id:'geometric',name:'هندسی',en:'THE GEOMETRIC LION'},
  {id:'royal',name:'سلطنتی',en:'THE ROYAL LION'},
  {id:'minimal',name:'مینیمال',en:'THE MINIMAL LION'},
  {id:'shield',name:'سپر',en:'THE GUARDIAN LION'},
  {id:'line',name:'خطی',en:'THE LINEWORK LION'},
  {id:'seal',name:'نشان',en:'THE SIGNATURE LION'}
];
const PALETTES = [
  {name:'طلایی سلطنتی',color:'#d9b875',text:'#eae8e1'},
  {name:'نقره‌ای کلاسیک',color:'#c2cbd6',text:'#edf1f5'},
  {name:'یخی دیجیتال',color:'#79cfe5',text:'#e1eff3'},
  {name:'بنفش خلاق',color:'#ad9bdf',text:'#eae4f6'},
  {name:'سبز زمردی',color:'#83c3a1',text:'#e1efe7'},
  {name:'مرجانی گرم',color:'#e29e86',text:'#fae9e2'}
];
const DEFAULT = {name:'LIONXSEC',tagline:'MAKE YOUR MARK',style:'geometric',layout:'stacked',color:'#d9b875',text:'#eae8e1',font:'sora',spacing:6,size:100,bg:'dark'};
const COLOR_RE = /^#[0-9a-f]{6}$/i;
function normalize(value) {
  const result = {...DEFAULT};
  if (!value || typeof value !== 'object') return result;
  for (const [key,limit] of [['name',28],['tagline',60]]) {
    if (typeof value[key] === 'string') result[key] = value[key].replace(/[\u0000-\u001f]/g,'').slice(0,limit);
  }
  for (const key of ['color','text']) if (COLOR_RE.test(value[key])) result[key] = value[key].toLowerCase();
  const choices = {style:STYLES.map(x=>x.id),layout:['stacked','horizontal','icon'],font:['sora','orbitron','serif'],bg:['dark','light','checker']};
  for (const [key,values] of Object.entries(choices)) if (values.includes(value[key])) result[key] = value[key];
  if (Number.isFinite(value.spacing)) result.spacing = Math.max(0,Math.min(16,value.spacing));
  if (Number.isFinite(value.size)) result.size = Math.max(65,Math.min(125,value.size));
  return result;
}
let canStore = true, desktopReady = false, nativeSaving = 0;
let nativeWrites = Promise.resolve();
const nativeReady = new Promise(resolve=>{
  const ready=()=>{if(window.pywebview?.api)resolve(window.pywebview.api);};
  window.addEventListener('pywebviewready',ready,{once:true});ready();
});
function storageStatus(){
  $('#autosave-text').textContent=!canStore?'ذخیرهٔ طرح انجام نشد؛ خروجی لوگو را ذخیره کن':nativeSaving?'در حال ذخیره روی کامپیوتر…':'تغییرات روی این کامپیوتر ذخیره می‌شود';
}
async function writeStorage(key,value){
  if(!desktopReady)return false;
  const snapshot=JSON.parse(JSON.stringify(value));nativeSaving++;storageStatus();
  const operation=nativeWrites.then(()=>window.pywebview.api.save_value(key,snapshot));
  nativeWrites=operation.catch(()=>null);
  try{const result=await operation;if(!result?.ok)throw new Error('save_failed');canStore=true;return true;}
  catch{canStore=false;return false;}
  finally{nativeSaving--;storageStatus();}
}
let state = {...DEFAULT};
let saved = [];
let past = [], future = [], lastEdit = {key:'',time:0};
let frame = 0, toastTimer;

// All six symbols are original editable vector marks. No remote generation service.
function face(color,weight=4) {
  return `<g fill="none" stroke="${color}" stroke-width="${weight}" stroke-linejoin="miter" stroke-linecap="round">
    <path d="m68 67 13-16 20 12 19-6 19 6 20-12 13 16-12 36 7 28-16 29-31 24-31-24-16-29 7-28Z"/>
    <path d="m80 98 26 12-8 7-15-5m77-14-26 12 8 7 15-5M87 120l-3 16 16 19m53-35 3 16-16 19M120 149v15m-21-8 21 12 21-12"/>
    <path fill="${color}" stroke="none" d="m105 133 15-5 15 5-15 16Z"/>
    <path d="m93 73 13 15m41-15-13 15" opacity=".75"/>
  </g>`;
}
function geometric(color) {
  return `<g fill="none" stroke="${color}" stroke-width="3.6" stroke-linejoin="miter">
    <path d="m120 9 30 13 23 1 12 22 22 19-5 28 15 23-17 26-5 29-27 18-18 25-30 20-30-20-18-25-27-18-5-29-17-26 15-23-5-28 22-19 12-22 23-1Z"/>
    <path d="m90 22-8 29-27-6 13 22-24 24 25 40-24 39 44-10 1 53 30-29 30 29 1-53 44 10-24-39 25-40-24-24 13-22-27 6-8-29M69 131l-29 10m131-10 29 10M120 9v32" opacity=".8"/>
  </g>${face(color,4)}`;
}
function minimal(color) {
  return `<g fill="none" stroke="${color}" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"><path d="M86 35c-33 2-57 30-57 66 0 62 39 97 91 124 52-27 91-62 91-124 0-36-24-64-57-66M87 53q33-22 66 0"/><path d="m65 68 16-13 17 16q22-10 44 0l17-16 16 13-11 37q9 26-7 49l-37 31-37-31q-16-23-7-49Z"/><path d="m82 106 24 7m52-7-24 7m-30 22 16-3 16 3-16 15Zm16 15v13m-18-8 18 10 18-10M49 114q5 42 29 58m113-58q-5 42-29 58"/></g>`;
}
function line(color) {
  return `<g fill="none" stroke="${color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M120 15c-20 0-35 9-45 22-23-2-39 17-40 40-14 17-15 42-3 60-1 28 15 46 37 53 12 23 31 35 51 41 20-6 39-18 51-41 22-7 38-25 37-53 12-18 11-43-3-60-1-23-17-42-40-40-10-13-25-22-45-22Z"/><path d="M103 29C58 42 43 88 55 128M137 29c45 13 60 59 48 99M43 137q10 35 41 42m113-42q-10 35-41 42M78 187l27 24m57-24-27 24M62 55l12 12m104-12-12 12"/></g>${face(color,3)}`;
}
function symbolContents(style,color) {
  if(style==='geometric') return geometric(color);
  if(style==='minimal') return minimal(color);
  if(style==='line') return line(color);
  if(style==='royal') return `<g fill="none" stroke="${color}" stroke-width="4" stroke-linejoin="miter"><path d="m64 22 22 16 34-31 34 31 22-16-10 39H74Z"/><path d="M79 69h82M61 81l-22 25 9 39 22 30 50 57 50-57 22-30 9-39-22-25M50 110l18 19-3 29m125-48-18 19 3 29M91 192l29 20 29-20"/></g><g transform="translate(21 41) scale(.825)">${face(color,4.5)}</g>`;
  if(style==='shield') return `<g fill="none" stroke="${color}" stroke-width="4" stroke-linejoin="miter"><path d="M120 9 26 46l6 90q8 50 88 96 80-46 88-96l6-90Z"/><path d="m120 24-79 32 6 78q7 40 73 80 66-40 73-80l6-78Z" stroke-width="1.8"/><path d="M120 24v19m0 153v18"/></g><g transform="translate(18 18) scale(.85)">${face(color,4.8)}</g>`;
  return `<g fill="none" stroke="${color}"><circle cx="120" cy="120" r="106" stroke-width="3"/><circle cx="120" cy="120" r="96" stroke-width="1.3"/><path d="M120 8v14m0 196v14M8 120h14m196 0h14" stroke-width="4"/><path d="m45 45 5 5m140 140 5 5m0-150-5 5M50 190l-5 5" stroke-width="2"/></g><g transform="translate(25 26) scale(.79)">${geometric(color)}</g>`;
}
function symbolSVG(style,color) {return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" aria-hidden="true">${symbolContents(style,color)}</svg>`;}

const fonts = {};
let arabicFontData = '';
let fontError = false;
async function loadFont(name) {
  const response = await fetch(`assets/${name}-logo.ttf`);
  if(!response.ok) throw new Error('font_missing');
  const buffer = await response.arrayBuffer();
  fonts[name] = opentype.parse(buffer);
}
const fontReady = Promise.all(['sora','orbitron','serif'].map(loadFont)).then(()=>{scheduleRender();return true;}).catch(()=>{fontError=true;scheduleRender();return false;});
async function embedArabicFont() {
  if(arabicFontData) return arabicFontData;
  const response = await fetch('assets/vazirmatn.ttf');
  if(!response.ok) throw new Error('font_missing');
  const bytes = new Uint8Array(await response.arrayBuffer());
  let binary = ''; for (let i=0;i<bytes.length;i+=8192) binary += String.fromCharCode(...bytes.subarray(i,i+8192));
  arabicFontData = btoa(binary); return arabicFontData;
}

function textElement(text,x,y,size,maxWidth,color,fontName,spacing=0) {
  if(!text.trim()) return '';
  const rtl = isRTL(text);
  const font = fonts[fontName];
  if(font && !rtl && [...text].every(char=>font.charToGlyphIndex(char)!==0 || /\s/.test(char))) {
    const baseWidth=font.getAdvanceWidth(text,size,{kerning:true})+Math.max(0,[...text].length-1)*spacing;
    const scale=Math.min(1,maxWidth/(baseWidth || 1));
    const fittedSize=size*scale, fittedSpacing=spacing*scale;
    const glyphs=font.stringToGlyphs(text);
    let cursor=x-(baseWidth*scale/2), path='';
    for(let i=0;i<glyphs.length;i++){
      const glyph=glyphs[i];
      path+=glyph.getPath(cursor,y,fittedSize).toPathData(2);
      cursor+=(glyph.advanceWidth||0)*fittedSize/font.unitsPerEm + (i<glyphs.length-1 ? fittedSpacing : 0);
      if(i<glyphs.length-1) cursor+=font.getKerningValue(glyph,glyphs[i+1])*fittedSize/font.unitsPerEm;
    }
    return `<path fill="${color}" d="${path}"/>`;
  }
  const estimate=[...text].length*size*(rtl ? .64 : .66)+(rtl?0:spacing*Math.max(0,text.length-1));
  const fitted=Math.min(size,size*maxWidth/(estimate||1));
  const family=rtl?'LogoArabic, Vazirmatn, Arial':fontName==='serif'?'Georgia, serif':fontName==='orbitron'?'Orbitron, Arial':'Sora, Arial';
  return `<text x="${x}" y="${y}" text-anchor="middle" direction="${rtl?'rtl':'ltr'}" font-family="${family}" font-size="${fitted}" font-weight="600" letter-spacing="${rtl?0:spacing*fitted/size}" fill="${color}">${xml(text)}</text>`;
}
function logoSVG(config=state,options={}) {
  const c=normalize(config), layout=options.layout || c.layout;
  const markOnly=layout==='icon';
  const w=markOnly?800:1200,h=markOnly?800:layout==='horizontal'?450:900;
  const color=options.monochrome || c.color, textColor=options.monochrome || c.text;
  const scale=c.size/100;
  let content='';
  if(markOnly){ const size=620*scale;content=`<g transform="translate(${(w-size)/2} ${(h-size)/2}) scale(${size/240})">${symbolContents(c.style,color)}</g>`; }
  else if(layout==='horizontal') {
    const size=255*scale;
    content=`<g transform="translate(${205-size/2} ${(h-size)/2}) scale(${size/240})">${symbolContents(c.style,color)}</g>`;
    content+=textElement(c.name,760,c.tagline?225:248,72,700,textColor,c.font,c.spacing*.65);
    if(c.tagline) content+=textElement(c.tagline,760,278,20,630,color,'sora',4);
  } else {
    const size=330*scale;
    const cy=c.name.trim()?348:430;
    content=`<g transform="translate(${600-size/2} ${cy-size/2}) scale(${size/240})">${symbolContents(c.style,color)}</g>`;
    content+=textElement(c.name,600,608,74,990,textColor,c.font,c.spacing);
    if(c.tagline) content+=textElement(c.tagline,600,667,19,900,color,'sora',5);
  }
  const embedded=options.embed && arabicFontData && (isRTL(c.name)||isRTL(c.tagline)) ? `<defs><style>@font-face{font-family:LogoArabic;src:url(data:font/ttf;base64,${arabicFontData}) format('truetype');font-weight:100 900;}</style></defs>`:'';
  const background=options.background && COLOR_RE.test(options.background)?`<rect width="${w}" height="${h}" fill="${options.background}"/>`:'';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" role="img" aria-label="${xml(c.name||'Lion logo')}"><title>${xml(c.name||'Lion logo')}</title>${embedded}${background}${content}</svg>`;
}

function showToast(message) { clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').hidden=false;toastTimer=setTimeout(()=>{$('#toast').hidden=true;},4200); }
function scheduleRender() { if(!frame) frame=requestAnimationFrame(()=>{frame=0;render();}); }
function update(patch,key=Object.keys(patch).join(',')) {
  const next=normalize({...state,...patch});
  if(JSON.stringify(next)===JSON.stringify(state)) return;
  const now=Date.now();
  if(key!==lastEdit.key || now-lastEdit.time>650){past.push({...state});if(past.length>60)past.shift();}
  lastEdit={key,time:now};future=[];state=next;persist();scheduleRender();
}
function persist(){writeStorage('lionxsec.design.v1',state);}
function syncFields(){
  const values={'brand-name':state.name,tagline:state.tagline,'primary-color':state.color,'text-color':state.text,font:state.font,spacing:state.spacing,'symbol-size':state.size};
  for(const [id,value] of Object.entries(values))if($('#'+id).value!==String(value))$('#'+id).value=value;
}
function render() {
  syncFields();
  $('#name-count').textContent=state.name.length+'/28';
  $('#primary-hex').textContent=state.color.toUpperCase();$('#text-hex').textContent=state.text.toUpperCase();
  $('#spacing-output').textContent=fa(state.spacing);$('#size-output').textContent=fa(state.size)+'٪';
  const activePalette=PALETTES.find(p=>p.color===state.color&&p.text===state.text);
  $('#palette-label').textContent=activePalette?.name || 'رنگ‌های شما';
  $$('[data-palette]').forEach(el=>{const active=PALETTES[el.dataset.palette]===activePalette;el.classList.toggle('selected',active);el.setAttribute('aria-pressed',String(active));});
  $$('[data-layout]').forEach(el=>{const active=el.dataset.layout===state.layout;el.classList.toggle('selected',active);el.setAttribute('aria-pressed',String(active));});
  $$('[data-style]').forEach(el=>{const active=el.dataset.style===state.style;el.classList.toggle('selected',active);el.setAttribute('aria-pressed',String(active));$('.symbol',el).innerHTML=symbolSVG(el.dataset.style,state.color);});
  $$('[data-bg]').forEach(el=>{const active=el.dataset.bg===state.bg;el.classList.toggle('selected',active);el.setAttribute('aria-pressed',String(active));});
  $('#canvas').className='canvas '+state.bg;
  $('#logo-preview').innerHTML=logoSVG();
  const index=STYLES.findIndex(s=>s.id===state.style);
  $('#style-index').textContent=String(index+1).padStart(2,'0')+' — '+STYLES[index].en;
  $('.canvas-dim').textContent=state.layout==='icon'?'800 × 800':state.layout==='horizontal'?'1200 × 450':'1200 × 900';
  $('#website-logo').innerHTML=logoSVG({...state,size:105,tagline:''},{layout:'horizontal'});
  $('#favicon-preview').innerHTML=symbolSVG(state.style,state.color);
  $('#tab-brand').textContent=state.name || 'برند شما';
  $('#undo').disabled=!past.length;$('#redo').disabled=!future.length;
  storageStatus();
  if($('#export-dialog').open)renderExport();
}
function undo(){if(!past.length)return;future.push({...state});state=past.pop();lastEdit={key:'',time:0};persist();render();}
function redo(){if(!future.length)return;past.push({...state});state=future.pop();lastEdit={key:'',time:0};persist();render();}

$('#palettes').innerHTML=PALETTES.map((p,i)=>`<button class="palette" data-palette="${i}" style="background:${p.color}" title="${p.name}" aria-label="${p.name}" aria-pressed="false"></button>`).join('');
$('#templates').innerHTML=STYLES.map(s=>`<button class="template" data-style="${s.id}" aria-label="شیر ${s.name}" aria-pressed="false"><span class="symbol"></span><span>${s.name}</span></button>`).join('');
$('#brand-mark').innerHTML=symbolSVG('geometric',DEFAULT.color);
$$('[data-layout]').forEach(el=>el.addEventListener('click',()=>update({layout:el.dataset.layout},'layout')));
$$('[data-style]').forEach(el=>el.addEventListener('click',()=>update({style:el.dataset.style},'style')));
$$('[data-bg]').forEach(el=>el.addEventListener('click',()=>update({bg:el.dataset.bg},'bg')));
$$('[data-palette]').forEach(el=>el.addEventListener('click',()=>{const p=PALETTES[el.dataset.palette];update({color:p.color,text:p.text},'palette');}));
for(const [id,key] of [['brand-name','name'],['tagline','tagline'],['primary-color','color'],['text-color','text'],['font','font'],['spacing','spacing'],['symbol-size','size']]) {
  $('#'+id).addEventListener('input',e=>update({[key]:['spacing','size'].includes(key)?Number(e.target.value):e.target.value},key));
}
$('#undo').addEventListener('click',undo);$('#redo').addEventListener('click',redo);
$('#reset').addEventListener('click',()=>{update({...DEFAULT},'reset');showToast('طرح اولیه برگشت؛ با واگرد می‌توانی طرح قبلی را برگردانی.');});
document.addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'&&!/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)){e.preventDefault();e.shiftKey?redo():undo();}
});

function renderSaved(){
  $('#saved-count').textContent=fa(saved.length);
  const root=$('#saved-designs');root.replaceChildren();
  if(!saved.length){root.innerHTML='<p class="empty-saved">هنوز طرحی ذخیره نکرده‌ای. روی «ذخیرهٔ طرح» زیر پیش‌نمایش بزن.</p>';return;}
  for(const entry of saved){
    const card=document.createElement('div');card.className='saved-card';
    const button=document.createElement('button');button.innerHTML=logoSVG(entry.state);button.setAttribute('aria-label','باز کردن '+(entry.state.name||'طرح'));
    button.addEventListener('click',()=>{update(entry.state,'saved');$('#editor').scrollIntoView({behavior:'smooth'});showToast('طرح ذخیره‌شده باز شد.');});
    const meta=document.createElement('div');meta.className='saved-meta';
    const name=document.createElement('span');name.textContent=entry.state.name||'بدون نام';
    const remove=document.createElement('button');remove.className='icon-button';remove.setAttribute('aria-label','حذف طرح '+(entry.state.name||''));remove.innerHTML=`<span class="icon">${icon('trash')}</span>`;
    remove.addEventListener('click',async()=>{remove.disabled=true;const next=saved.filter(x=>x.id!==entry.id);if(!await writeStorage('lionxsec.saved.v1',next)){remove.disabled=false;showToast('ذخیرهٔ تغییر روی کامپیوتر انجام نشد.');return;}saved=next;renderSaved();showToast('طرح از فهرست ذخیره‌ها حذف شد.');});
    meta.append(name,remove);card.append(button,meta);root.append(card);
  }
}
$('#save-design').addEventListener('click',async()=>{
  if(saved.some(x=>JSON.stringify(x.state)===JSON.stringify(state))){showToast('این طرح قبلاً ذخیره شده است.');return;}
  if(saved.length>=12){showToast('۱۲ طرح ذخیره شده است؛ ابتدا یکی را از «طرح‌های من» حذف کن.');openSaved();return;}
  const next=[{id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),state:{...state}},...saved];
  $('#save-design').disabled=true;
  const stored=await writeStorage('lionxsec.saved.v1',next);$('#save-design').disabled=false;
  if(!stored){showToast('ذخیرهٔ طرح روی کامپیوتر انجام نشد؛ خروجی لوگو را ذخیره کن.');render();return;}
  saved=next;renderSaved();showToast('طرح در «طرح‌های من» ذخیره شد.');
});
function openSaved(){renderSaved();$('#saved-section').hidden=false;$('#saved-section').scrollIntoView({behavior:'smooth',block:'start'});}
$('#nav-saved').addEventListener('click',openSaved);
$('#nav-studio').addEventListener('click',()=>$('#editor').scrollIntoView({behavior:'smooth'}));
$('#close-saved').addEventListener('click',()=>{$('#saved-section').hidden=true;$('#nav-saved').focus();});
$('#help-open').addEventListener('click',()=>$('#help-dialog').showModal());
$$('[data-close]').forEach(el=>el.addEventListener('click',()=>$('#'+el.dataset.close).close()));
$$('dialog').forEach(el=>el.addEventListener('click',e=>{if(e.target===el){const rect=el.getBoundingClientRect();if(e.clientX<rect.left||e.clientX>rect.right||e.clientY<rect.top||e.clientY>rect.bottom)el.close();}}));

function exportOptions(){return {embed:true,layout:$('#export-format').value==='favicon'?'icon':state.layout,background:$('#transparent').checked?null:$('#export-bg').value};}
function renderExport(){
  const format=$('#export-format').value;
  $('#export-preview').innerHTML=logoSVG(state,exportOptions());
  $('#export-bg-label').hidden=$('#transparent').checked;
  $('#export-size').disabled=format==='svg'||format==='favicon';
  $('#download-label').textContent=format==='favicon'?'دانلود آیکون ۵۱۲ پیکسل':'دانلود '+format.toUpperCase();
  $('#format-note').textContent=format==='svg'?'قابل استفاده در سایت و نرم‌افزارهای طراحی؛ حروف انگلیسی به مسیر برداری تبدیل می‌شوند.':format==='favicon'?'یک آیکون مربعی ۵۱۲ × ۵۱۲ از نماد شیر؛ مناسب سایت و پروفایل.':'تصویر با نسبت اصلی طرح ذخیره می‌شود؛ اندازهٔ انتخابی، عرض فایل است.';
}
$$('[data-open-export]').forEach(el=>el.addEventListener('click',()=>{$('#export-dialog').showModal();renderExport();}));
for(const id of ['export-format','transparent','export-bg','export-size'])$('#'+id).addEventListener('input',renderExport);
async function prepareExport(){
  const ok=await fontReady;
  if(!ok||fontError)throw new Error('font_missing');
  if(isRTL(state.name)||isRTL(state.tagline))await embedArabicFont();
}
function fileName(){return (state.name.trim().replace(/[^\p{L}\p{N}_-]/gu,'-').replace(/-+/g,'-')||'lionxsec')+'-'+state.style;}
async function download(blob,name){
  if(!desktopReady)throw new Error('desktop_unavailable');
  const bytes=new Uint8Array(await blob.arrayBuffer());
  let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  const result=await window.pywebview.api.save_file(name,btoa(binary));
  if(!result?.ok)throw new Error(result?.error||'file_save_failed');
  return !result.cancelled;
}
async function raster(svg,width){
  const parsed=new DOMParser().parseFromString(svg,'image/svg+xml').documentElement;
  const [, ,w,h]=parsed.getAttribute('viewBox').split(' ').map(Number);
  // Set the image viewport to output pixels before rasterization, keeping the vector viewBox.
  parsed.setAttribute('width',String(width));parsed.setAttribute('height',String(Math.round(width*h/w)));
  const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(parsed)],{type:'image/svg+xml;charset=utf-8'}));
  try{
    const image=new Image();image.src=url;await image.decode();
    const canvas=document.createElement('canvas');canvas.width=width;canvas.height=Math.round(width*h/w);
    const context=canvas.getContext('2d');context.drawImage(image,0,0,canvas.width,canvas.height);
    return await new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('png_failed')),'image/png'));
  }finally{URL.revokeObjectURL(url);}
}
async function withBusy(button,work){
  if(button.disabled)return;button.disabled=true;button.setAttribute('aria-busy','true');
  try{await work();}catch(error){const messages={font_missing:'فونت‌ها پیدا نشدند؛ پوشهٔ پروژه را کامل از ZIP استخراج کن.',desktop_unavailable:'برنامه را با START-LIONXSEC.cmd اجرا کن.',extension_mismatch:'پسوند فایل را در Save As تغییر نده؛ دوباره ذخیره کن.',dialog_busy:'ابتدا پنجرهٔ ذخیرهٔ قبلی را ببند.'};showToast(messages[error.message]||'ذخیرهٔ فایل انجام نشد؛ مسیر را بررسی کن و دوباره تلاش کن.');}
  finally{button.disabled=false;button.removeAttribute('aria-busy');}
}
$('#download-file').addEventListener('click',()=>withBusy($('#download-file'),async()=>{
  await prepareExport();const format=$('#export-format').value;
  const svg=logoSVG(state,exportOptions());
  const completed=format==='svg'
    ?await download(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}),fileName()+'.svg')
    :await download(await raster(svg,format==='favicon'?512:Number($('#export-size').value)),fileName()+(format==='favicon'?'-favicon':'')+'.png');
  showToast(completed?'فایل روی کامپیوتر ذخیره شد.':'ذخیرهٔ فایل لغو شد.');
}));

// Small uncompressed ZIP writer. All work stays in the browser; no upload is required.
const crcTable=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crc32(data){let crc=0xffffffff;for(const byte of data)crc=crcTable[(crc^byte)&255]^(crc>>>8);return(crc^0xffffffff)>>>0;}
async function makeZip(files){
  const enc=new TextEncoder(),chunks=[],directory=[];let offset=0,dirSize=0;
  const today=new Date(),time=(today.getHours()<<11)|(today.getMinutes()<<5)|(today.getSeconds()>>1),date=((Math.max(1980,today.getFullYear())-1980)<<9)|((today.getMonth()+1)<<5)|today.getDate();
  for(const [name,body] of Object.entries(files)){
    const filename=enc.encode(name),data=body instanceof Blob?new Uint8Array(await body.arrayBuffer()):enc.encode(body),crc=crc32(data);
    const header=new Uint8Array(30),h=new DataView(header.buffer);h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint16(10,time,true);h.setUint16(12,date,true);h.setUint32(14,crc,true);h.setUint32(18,data.length,true);h.setUint32(22,data.length,true);h.setUint16(26,filename.length,true);
    const central=new Uint8Array(46),c=new DataView(central.buffer);c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint16(12,time,true);c.setUint16(14,date,true);c.setUint32(16,crc,true);c.setUint32(20,data.length,true);c.setUint32(24,data.length,true);c.setUint16(28,filename.length,true);c.setUint32(42,offset,true);
    chunks.push(header,filename,data);directory.push(central,filename);offset+=30+filename.length+data.length;dirSize+=46+filename.length;
  }
  const end=new Uint8Array(22),e=new DataView(end.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,directory.length/2,true);e.setUint16(10,directory.length/2,true);e.setUint32(12,dirSize,true);e.setUint32(16,offset,true);
  return new Blob([...chunks,...directory,end],{type:'application/zip'});
}
$('#download-kit').addEventListener('click',()=>withBusy($('#download-kit'),async()=>{
  await prepareExport();
  const c={...state},svg=logoSVG(c,{embed:true});
  const files={
    'logo-color.svg':svg,
    'logo-black.svg':logoSVG(c,{monochrome:'#111111',embed:true}),
    'logo-white.svg':logoSVG(c,{monochrome:'#ffffff',embed:true}),
    'logo-horizontal.svg':logoSVG(c,{layout:'horizontal',embed:true}),
    'lion-symbol.svg':logoSVG(c,{layout:'icon',embed:true}),
    'logo-2048.png':await raster(svg,2048),
    'favicon-512.png':await raster(logoSVG(c,{layout:'icon'}),512),
    'favicon-32.png':await raster(logoSVG(c,{layout:'icon'}),32),
    'brand-colors.txt':`LIONXSEC LOGO STUDIO\nBrand: ${c.name}\nTagline: ${c.tagline}\nSymbol: ${c.color}\nText: ${c.text}\nStyle: ${c.style}\nFont: ${isRTL(c.name)?'Vazirmatn':c.font}\nAll images have transparent backgrounds.\n`,
    'README.txt':'SVG files are scalable. English lettering is outlined. Persian lettering uses an embedded Vazirmatn font. PNG files have transparent backgrounds. Upload favicon-32.png or favicon-512.png in your website icon settings. White logos are intended for dark backgrounds; black logos for light backgrounds.\n\nفایل‌های SVG برداری هستند. برای عکس از PNG و برای آیکون سایت از favicon استفاده کنید. پس‌زمینهٔ تمام خروجی‌های این بسته شفاف است.\n'
  };
  const completed=await download(await makeZip(files),fileName()+'-brand-kit.zip');showToast(completed?'بستهٔ برند روی کامپیوتر ذخیره شد.':'ذخیرهٔ بسته لغو شد.');
}));

async function startDesktop(){
  $('main').inert=true;$('.site-header').inert=true;
  try{
    const api=await nativeReady;
    const stored=await api.load_state();
    if(!stored?.ok)throw new Error('state_read_failed');
    state=normalize(stored.design);
    saved=Array.isArray(stored.saved)?stored.saved.slice(0,12).map(x=>({id:x.id,state:normalize(x.state)})):[];
    desktopReady=true;render();renderSaved();
    $('#desktop-loading').hidden=true;$('main').inert=false;$('.site-header').inert=false;
  }catch{
    $('#desktop-loading-message').textContent='خواندن طرح‌های ذخیره‌شده انجام نشد. فایل designs.json را بررسی کن؛ اطلاعات قبلی حفظ شده‌اند.';
  }
}
render();renderSaved();startDesktop();
fontReady.then(()=>renderSaved());
