"""Create an isolated environment once; subsequent launches work offline."""
import importlib.metadata
from pathlib import Path
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parent
ENV = ROOT / '.venv'
REQUIRED_VERSION = '6.2.1'


def main():
    if not (3, 10) <= sys.version_info[:2] < (3, 14):
        print('Please install Python 3.10, 3.11, 3.12 or 3.13 (64-bit).')
        print('Official download: https://www.python.org/downloads/windows/')
        return 1
    python = ENV / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')
    if not python.exists():
        print('Preparing the local desktop environment...', flush=True)
        venv.create(ENV, with_pip=True)
    probe = [str(python), '-c',
             "import importlib.metadata,webview;assert importlib.metadata.version('pywebview')=='6.2.1'"]
    if subprocess.run(probe, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
        print('Installing desktop dependencies. Internet is needed for this first setup.', flush=True)
        code = subprocess.call([str(python), '-m', 'pip', 'install', '--disable-pip-version-check',
                                '-r', str(ROOT / 'requirements.txt')])
        if code:
            print('Installation did not finish. Keep this folder and run START-LIONXSEC.cmd again.')
            return code
    print('Desktop setup is ready. Opening LIONXSEC...', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
