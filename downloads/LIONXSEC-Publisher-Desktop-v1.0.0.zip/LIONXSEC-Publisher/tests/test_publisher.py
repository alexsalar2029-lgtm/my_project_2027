import base64
from datetime import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from zoneinfo import ZoneInfo

import imageio_ffmpeg
from PIL import Image
import requests

from app import API
from content import ContentError,analyze,caption,fingerprint,prepare,source_text,utf16len,video_frames
from engine import Engine,next_slot,validate_settings
from storage import Store,SingleInstance,DEFAULTS
from telegram_client import Telegram,TelegramError


class FakeTelegram:
    def __init__(self): self.deliveries=[];self.failure=None
    def verify(self,channel): return {'channel_title':'Example channel','bot':'example_bot','channel_id':'-1001234567890'}
    def send(self,job,text,path,kind):
        if self.failure: raise self.failure
        self.deliveries.append({'channel':job['channel'],'caption':text,'bytes':Path(path).read_bytes(),'kind':kind})
        return {'message_id':100+len(self.deliveries)}


class PublisherTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.folder=self.root/'input';self.folder.mkdir();self.store=Store(self.root/'data')
        self.now=datetime(2030,1,2,8,58,tzinfo=ZoneInfo('Asia/Tehran')).timestamp()
        self.telegram=FakeTelegram();self.engine=Engine(self.store,lambda token:self.telegram,clock=lambda:self.now)
        self.config={**DEFAULTS,'folder':str(self.folder),'channel':'@example_channel','tag':'@example_channel',
                     'website':'https://example.com','ai':False,'auto_watch':False}
        self.engine.save_settings(self.config,'12345678:'+('x'*35))

    def tearDown(self): self.temp.cleanup()
    def source(self,name='lesson.txt',text='عنوان آموزشی\nروش عکاسی در نور طبیعی'):
        path=self.folder/name;path.write_text(text,encoding='utf-8');return path
    def scan(self):
        self.engine._scan()
        with self.store.db() as db: return [dict(row) for row in db.execute('SELECT * FROM jobs ORDER BY id')]
    def due(self):
        self.engine.enable();job=self.store.job(1);self.now=job['scheduled'];return job

    def test_txt_copy_preserves_all_source_and_inserts_links_both_positions(self):
        text='دانشگاه و طراحی\r\n'+('متن درس ' * 7000)
        path=self.source(text=text);original=path.read_bytes();job=self.scan()[0]
        for placement in ['header','footer']:
            prepared,kind=prepare(job,{**self.config,'text_placement':placement},self.store.directory/'prepared')
            output=prepared.read_bytes().decode('utf-8-sig')
            self.assertIn(text,output);self.assertEqual(kind,'document')
            self.assertIn('https://example.com',output)
            self.assertTrue(output.startswith('@example_channel') if placement=='header' else output.startswith(text))
            self.assertEqual(path.read_bytes(),original)
        self.assertNotEqual(path,prepared)

    def test_scan_is_deduplicated_and_unknown_svb_is_not_processed(self):
        self.source();self.source('copy.txt');self.source('unknown.svb','opaque format')
        self.assertEqual(len(self.scan()),1);self.assertEqual(len(self.scan()),1)
        self.assertFalse(self.store.settings()['enabled']);self.assertEqual(self.telegram.deliveries,[])

    def test_schedule_slots_use_tehran_timezone_and_do_not_collide(self):
        first=next_slot(self.config,self.now)
        self.assertEqual(datetime.fromtimestamp(first,ZoneInfo('Asia/Tehran')).strftime('%H:%M'),'09:00')
        second=next_slot(self.config,self.now,[first])
        self.assertEqual(datetime.fromtimestamp(second,ZoneInfo('Asia/Tehran')).strftime('%H:%M'),'14:00')
        end=datetime(2030,1,2,22,tzinfo=ZoneInfo('Asia/Tehran')).timestamp()
        self.assertEqual(datetime.fromtimestamp(next_slot(self.config,end),ZoneInfo('Asia/Tehran')).day,3)

    def test_one_send_at_due_time_with_edited_document_and_persian_date(self):
        self.source();self.scan();self.engine.enable()
        self.assertFalse(self.engine.tick());self.now=self.store.job(1)['scheduled']
        self.assertTrue(self.engine.tick());self.assertFalse(self.engine.tick())
        delivery=self.telegram.deliveries[0]
        self.assertEqual(delivery['kind'],'document');self.assertIn('@example_channel',delivery['bytes'].decode('utf-8-sig'))
        self.assertIn('📅',delivery['caption']);self.assertIn('09:00',delivery['caption']);self.assertIn('https://example.com',delivery['caption'])
        self.assertEqual(self.store.job(1)['status'],'sent');self.assertEqual(len(self.telegram.deliveries),1)

    def test_restart_does_not_resend_unknown_delivery(self):
        self.source();self.scan();self.due()
        with self.store.db() as db: db.execute("UPDATE jobs SET status='sending'")
        self.store.recover();self.assertFalse(self.store.settings()['enabled'])
        self.assertEqual(self.store.job(1)['status'],'uncertain')
        self.engine.enable();self.assertFalse(self.engine.tick())
        self.engine.acknowledge(1,'sent');self.assertEqual(self.store.job(1)['status'],'sent')

    def test_interrupted_analysis_can_be_edited_after_restart(self):
        self.source();self.scan()
        with self.store.db() as db: db.execute("UPDATE jobs SET status='review',error='analyzing'")
        self.store.recover();self.engine.edit(1,'عنوان تازه','متن تازه')
        self.assertEqual(self.store.job(1)['status'],'draft')

    def test_ambiguous_timeout_stops_automatic_retries(self):
        self.source();self.scan();self.due();self.telegram.failure=TelegramError('delivery_unknown',uncertain=True)
        self.engine.tick();self.assertEqual(self.store.job(1)['status'],'uncertain')
        self.now+=100000;self.assertFalse(self.engine.tick());self.assertEqual(self.telegram.deliveries,[])

    def test_rate_limit_uses_next_free_schedule_slot(self):
        self.source();self.scan();self.due();self.telegram.failure=TelegramError('telegram_rate_limit',retry_after=90)
        self.engine.tick();job=self.store.job(1)
        self.assertEqual(job['status'],'scheduled');self.assertGreater(job['scheduled'],self.now+90)
        self.assertEqual(datetime.fromtimestamp(job['scheduled'],ZoneInfo('Asia/Tehran')).strftime('%H:%M'),'14:00')

    def test_changed_file_and_sensitive_file_are_never_sent(self):
        path=self.source();self.scan();self.due();path.write_text('Changed data',encoding='utf-8')
        self.engine.tick();self.assertEqual(self.store.job(1)['status'],'review');self.assertEqual(self.telegram.deliveries,[])
        self.source('private.txt','password: synthetic-example-only')
        jobs=self.scan();self.assertTrue(any(j['status']=='blocked' for j in jobs))

    def test_excluding_during_analysis_is_not_undone_by_result(self):
        self.source()
        def analyzing(path,kind,config):
            self.engine.remove(1)
            return {'status':'draft','title':'Title','body':'Body','error':'','analysis':'text'}
        self.engine.analyzer=analyzing;self.scan();self.assertEqual(self.store.job(1)['status'],'excluded')

    def test_blocked_or_unknown_delivery_cannot_be_reset_by_exclusion(self):
        self.source();self.scan()
        for status in ['blocked','uncertain']:
            with self.store.db() as db: db.execute('UPDATE jobs SET status=? WHERE id=1',(status,))
            self.engine.remove(1)
            self.assertEqual(self.store.job(1)['status'],status)
            with self.assertRaisesRegex(ValueError,'job_locked'):
                self.engine.edit(1,'New title','New body')

    def test_config_changed_during_prepare_does_not_send_old_destination(self):
        self.source();self.scan();self.due()
        original=prepare
        def changed(job,config,out):
            result=original(job,config,out)
            self.engine.save_settings({**self.config,'channel':'@new_example_channel'})
            self.store.update_settings({'enabled':True})
            return result
        with patch('engine.prepare',changed): self.engine.tick()
        self.assertEqual(self.telegram.deliveries,[]);self.assertEqual(self.store.job(1)['status'],'draft')

    def test_config_changed_during_verify_is_rejected(self):
        def verify(channel):
            self.engine.save_settings({**self.config,'channel':'@new_example_channel'})
            return {}
        self.telegram.verify=verify
        with self.assertRaisesRegex(ValueError,'changed_during_verification'): self.engine.enable()
        self.assertFalse(self.store.settings()['enabled'])

    def test_missed_slots_are_moved_forward_without_catchup_burst(self):
        self.source();self.scan();self.due();self.now+=3600
        self.assertFalse(self.engine.tick());self.assertGreater(self.store.job(1)['scheduled'],self.now)

    def test_caption_limit_counts_emoji_and_preserves_footer(self):
        text=caption({'title':'عنوان','body':'🦁'*1000,'kind':'photo'},self.config,self.now)
        self.assertLessEqual(utf16len(text),1024);self.assertTrue(text.endswith('https://example.com'))

    def test_native_snapshot_does_not_expose_token(self):
        snapshot=API(self.store,self.engine).snapshot()
        self.assertTrue(snapshot['settings']['token_set'])
        self.assertNotIn('x'*35,json.dumps(snapshot));self.assertNotIn('bot-token.dat',json.dumps(snapshot))

    def test_second_instance_lock_is_rejected(self):
        one=SingleInstance(self.store.directory)
        try:
            with self.assertRaises(RuntimeError): SingleInstance(self.store.directory)
        finally: one.close()

    def test_image_watermark_changes_only_prepared_image(self):
        path=self.folder/'image.png';Image.new('RGB',(640,400),'#304060').save(path)
        original=path.read_bytes();job=self.scan()[0]
        output,kind=prepare(job,{**self.config,'watermark':True},self.store.directory/'prepared')
        self.assertEqual(kind,'photo');self.assertNotEqual(Image.open(output).getpixel((100,380)),Image.open(path).getpixel((100,380)))
        self.assertEqual(path.read_bytes(),original)

    def test_local_vision_receives_images_and_source_as_data(self):
        path=self.folder/'poster.png';Image.new('RGB',(20,20),'blue').save(path)
        def transport(payload):
            self.assertEqual(len(payload['messages'][1]['images']),1)
            self.assertIn('poster.png',payload['messages'][1]['content'])
            return {'message':{'content':json.dumps({'decision':'ready','title':'Poster','body':'Blue study poster'})}}
        result=analyze(path,'photo',{**self.config,'ai':True},transport)
        self.assertEqual(result['status'],'draft');self.assertEqual(result['analysis'],'ollama')


class TelegramTests(unittest.TestCase):
    def test_uncertain_network_error_is_sanitized(self):
        class Session:
            def post(self,*args,**kwargs): raise requests.ReadTimeout('secret url must not escape')
        client=Telegram('test-secret',Session())
        with self.assertRaises(TelegramError) as caught: client.call('sendMessage',{'text':'hello'})
        self.assertTrue(caught.exception.uncertain);self.assertNotIn('secret',str(caught.exception))

    def test_getme_and_channel_permissions_are_required(self):
        replies=[{'id':7,'username':'test_bot'},{'id':-10011111,'type':'channel','title':'Test'},
                 {'status':'administrator','can_post_messages':False}]
        client=Telegram('fake')
        client.call=lambda *args,**kwargs:replies.pop(0)
        with self.assertRaisesRegex(TelegramError,'bot_permission'): client.verify('@example_channel')

    def test_media_uses_streaming_multipart_and_keeps_caption(self):
        class Response:
            status_code=200
            def json(self): return {'ok':True,'result':{'message_id':4}}
        class Session:
            def post(self,url,**kwargs):
                self.body=kwargs['data'].to_string();return Response()
        session=Session();client=Telegram('fake',session)
        with tempfile.TemporaryDirectory() as temp:
            file=Path(temp)/'lesson.txt';file.write_text('Example lesson')
            result=client.send({'channel':'@example_channel'},'Title\nDate',file,'document')
        self.assertEqual(result['message_id'],4);self.assertIn(b'Example lesson',session.body);self.assertIn(b'Title',session.body)


if __name__=='__main__': unittest.main()
