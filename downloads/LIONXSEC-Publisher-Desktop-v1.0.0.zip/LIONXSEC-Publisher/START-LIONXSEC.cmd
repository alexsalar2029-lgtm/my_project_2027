@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title LIONXSEC Publisher
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" setup_desktop.py
  goto installed
)
for %%V in (3.13 3.12 3.11 3.10) do (
  py -%%V -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    py -%%V setup_desktop.py
    goto installed
  )
)
python setup_desktop.py
:installed
if errorlevel 1 goto failed
".venv\Scripts\python.exe" app.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo Setup or startup failed. Read the message above and README_FA.md.
pause
exit /b 1
