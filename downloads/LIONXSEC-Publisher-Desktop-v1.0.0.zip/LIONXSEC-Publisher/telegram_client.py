"""Telegram Bot API with streamed media and conservative delivery recovery."""
import mimetypes
from pathlib import Path

import requests
from requests_toolbelt import MultipartEncoder


class TelegramError(Exception):
    def __init__(self,code,retry_after=0,uncertain=False):
        self.code=code;self.retry_after=retry_after;self.uncertain=uncertain
        super().__init__(code)


class Telegram:
    def __init__(self,token,session=None): self.token=token;self.session=session or requests.Session()

    def call(self,method,data=None,path=None,field=None):
        url='https://api.telegram.org/bot'+self.token+'/'+method
        source=None
        try:
            if path:
                source=Path(path).open('rb')
                fields={key:str(value) for key,value in (data or {}).items()}
                fields[field]=(Path(path).name,source,mimetypes.guess_type(str(path))[0] or 'application/octet-stream')
                encoder=MultipartEncoder(fields)
                response=self.session.post(url,data=encoder,headers={'Content-Type':encoder.content_type},timeout=(10,180))
            else: response=self.session.post(url,json=data or {},timeout=(10,45))
            try: result=response.json()
            except ValueError: raise TelegramError('delivery_unknown' if method.startswith('send') else 'telegram_response',uncertain=method.startswith('send')) from None
            if response.status_code==429 or result.get('error_code')==429:
                wait=max(1,int(result.get('parameters',{}).get('retry_after',60)))
                raise TelegramError('telegram_rate_limit',retry_after=wait)
            if not result.get('ok'):
                code=result.get('error_code',response.status_code)
                label={401:'bot_token_invalid',403:'bot_permission',400:'telegram_request'}.get(code,'telegram_unavailable')
                raise TelegramError(label,uncertain=code>=500 and method.startswith('send'))
            return result['result']
        except requests.ConnectTimeout: raise TelegramError('connection_failed') from None
        except (requests.Timeout,requests.ConnectionError):
            raise TelegramError('delivery_unknown' if method.startswith('send') else 'connection_failed',uncertain=method.startswith('send')) from None
        except requests.RequestException: raise TelegramError('telegram_unavailable') from None
        finally:
            if source: source.close()

    def verify(self,channel):
        me=self.call('getMe');chat=self.call('getChat',{'chat_id':channel})
        if chat.get('type')!='channel': raise TelegramError('not_channel')
        member=self.call('getChatMember',{'chat_id':channel,'user_id':me['id']})
        if member.get('status')!='creator' and (member.get('status')!='administrator' or not member.get('can_post_messages')):
            raise TelegramError('bot_permission')
        return {'bot':me.get('username',''),'channel_title':chat.get('title',''),'channel_id':str(chat['id'])}

    def send(self,job,caption,path,kind):
        fields={'chat_id':job['channel']}
        if kind=='text':
            fields.update(text=caption,link_preview_options={'is_disabled':True})
            return self.call('sendMessage',fields)
        method,field={'photo':('sendPhoto','photo'),'video':('sendVideo','video'),'document':('sendDocument','document')}[kind]
        fields['caption']=caption
        if kind=='video': fields['supports_streaming']='true'
        return self.call(method,fields,path,field)
