"""Background intake and one-at-a-time, restart-safe scheduled publication."""
from datetime import datetime,timedelta
import json
from pathlib import Path
import re
import threading
import time
from urllib.parse import urlparse
from zoneinfo import ZoneInfo,ZoneInfoNotFoundError

from content import KINDS,MAX_BYTES,ContentError,analyze,caption,fingerprint,prepare,protected_content,thumbnail
from storage import DEFAULTS,atomic_write
from telegram_client import Telegram,TelegramError


def validate_settings(data):
    if not isinstance(data,dict): raise ValueError('invalid_settings')
    value={**DEFAULTS,**{k:v for k,v in data.items() if k in DEFAULTS and k!='enabled'}}
    for key in ['folder','channel','tag','website','timezone','model']:
        if not isinstance(value[key],str): raise ValueError('invalid_settings')
        value[key]=value[key].strip()
    if value['folder'] and not Path(value['folder']).is_dir(): raise ValueError('folder_missing')
    if value['channel'] and not re.fullmatch(r'@[A-Za-z0-9_]{5,32}|-100\d{5,}',value['channel']): raise ValueError('channel_invalid')
    if value['tag'] and not re.fullmatch(r'@[A-Za-z0-9_]{5,32}|https://t\.me/[A-Za-z0-9_+/-]{1,150}',value['tag']): raise ValueError('tag_invalid')
    if value['website']:
        u=urlparse(value['website'])
        if u.scheme not in ('https','http') or not u.hostname or u.username or len(value['website'])>240: raise ValueError('website_invalid')
    if not re.fullmatch(r'[A-Za-z0-9._:/-]{1,100}',value['model']): raise ValueError('model_invalid')
    try: ZoneInfo(value['timezone'])
    except (ZoneInfoNotFoundError,ValueError): raise ValueError('timezone_invalid') from None
    times=value['times']
    if not isinstance(times,list) or not 1<=len(times)<=24 or any(not isinstance(t,str) or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',t) for t in times): raise ValueError('times_invalid')
    value['times']=sorted(set(times))
    for key in ['ai','watermark','recursive','auto_watch']:
        if type(value[key]) is not bool: raise ValueError('invalid_settings')
    if value['text_placement'] not in ('header','footer'): raise ValueError('invalid_settings')
    value['enabled']=False
    return value


def next_slot(settings,after,occupied=()):
    zone=ZoneInfo(settings['timezone']);start=datetime.fromtimestamp(after,zone)
    taken={int(x) for x in occupied}
    for day in range(3670):
        date=start.date()+timedelta(days=day)
        for text in settings['times']:
            hour,minute=map(int,text.split(':'))
            local=datetime(date.year,date.month,date.day,hour,minute,tzinfo=zone)
            timestamp=local.timestamp()
            # Reject nonexistent local times around a DST jump.
            if datetime.fromtimestamp(timestamp,zone).replace(tzinfo=None)!=local.replace(tzinfo=None): continue
            if timestamp>after and int(timestamp) not in taken: return timestamp
    raise ValueError('no_schedule_slot')


class Engine:
    def __init__(self,store,telegram_factory=Telegram,analyzer=analyze,clock=time.time):
        self.store=store;self.telegram_factory=telegram_factory;self.analyzer=analyzer;self.clock=clock
        self.stop_event=threading.Event();self.lock=threading.RLock();self.scan_lock=threading.Lock()
        self.runtime={'scanning':False,'scanned':0,'total':0,'current':'','sending':False}
        self.last_scan=0;self.thread=None;self.revision=0

    def start_worker(self):
        self.thread=threading.Thread(target=self._loop,name='publisher',daemon=True);self.thread.start()

    def close(self):
        self.stop_event.set();self.store.update_settings({'enabled':False})

    def _loop(self):
        while not self.stop_event.is_set():
            try:
                config=self.store.settings()
                if config['enabled']:
                    self.tick()
                    if config['auto_watch'] and self.clock()-self.last_scan>60 and not self.runtime['scanning']:
                        self.scan_async()
            except Exception:
                self.store.update_settings({'enabled':False});self.store.event('پردازش متوقف شد؛ تنظیمات و صف را بررسی کنید.','error')
            self.stop_event.wait(3)

    def save_settings(self,data,token=''):
        settings=validate_settings(data)
        if settings['folder'] and Path(settings['folder']).resolve().is_relative_to(self.store.directory.resolve()): raise ValueError('folder_in_app_data')
        if token and not re.fullmatch(r'\d{5,20}:[A-Za-z0-9_-]{20,200}',token): raise ValueError('bot_token_invalid')
        with self.lock:
            self.revision+=1
            self.store.update_settings(settings)
            if token: self.store.set_token(token)
            with self.store.db() as db:
                db.execute("UPDATE jobs SET status='draft',scheduled=NULL,channel='',error='' WHERE status='scheduled'")
        self.store.event('تنظیمات ذخیره شد. برای انتشار، زمان‌بندی را فعال کنید.')
        return settings

    def verify(self):
        config=self.store.settings()
        if not config['channel']: raise ValueError('channel_missing')
        token=self.store.token()
        if not token: raise ValueError('bot_token_missing')
        return self.telegram_factory(token).verify(config['channel'])

    def _assign(self,db,config,now):
        occupied=[r[0] for r in db.execute("SELECT scheduled FROM jobs WHERE status='scheduled'")]
        rows=db.execute("SELECT id FROM jobs WHERE status='draft' AND error='' AND title<>'' ORDER BY id").fetchall()
        for row in rows:
            slot=next_slot(config,now,occupied);occupied.append(slot)
            db.execute("UPDATE jobs SET status='scheduled',scheduled=?,channel=?,updated=? WHERE id=?",(slot,config['channel'],now,row[0]))
        return len(rows)

    def enable(self):
        with self.lock:
            revision=self.revision;config=self.store.settings();token=self.store.token()
        if not config['channel']: raise ValueError('channel_missing')
        if not token: raise ValueError('bot_token_missing')
        self.telegram_factory(token).verify(config['channel'])
        with self.lock:
            if revision!=self.revision: raise ValueError('changed_during_verification')
            config=self.store.settings()
            if not config['folder']: raise ValueError('folder_missing')
            now=self.clock()
            with self.store.db() as db:
                db.execute('BEGIN IMMEDIATE')
                db.execute("UPDATE jobs SET status='draft',scheduled=NULL,error='' WHERE status='scheduled'")
                count=self._assign(db,config,now)
            self.store.update_settings({'enabled':True})
        self.store.event('زمان‌بندی فعال شد؛ '+str(count)+' پست در صف است.')
        return count

    def pause(self):
        with self.lock:
            self.revision+=1;self.store.update_settings({'enabled':False})
        self.store.event('انتشارهای بعدی متوقف شدند. ارسال جاری، در صورت شروع، ممکن است کامل شود.')

    def scan_async(self,only_id=None):
        config=self.store.settings()
        if not config['folder'] or not Path(config['folder']).is_dir(): raise ValueError('folder_missing')
        if only_id is not None:
            prior=self.store.job(only_id)
            if not prior or prior['status'] in ('sent','sending','preparing','blocked','uncertain'): raise ValueError('job_locked')
        if not self.scan_lock.acquire(blocking=False): raise ValueError('scan_busy')
        self.runtime.update(scanning=True,scanned=0,total=0,current='')
        def work():
            try: self._scan(only_id)
            except Exception: self.store.event('خواندن پوشه کامل نشد؛ مسیر و دسترسی فایل‌ها را بررسی کنید.','error')
            finally:
                self.runtime.update(scanning=False,current='');self.last_scan=self.clock();self.scan_lock.release()
        threading.Thread(target=work,name='intake',daemon=True).start()

    def _scan(self,only_id=None):
        config=self.store.settings();folder=Path(config['folder'])
        if not config['folder'] or not folder.is_dir(): raise ValueError('folder_missing')
        if only_id is not None:
            prior=self.store.job(only_id)
            if not prior or prior['status'] in ('sent','sending','preparing','blocked','uncertain'): raise ValueError('job_locked')
            paths=[Path(prior['path'])]
        else:
            source=folder.rglob('*') if config['recursive'] else folder.iterdir()
            paths=sorted((p for p in source if p.is_file() and not p.is_symlink() and p.suffix.lower() in KINDS and not p.name.endswith('.caption.txt') and not p.resolve().is_relative_to(self.store.directory.resolve()) and not any(part in ('.venv','.git') for part in p.parts)),key=lambda p:p.name.lower())
        self.runtime['total']=len(paths);added=0
        for index,path in enumerate(paths):
            identifier=None
            if self.stop_event.is_set(): break
            self.runtime.update(scanned=index,current=path.name)
            kind=KINDS.get(path.suffix.lower())
            if not kind: continue
            try:
                size=path.stat().st_size
                if not size or size>MAX_BYTES: continue
                digest=fingerprint(path);now=self.clock()
                with self.store.db() as db:
                    existing=db.execute('SELECT id FROM jobs WHERE digest=?',(digest,)).fetchone()
                    if existing and only_id is None: continue
                    if only_id is not None:
                        identifier=only_id
                        changed=db.execute("UPDATE jobs SET status='review',error='analyzing',digest=?,updated=? WHERE id=? AND status NOT IN ('sent','sending','preparing','blocked','uncertain')",(digest,now,identifier))
                        if not changed.rowcount: continue
                    else:
                        cursor=db.execute("INSERT OR IGNORE INTO jobs(path,digest,filename,kind,size,status,error,created,updated) VALUES(?,?,?,?,?,'review','analyzing',?,?)",(str(path.resolve()),digest,path.name,kind,size,now,now))
                        if not cursor.rowcount: continue
                        identifier=cursor.lastrowid;added+=1
                thumb=thumbnail(path,kind)
                if thumb: atomic_write(self.store.directory/'thumbs'/f'{identifier}.jpg',thumb)
                try: result=self.analyzer(path,kind,config)
                except ContentError as error:
                    result={'status':'review','title':path.stem[:100],'body':'','error':error.code,'analysis':''}
                if fingerprint(path)!=digest: raise ContentError('file_changed')
                with self.store.db() as db:
                    db.execute("UPDATE jobs SET status=?,title=?,body=?,error=?,analysis=?,updated=? WHERE id=? AND status='review' AND error='analyzing'",
                               (result['status'],result['title'],result['body'],result['error'],result['analysis'],self.clock(),identifier))
            except Exception:
                if identifier is not None:
                    with self.store.db() as db: db.execute("UPDATE jobs SET status='review',error='file_changed' WHERE id=? AND status='review' AND error='analyzing'",(identifier,))
            with self.lock:
                current=self.store.settings()
                if current['enabled']:
                    with self.store.db() as db:
                        db.execute('BEGIN IMMEDIATE');self._assign(db,current,self.clock())
        self.runtime['scanned']=len(paths)
        if added: self.store.event(str(added)+' فایل جدید بررسی شد؛ فایل‌های اصلی حفظ شدند.')

    def edit(self,identifier,title,body):
        if not isinstance(title,str) or not title.strip() or len(title)>100 or not isinstance(body,str) or len(body)>500: raise ValueError('caption_invalid')
        if protected_content(title+'\n'+body): raise ValueError('sensitive_content')
        with self.lock,self.store.db() as db:
            row=db.execute('SELECT * FROM jobs WHERE id=?',(int(identifier),)).fetchone()
            if not row or row['status'] in ('sent','sending','preparing','blocked','uncertain') or row['error']=='analyzing': raise ValueError('job_locked')
            db.execute("UPDATE jobs SET title=?,body=?,status='draft',error='',scheduled=NULL,updated=? WHERE id=?",(title.strip(),body.strip(),self.clock(),int(identifier)))

    def remove(self,identifier):
        with self.lock,self.store.db() as db:
            db.execute("UPDATE jobs SET status='excluded',scheduled=NULL WHERE id=? AND status NOT IN ('sending','preparing','sent','blocked','uncertain')",(int(identifier),))

    def acknowledge(self,identifier,action):
        if action not in ('sent','retry'): raise ValueError('invalid_action')
        with self.lock,self.store.db() as db:
            row=db.execute('SELECT * FROM jobs WHERE id=?',(int(identifier),)).fetchone()
            if not row or row['status']!='uncertain': raise ValueError('job_locked')
            if action=='sent': db.execute("UPDATE jobs SET status='sent',sent=?,error='' WHERE id=?",(self.clock(),int(identifier)))
            else: db.execute("UPDATE jobs SET status='draft',error='',scheduled=NULL WHERE id=?",(int(identifier),))

    def tick(self):
        now=self.clock()
        with self.lock,self.store.db() as db:
            config=self.store.settings()
            revision=self.revision
            if not config['enabled']: return False
            db.execute('BEGIN IMMEDIATE')
            db.execute("UPDATE jobs SET status='draft',scheduled=NULL,error='' WHERE status='scheduled' AND scheduled<?",(now-300,))
            self._assign(db,config,now)
            row=db.execute("SELECT * FROM jobs WHERE status='scheduled' AND scheduled<=? ORDER BY scheduled,id LIMIT 1",(now,)).fetchone()
            if not row: return False
            job=dict(row);db.execute("UPDATE jobs SET status='preparing',updated=? WHERE id=?",(now,job['id']))
        self.runtime['sending']=True
        try:
            path,kind=prepare(job,config,self.store.directory/'prepared')
            with self.lock:
                if not self.store.settings()['enabled'] or self.stop_event.is_set() or revision!=self.revision:
                    with self.store.db() as db: db.execute("UPDATE jobs SET status='draft',scheduled=NULL WHERE id=?",(job['id'],))
                    return True
                text=caption(job,config,self.clock())
                atomic_write(self.store.directory/'prepared'/f"{job['id']}-caption.txt",text.encode('utf-8-sig'))
                with self.store.db() as db: db.execute("UPDATE jobs SET status='sending',updated=? WHERE id=?",(self.clock(),job['id']))
            result=self.telegram_factory(self.store.token()).send(job,text,path,kind)
            with self.store.db() as db:
                db.execute("UPDATE jobs SET status='sent',sent=?,message_id=?,error='',updated=? WHERE id=?",(self.clock(),result.get('message_id'),self.clock(),job['id']))
            self.store.event('پست شمارهٔ '+str(job['id'])+' با موفقیت منتشر شد.')
        except ContentError as error:
            with self.store.db() as db: db.execute("UPDATE jobs SET status=?,error=?,updated=? WHERE id=?",('blocked' if error.code=='sensitive_content' else 'review',error.code,self.clock(),job['id']))
        except TelegramError as error:
            attempts=job['attempts']+1
            if error.uncertain: status='uncertain'
            elif (error.retry_after or error.code=='connection_failed') and attempts<4: status='scheduled'
            else: status='failed'
            with self.store.db() as db:
                occupied=[r[0] for r in db.execute("SELECT scheduled FROM jobs WHERE status='scheduled'")]
                slot=next_slot(config,self.clock()+error.retry_after,occupied) if status=='scheduled' else None
                db.execute('UPDATE jobs SET status=?,error=?,attempts=?,scheduled=?,updated=? WHERE id=?',(status,error.code,attempts,slot,self.clock(),job['id']))
            self.store.event('ارسال پست شمارهٔ '+str(job['id'])+' نیاز به بررسی دارد.','warning')
        except Exception:
            with self.store.db() as db:
                current=db.execute('SELECT status FROM jobs WHERE id=?',(job['id'],)).fetchone()[0]
                db.execute('UPDATE jobs SET status=?,error=? WHERE id=?',('uncertain' if current=='sending' else 'failed','delivery_unknown' if current=='sending' else 'prepare_failed',job['id']))
        finally: self.runtime['sending']=False
        return True
