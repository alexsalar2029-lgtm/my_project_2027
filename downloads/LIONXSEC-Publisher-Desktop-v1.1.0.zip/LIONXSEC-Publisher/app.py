"""LIONXSEC Publisher native desktop entry point."""
import base64
from datetime import datetime
import os
from pathlib import Path
import subprocess
import sys
import time

from content import caption,prepare,ContentError
from desktop_runtime import initialize_desktop
from engine import Engine
from storage import Store,SingleInstance
from telegram_client import TelegramError

ROOT=Path(__file__).resolve().parent


class API:
    def __init__(self,store,engine): self._store=store;self._engine=engine;self._window=None

    def _call(self,function,*args):
        try: return {'ok':True,'value':function(*args)}
        except (ValueError,ContentError,TelegramError) as error: return {'ok':False,'error':getattr(error,'code',str(error))}
        except Exception: return {'ok':False,'error':'operation_failed'}

    def snapshot(self):
        settings=self._store.settings()
        settings['token_set']=self._store.token_path.exists()
        with self._store.db() as db:
            jobs=[dict(row) for row in db.execute('SELECT * FROM jobs ORDER BY id DESC LIMIT 500')]
            counts=dict(db.execute('SELECT status,count(*) FROM jobs GROUP BY status').fetchall())
            events=[dict(row) for row in db.execute('SELECT * FROM events ORDER BY id DESC LIMIT 20')]
        return {'settings':settings,'jobs':jobs,'counts':counts,'events':events,'runtime':dict(self._engine.runtime),'now':time.time()}

    def save_settings(self,data,token=''): return self._call(self._engine.save_settings,data,token)
    def verify(self): return self._call(self._engine.verify)
    def scan(self): return self._call(self._engine.scan_async)
    def enable(self): return self._call(self._engine.enable)
    def pause(self): return self._call(self._engine.pause)
    def edit(self,identifier,title,body): return self._call(self._engine.edit,identifier,title,body)
    def remove(self,identifier): return self._call(self._engine.remove,identifier)
    def reanalyze(self,identifier): return self._call(self._engine.scan_async,int(identifier))
    def acknowledge(self,identifier,action): return self._call(self._engine.acknowledge,identifier,action)

    def choose_folder(self):
        import webview
        choice=self._window.create_file_dialog(webview.FileDialog.FOLDER)
        return choice[0] if choice else ''

    def thumbnail(self,identifier):
        path=self._store.directory/'thumbs'/f'{int(identifier)}.jpg'
        return 'data:image/jpeg;base64,'+base64.b64encode(path.read_bytes()).decode() if path.exists() else ''

    def detail(self,identifier):
        job=self._store.job(identifier)
        if not job: return {'ok':False,'error':'job_missing'}
        return {'ok':True,'job':job,'caption':caption(job,self._store.settings(),job['scheduled'] or time.time())}

    def preview_caption(self,identifier,title,body):
        def build():
            job=self._store.job(identifier)
            if not job: raise ValueError('job_missing')
            if not isinstance(title,str) or not isinstance(body,str) or len(title)>100 or len(body)>500:
                raise ValueError('caption_invalid')
            return caption({**job,'title':title,'body':body},self._store.settings(),job['scheduled'] or time.time())
        return self._call(build)

    def prepare_copy(self,identifier):
        def build():
            job=self._store.job(identifier)
            if not job or job['status'] in ('blocked','sending','preparing'): raise ValueError('job_locked')
            path,kind=prepare(job,self._store.settings(),self._store.directory/'prepared')
            return {'filename':path.name,'kind':kind}
        return self._call(build)

    def open_outputs(self):
        folder=str(self._store.directory/'prepared')
        if sys.platform=='win32': os.startfile(folder)
        elif sys.platform=='darwin': subprocess.Popen(['open',folder])
        else: subprocess.Popen(['xdg-open',folder],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return {'ok':True}

    def test_ai(self,model):
        def test():
            import requests
            try:
                result=requests.get('http://127.0.0.1:11434/api/tags',timeout=8);result.raise_for_status()
                models=[entry['name'] for entry in result.json().get('models',[])]
            except Exception: raise ValueError('ollama_unavailable') from None
            if model not in models and model+':latest' not in models: raise ValueError('model_missing')
            return {'model':model}
        return self._call(test)


def main():
    try: import webview
    except ImportError:
        print('Run START-LIONXSEC.cmd to install dependencies.');return 1
    try: initialize_desktop()
    except Exception:
        print('The Qt desktop renderer is missing or could not start. Run START-LIONXSEC.cmd with Internet access.')
        print('If you see a graphics driver error, use START-LIONXSEC-SOFTWARE.cmd. Windows 10/11 (64-bit) is required.')
        return 1
    store=Store()
    try: instance=SingleInstance(store.directory)
    except RuntimeError:
        print('LIONXSEC Publisher is already running. Open its existing window.');return 1
    store.recover();engine=Engine(store);api=API(store,engine)
    webview.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER']=False
    api._window=webview.create_window('LIONXSEC | Publisher Studio',str(ROOT/'ui/index.html'),
                                     js_api=api,width=1440,height=940,min_size=(900,650),
                                     background_color='#0b0c0f',text_select=True)
    api._window.events.closed+=engine.close
    engine.start_worker()
    try:
        webview.start(gui='qt',http_server=True,
                      private_mode=False,storage_path=str(store.directory/'webview'))
    except Exception:
        print('Desktop window could not start. Run START-LIONXSEC-SOFTWARE.cmd or reinstall through START-LIONXSEC.cmd.');return 1
    finally: engine.close();instance.close()
    return 0


if __name__=='__main__': raise SystemExit(main())
