from pathlib import Path
import hashlib
import subprocess
import sys
import venv

ROOT=Path(__file__).resolve().parent


def main():
    if not (3,10)<=sys.version_info[:2]<(3,14):
        print('Install Python 3.10 to 3.13 (64-bit), then run START-LIONXSEC.cmd.');return 1
    if sys.maxsize<=2**32:
        print('Install the 64-bit version of Python.');return 1
    if sys.platform=='win32' and sys.getwindowsversion().major<10:
        print('This desktop version requires Windows 10 or Windows 11 (64-bit).');return 1
    environment=ROOT/'.venv';python=environment/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')
    if not python.exists():
        print('Creating the local environment...',flush=True);venv.create(environment,with_pip=True)
    digest=hashlib.sha256((ROOT/'requirements.txt').read_bytes()).hexdigest();marker=environment/'.requirements-sha256'
    installed=marker.exists() and marker.read_text()==digest
    if installed:
        installed=subprocess.run([str(python),'-c','import webview,requests,requests_toolbelt,PIL,imageio_ffmpeg,jdatetime,pypdf,qtpy; from PySide6 import QtWebEngineWidgets'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
    if not installed:
        print('Installing dependencies. Keep your Internet connection on for this first setup.',flush=True)
        code=subprocess.call([str(python),'-m','pip','install','--disable-pip-version-check','-r',str(ROOT/'requirements.txt')])
        if code: return code
        marker.write_text(digest)
    print('Opening LIONXSEC Publisher...',flush=True);return 0


if __name__=='__main__': raise SystemExit(main())
