"""Select a modern, packaged renderer without falling back to MSHTML."""
import os


def initialize_desktop(initialize=None):
    os.environ['QT_API']='pyside6'
    if initialize is None:
        # Import explicitly before pywebview can silently fall back to WinForms/IE.
        from PySide6 import QtWebEngineWidgets  # noqa: F401
        import qtpy
        if qtpy.API_NAME!='PySide6': raise RuntimeError('desktop_renderer_unavailable')
        from webview.guilib import initialize
    backend=initialize('qt')
    if getattr(backend,'renderer',None)!='qtwebengine':
        raise RuntimeError('desktop_renderer_unavailable')
    return backend
