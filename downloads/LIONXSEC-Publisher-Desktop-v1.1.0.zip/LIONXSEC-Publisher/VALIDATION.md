# Validation — LIONXSEC Publisher Studio 1.1.0

The release was checked in a Linux development environment. It contains a Windows launcher and Windows-specific implementations, but **Windows startup, DPAPI on Windows and delivery to a live Telegram channel have not been exercised here**. Version 1.1 selects PySide6/Qt WebEngine and rejects legacy renderer fallback; WebView2 is no longer required. No real bot token, channel, user files or local database is included.

## Automated coverage

Run from the project directory after installing `requirements.txt`:

```sh
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/media_smoke.py
```

The 28 unit/integration tests cover full TXT preservation and link insertion, source preservation, deduplication, unknown SVB exclusion, Tehran scheduling, one fake delivery at the scheduled slot, recovery after interrupted work, explicit handling of ambiguous delivery, rate-limit rescheduling, file changes, sensitive-text blocking, blocked-job state protections, concurrent settings changes, exclusion while analysis is running, missed slots, Telegram caption limits, token omission from UI snapshots, single-instance locking, image watermarking, multimodal AI input structure and streamed Telegram multipart uploads. New coverage includes one-pass custom templates, publication year, long-template caption limits, rejection of expressions/unknown placeholders, unsaved preview without mutation, email-collection blocking and legacy-renderer rejection.

The media smoke test uses FFmpeg to create an ordinary synthetic clip, extract three frames and generate a branded MP4 without changing the source. FFmpeg is provided by `imageio-ffmpeg`. It passed for version 1.0; that media preparation code is unchanged in version 1.1 and the full media smoke was not repeated for this caption/renderer change.

## Native and visual checks

PySide6 6.10.3 and QtPy 2.4.3 are now runtime dependencies installed by the Windows launcher. Playwright with system Chromium is an optional, separately installed visual-test dependency.

```sh
QT_QPA_PLATFORM=offscreen QTWEBENGINE_CHROMIUM_FLAGS='--no-sandbox --disable-gpu' python tests/native_smoke.py
python tests/browser_smoke.py
node --check ui/app.js
```

The native check runs the production renderer selector, opens a real pywebview/PySide6 window and uses its JavaScript-to-Python bridge to scan a folder, edit a draft, prepare a TXT copy, enable a schedule, make a simulated Telegram delivery and pause. It also checks Persian time input, unsupported SVB behavior and custom-template persistence. Headless Qt may emit GPU/D-Bus warnings in this environment. `--no-sandbox` is used only for this headless test invocation, not by the shipped launchers.

The visual check uses Chromium with the real local Python API and safe synthetic fixtures. It checks library, settings, live unsaved caption preview, custom-template editing, search, scheduling and pause; widths 900, 1100 and 1440 have no horizontal document overflow. It asserts compact header button dimensions and absence of JavaScript errors. Screenshots are generated in `tests/artifacts/`, which is excluded from the download ZIP.

Telegram requests and Ollama responses are simulated in automated tests. Media encoding and filesystem/SQLite operations are real. This testing does not establish live Telegram connectivity, semantic accuracy of an installed Ollama model, Windows hardware compatibility or performance on large libraries/videos. First deployment should use a few ordinary sample files and an owned test channel.

## Package hygiene

The distributable excludes virtual environments, runtime databases, tokens, sessions, generated screenshots and cache directories. Fonts include their OFL notices. The ZIP is accompanied by a SHA-256 checksum, and the downloaded GitHub artifact is checked against the local archive before delivery.
