# 1.1.0

- Select PySide6/Qt WebEngine explicitly. Refuse legacy MSHTML fallback, which could display a white, broken layout and fail to execute the interface JavaScript.
- Install the Qt runtime through the launcher; add an optional software-rendering launcher for GPU driver issues. Require 64-bit Windows 10/11.
- Add editable caption templates with title, body, filename, publication year and brand placeholders, plus live preview while editing a post.
- Preserve the automatic date/channel/site footer and Telegram caption length limit. Keep template variables inert and validate them before saving.
- Clarify that Telegram app API credentials are different from a BotFather bot token. Personal-account login is not included.
- Hold personal email collections for protection instead of converting them into promotional captions.
- Preserve existing AppData settings and queue data. Startup still pauses publishing.
