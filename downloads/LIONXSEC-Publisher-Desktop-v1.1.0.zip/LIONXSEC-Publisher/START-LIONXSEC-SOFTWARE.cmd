@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu"
call START-LIONXSEC.cmd
