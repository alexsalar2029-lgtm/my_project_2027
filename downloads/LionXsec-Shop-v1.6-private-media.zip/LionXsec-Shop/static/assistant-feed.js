import {api,esc,name,lang} from './shared.js';
let posts=[];
for(const [kind,parent] of [['sale','catalog'],['tutorial','tutorials']]){
 const section=document.createElement('section');section.id='assistant-'+kind;section.className='assistant-section';section.hidden=true;
 document.getElementById(parent)?.append(section);
}
const text=()=>({fa:{sale:'پیشنهادهای کانال',tutorial:'آموزش‌های کانال',article:'مطالب و تازه‌ها',source:'مشاهده پست اصلی',buy:'سفارش در تلگرام',price:'استعلام قیمت',details:'جزئیات بیشتر'},en:{sale:'Channel offers',tutorial:'Channel tutorials',article:'News & articles',source:'Original post',buy:'Order on Telegram',price:'Ask for price',details:'Read more'},ar:{sale:'عروض القناة',tutorial:'دروس القناة',article:'المقالات والأخبار',source:'المنشور الأصلي',buy:'اطلب عبر تيليجرام',price:'استفسر عن السعر',details:'التفاصيل'},es:{sale:'Ofertas del canal',tutorial:'Tutoriales del canal',article:'Noticias y artículos',source:'Publicación original',buy:'Pedir por Telegram',price:'Consultar precio',details:'Leer más'}}[lang]);
export async function loadAssistantPosts(){posts=(await api('/api/assistant/posts')).posts;renderAssistantPosts();}
export function renderAssistantPosts(){
 const l=text();
 for(const kind of ['sale','tutorial','article']){
  const section=document.getElementById('assistant-'+kind);if(!section)continue;
  const items=posts.filter(p=>p.kind===kind);section.hidden=!items.length;
  section.innerHTML=`<h2>${esc(l[kind])}</h2><div class="assistant-grid">${items.map(p=>`<article class="assistant-card"><h3>${esc(name(p.title))}</h3><p>${esc(name(p.summary))}</p><details><summary>${esc(l.details)}</summary><p class="assistant-body">${esc(name(p.body))}</p></details>${kind==='sale'?`<strong dir="ltr">${p.price?esc(p.price.amount+' '+p.price.currency):esc(l.price)}</strong>`:''}<a class="button secondary" href="${esc(p.source_url||'https://t.me/link_Lion')}" target="_blank" rel="noopener noreferrer">${esc(kind==='sale'?l.buy:l.source)} ↗</a></article>`).join('')}</div>`;
 }
}
