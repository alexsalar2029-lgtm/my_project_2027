"""Offline integration: real browser/server/database, simulated AI/Telegram responses."""
from pathlib import Path
import secrets
import tempfile
import threading

from playwright.sync_api import sync_playwright, expect
from assistant import Runner
from automation import ingest, process_one
from server import App, Store


def run():
    with tempfile.TemporaryDirectory() as folder:
        store=Store(Path(folder)/'shop.sqlite3')
        password=secrets.token_urlsafe(24)
        store.init_admin(password)
        for index,kind in enumerate(('sale','tutorial','article'),1):
            ingest(store,[{'update_id':index,'channel_post':{'message_id':index,
                'chat':{'type':'channel','id':-1001234567890,'username':'my_channel'},
                'text':'Sample subscription 12.50 USDT'}}],'@my_channel','local-test')
            class Model:
                def analyze(self,text,media=None):
                    local=lambda value:dict.fromkeys(('fa','en','ar','es'),value)
                    return {'kind':kind,'title':local('نمونه '+kind),'summary':local('توضیحات آزمایشی'),
                            'body':local('<img src=x onerror=alert(1)> متن توضیحات'),
                            'price':{'amount':'12.50','currency':'USDT'}}
            process_one(store,Model())
        app=App(('127.0.0.1',0),store)
        thread=threading.Thread(target=app.serve_forever,daemon=True);thread.start()
        runner=Runner(store);runner.start()
        origin=f'http://127.0.0.1:{app.server_port}'
        try:
            with sync_playwright() as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
                page=browser.new_page(viewport={'width':1440,'height':1000})
                errors=[];external=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.on('request',lambda r:external.append(r.url) if not r.url.startswith(origin) else None)
                page.goto(origin)
                for kind in ('sale','tutorial','article'):
                    expect(page.locator('#assistant-'+kind+' .assistant-card')).to_have_count(1)
                expect(page.locator('#catalog #assistant-sale')).to_be_visible()
                expect(page.locator('#tutorials #assistant-tutorial')).to_be_visible()
                expect(page.locator('#assistant-sale strong')).to_have_text('12.50 USDT')
                page.locator('#assistant-sale summary').click()
                expect(page.locator('#assistant-sale .assistant-body')).to_contain_text('<img')
                expect(page.locator('#assistant-sale img')).to_have_count(0)
                for language in ('fa','en','ar','es'):
                    page.locator('.language').select_option(language)
                    page.set_viewport_size({'width':390,'height':844})
                    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
                page.locator('.language').select_option('fa')
                page.goto(origin+'/admin')
                assert page.request.get(origin+'/api/admin/assistant').status==401
                page.locator('[name=password]').fill(password)
                page.locator('#login-form [type=submit]').click()
                page.locator('[data-tab=assistant]').click()
                expect(page.locator('#assistant-form')).to_be_visible()
                expect(page.locator('[name=enabled]')).not_to_be_checked()
                assert page.request.put(origin+'/api/admin/assistant',data={'enabled':False}).status==403
                page.locator('[name=channel]').fill('@my_channel')
                page.locator('[name=bot_token]').fill('LOCAL_TEST_BOT_SENTINEL')
                page.locator('[name=api_key]').fill('LOCAL_TEST_AI_SENTINEL')
                with page.expect_response('**/api/admin/assistant') as saved:
                    page.locator('#assistant-form [type=submit]').click()
                assert saved.value.status==200
                response=page.request.get(origin+'/api/admin/assistant')
                assert 'SENTINEL' not in response.text()
                assert response.json()['runtime']['state']=='disabled'
                assert page.request.get(origin+'/data/assistant-config.json').status==404
                assert page.request.get(origin+'/assistant-config.json').status==404
                page.reload();page.locator('[data-tab=assistant]').click()
                expect(page.locator('[name=channel]')).to_have_value('@my_channel')
                expect(page.locator('[name=api_key]')).to_have_value('')
                page.locator('[name=source]').select_option('account')
                expect(page.locator('[name=bot_token]')).to_be_hidden()
                page.locator('[name=telegram_api_id]').fill('123456')
                page.locator('[name=telegram_api_hash]').fill('a'*32)
                with page.expect_response('**/api/admin/assistant') as account_saved:
                    page.locator('#assistant-form [type=submit]').click()
                assert account_saved.value.status==200
                account_config=page.request.get(origin+'/api/admin/assistant').json()['config']
                assert account_config['source']=='account'
                assert 'telegram_api_hash' not in account_config
                page.reload();page.locator('[data-tab=assistant]').click()
                expect(page.locator('[name=source]')).to_have_value('account')
                expect(page.locator('[name=telegram_api_hash]')).to_have_value('')
                page.set_viewport_size({'width':1440,'height':1000})
                page.screenshot(path='/workspace/LionXsec-Shop-v1.5-account-admin.png',full_page=True)
                assert not errors,errors
                assert not external,external
                browser.close()
                print('PASS: local server/worker, three publish destinations, escaped AI text, four languages/mobile, admin setup/save, CSRF/authentication, secret redaction, private config inaccessible, zero external calls. Model/Telegram responses simulated.')
        finally:
            runner.stop.set();runner.thread.join(timeout=4)
            app.shutdown();app.server_close();thread.join()


if __name__=='__main__':
    run()
