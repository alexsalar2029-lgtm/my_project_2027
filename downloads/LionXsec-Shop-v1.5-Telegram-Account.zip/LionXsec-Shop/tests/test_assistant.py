import json
from pathlib import Path
import tempfile
import unittest

from server import Store
from automation import ingest, process_one, public_posts, status, validate
from assistant import Model, Telegram, import_history, read_config, save_config


def translated(text):
    return dict.fromkeys(('fa','en','ar','es'),text)


def result(kind='sale', title='Premium subscription'):
    return {'kind':kind,'title':translated(title),'summary':translated('Source-based summary'),
            'body':translated('Source-based details'),'price':{'amount':'12.50','currency':'USDT'}}


def update(uid=1, mid=10, text='Subscription 12.50 USDT', edited=False, chat=-1001234567890):
    return {'update_id':uid,'edited_channel_post' if edited else 'channel_post':{
        'message_id':mid,'text':text,'chat':{'id':chat,'type':'channel','username':'my_channel'}}}


class FakeModel:
    def __init__(self, value=None):
        self.value = value or result()
    def analyze(self, text):
        return self.value


class AssistantTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.temp.name)/'shop.sqlite3')
    def tearDown(self):
        self.temp.cleanup()
    def enqueue(self, *updates):
        ingest(self.store,list(updates),'@my_channel','test-offset')

    def test_full_transport_classify_queue_publish_and_duplicate(self):
        calls=[]
        def transport(url,payload,headers=None):
            calls.append((url,payload))
            if url.endswith('getUpdates'):
                return {'ok':True,'result':[update()]}
            self.assertEqual(headers['Authorization'],'Bearer local-test-key')
            self.assertIn('untrusted',payload['messages'][0]['content'])
            self.assertEqual(json.loads(payload['messages'][1]['content'])['source_post'],'Subscription 12.50 USDT')
            return {'choices':[{'message':{'content':json.dumps(result())}}]}
        telegram=Telegram('test-token',transport)
        self.enqueue(*telegram.call('getUpdates',{'offset':0}))
        self.assertTrue(process_one(self.store,Model({'api_key':'local-test-key','model':'test-model'},transport)))
        self.enqueue(update())
        self.assertFalse(process_one(self.store,FakeModel()))
        posts=public_posts(Store(self.store.path))
        self.assertEqual(len(posts),1)
        self.assertEqual(posts[0]['price'],{'amount':'12.50','currency':'USDT'})
        self.assertEqual(posts[0]['source_url'],'https://t.me/my_channel/10')
        self.assertEqual(status(self.store)['counts'],{'published':1})

    def test_other_channels_and_user_messages_never_queue(self):
        other=update(chat=-1009999999999)
        other['channel_post']['chat']['username']='unrelated_channel'
        self.enqueue(other,{'update_id':2,'message':update()['channel_post']})
        self.assertFalse(process_one(self.store,FakeModel()))
        with self.store.db() as db:
            self.assertEqual(db.execute("SELECT value FROM assistant_state WHERE key='test-offset'").fetchone()[0],'3')

    def test_edited_post_replaces_published_record_and_can_change_kind(self):
        self.enqueue(update())
        process_one(self.store,FakeModel())
        original=public_posts(self.store)[0]['id']
        self.enqueue(update(uid=2,text='Educational tutorial',edited=True))
        process_one(self.store,FakeModel(result('tutorial','Updated guide')))
        posts=public_posts(self.store)
        self.assertEqual(len(posts),1)
        self.assertEqual(posts[0]['id'],original)
        self.assertEqual(posts[0]['kind'],'tutorial')
        self.assertIsNone(posts[0]['price'])

    def test_edit_arriving_during_model_call_cannot_publish_stale_text(self):
        self.enqueue(update())
        outer=self
        class EditingModel:
            def analyze(self,text):
                outer.enqueue(update(uid=2,text='New source',edited=True))
                return result()
        process_one(self.store,EditingModel())
        self.assertEqual(public_posts(self.store),[])
        self.assertEqual(status(self.store)['counts'],{'pending':1})

    def test_bad_model_response_stays_unpublished_and_can_retry(self):
        self.enqueue(update())
        process_one(self.store,FakeModel({'kind':'sale','title':'broken'}))
        self.assertEqual(public_posts(self.store),[])
        self.assertEqual(status(self.store)['counts'],{'retry':1})
        with self.store.db() as db:
            db.execute('UPDATE assistant_jobs SET retry_at=0')
        process_one(self.store,FakeModel())
        self.assertEqual(len(public_posts(self.store)),1)

    def test_invented_prices_and_currencies_are_not_published(self):
        self.assertIsNone(validate(result(),'No price was given')['price'])
        self.assertIsNone(validate(result(),'12.50 USD')['price'])
        self.assertIsNone(validate(result(),'112.50 USDT')['price'])
        self.assertEqual(validate(result(),'۱۲٫۵۰ USDT')['price']['amount'],'12.50')

    def test_ignore_removes_previously_published_post(self):
        self.enqueue(update())
        process_one(self.store,FakeModel())
        self.enqueue(update(uid=2,text='Unrelated announcement',edited=True))
        process_one(self.store,FakeModel({'kind':'ignore'}))
        self.assertEqual(public_posts(self.store),[])

    def test_configuration_is_disabled_by_default_and_secrets_never_returned(self):
        self.assertFalse(read_config(self.store)['enabled'])
        data={'enabled':True,'channel':'@my_channel','model':'gpt-4.1-mini','bot_token':'test-bot-secret','api_key':'test-api-secret'}
        response=save_config(self.store,data)
        self.assertNotIn('secret',json.dumps(response))
        self.assertTrue(response['api_key_set'])
        save_config(self.store,{**data,'bot_token':'','api_key':''})
        self.assertEqual(read_config(self.store)['api_key'],'test-api-secret')
        with self.assertRaises(ValueError):
            save_config(self.store,{**data,'channel':'https://t.me/not-identifier'})

    def test_export_channel_verification_and_import_deduplication(self):
        export=Path(self.temp.name)/'export.json'
        export.write_text(json.dumps({'id':1234567890,'messages':[{'id':10,'type':'message','text':['Subscription ',{'text':'12.50 USDT'}]}]}))
        with self.assertRaises(ValueError):
            import_history(self.store,export,'-1009999999999')
        import_history(self.store,export,'-1001234567890')
        import_history(self.store,export,'-1001234567890')
        process_one(self.store,FakeModel())
        self.assertEqual(len(public_posts(self.store)),1)
