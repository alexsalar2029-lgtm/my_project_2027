import {api,esc,lang} from './shared.js';
import {assistantStates,assistantError} from './assistant-status.js';
export const assistantLabel=()=>({fa:'دستیار تلگرام',en:'Telegram assistant',ar:'مساعد تيليجرام',es:'Asistente Telegram'}[lang]);
const labels=()=>({
 fa:{help:'کانال تحت مدیریت خود را وارد کنید و ربات اختصاصی را به آن اضافه کنید. پس از فعال‌سازی، دریافت، تحلیل و انتشار خودکار است. فیلدهای دارای ✓ را خالی بگذارید تا مقدار ذخیره‌شده حفظ شود.',channel:'کانال (@channel، ‎-100… یا لینک دعوت خصوصی در حالت حساب)',bot:'توکن ربات تلگرام',key:'کلید API OpenAI',model:'مدل OpenAI',enable:'فعال‌سازی انتشار خودکار',save:'ذخیره تنظیمات',saved:'ذخیره شد؛ دستیار در اجرای عادی سایت خودکار شروع می‌شود.',status:'وضعیت پردازش',recent:'آخرین پست‌ها',placeholder:'فقط برای جایگزینی مقدار جدید وارد کنید',error:'تنظیمات معتبر نیست.',privacy:'کلیدها فقط روی دستگاه میزبان در پوشه data ذخیره می‌شوند و در پاسخ API نمایش داده نمی‌شوند. متن و تصویر پیش‌نمایش رسانه برای تحلیل به OpenAI ارسال می‌شود و API هزینه دارد.'},
 en:{help:'Add a dedicated bot to your own channel. Once enabled, intake, analysis and publishing run automatically. Empty secret fields preserve saved values.',channel:'Channel (@channel or -100…)',bot:'Telegram bot token',key:'OpenAI API key',model:'OpenAI model',enable:'Enable automatic publishing',save:'Save settings',saved:'Saved; the assistant starts automatically when running the site normally.',status:'Processing status',recent:'Recent posts',placeholder:'Enter a new value to replace',error:'Check the channel, model, Telegram token and OpenAI key.',privacy:'Keys are stored in the local data folder and never returned by the API. Post text is sent to OpenAI; API usage is billed.'},
 ar:{help:'أضف بوتًا مخصصًا إلى قناتك. بعد التفعيل يتم التحليل والنشر تلقائيًا.',channel:'معرّف القناة',bot:'توكن البوت',key:'مفتاح OpenAI',model:'نموذج OpenAI',enable:'تفعيل النشر التلقائي',save:'حفظ',saved:'تم الحفظ.',status:'حالة المعالجة',recent:'آخر المنشورات',placeholder:'قيمة جديدة للاستبدال',error:'تحقق من إعدادات القناة والمفاتيح.',privacy:'تُحفظ المفاتيح محليًا في data. يُرسل النص إلى OpenAI للتحليل بتكلفة API.'},
 es:{help:'Añade un bot dedicado a tu canal. Al activar, la clasificación y publicación son automáticas.',channel:'Canal',bot:'Token de Telegram',key:'Clave de OpenAI',model:'Modelo OpenAI',enable:'Activar publicación automática',save:'Guardar',saved:'Guardado.',status:'Estado',recent:'Publicaciones recientes',placeholder:'Nuevo valor para reemplazar',error:'Revisa el canal, modelo y claves.',privacy:'Las claves se guardan en data. Los textos se envían a OpenAI y la API tiene coste.'}
}[lang]);
export async function renderAssistant(container,mutate){
 const result=await api('/api/admin/assistant'),c=result.config,l=labels();
 container.innerHTML=`<form id="assistant-form" class="panel settings-panel"><h2>${esc(assistantLabel())}</h2><p class="notice">${esc(l.help)}</p><p class="small muted">${esc(l.privacy)}</p><label class="field">${esc(l.channel)}<input name="channel" dir="ltr" value="${esc(c.channel)}" maxlength="40" placeholder="@your_channel"></label><label class="field">${esc(l.bot)} · ${c.bot_token_set?'✓':'—'}<input name="bot_token" type="password" dir="ltr" autocomplete="new-password" maxlength="500" placeholder="${esc(l.placeholder)}"></label><label class="field">${esc(l.key)} · ${c.api_key_set?'✓':'—'}<input name="api_key" type="password" dir="ltr" autocomplete="new-password" maxlength="500" placeholder="${esc(l.placeholder)}"></label><label class="field">${esc(l.model)}<input name="model" dir="ltr" value="${esc(c.model)}" maxlength="100"></label><label class="check-field"><input type="checkbox" name="enabled" ${c.enabled?'checked':''}>${esc(l.enable)}</label><p class="form-error" id="assistant-error" role="alert" hidden></p><p id="assistant-saved" role="status"></p><button class="button primary" type="submit">${esc(l.save)}</button><h3>${esc(l.status)}</h3><p dir="ltr">${esc(result.runtime.state)} ${esc(result.runtime.code||'')}</p><pre dir="ltr">${esc(JSON.stringify(result.counts,null,2))}</pre><h3>${esc(l.recent)}</h3><div id="assistant-recent"></div></form>`;
 const names=assistantStates();
 container.querySelector('h3 + p').textContent=(names[result.runtime.state]||result.runtime.state)+(result.runtime.code?' · '+result.runtime.code:'');
 container.querySelector('pre').textContent=Object.entries(result.counts).map(([key,count])=>(names[key]||key)+': '+count).join('\n')||'—';
 const form=container.querySelector('form');
 const recovery={
  fa:{button:'تلاش دوباره موارد ناموفق',help:'فقط پست‌های ناموفق و در انتظار تلاش مجدد به صف برمی‌گردند. ابتدا تنظیمات مدل را ذخیره کنید؛ دستیار باید فعال باشد.',queued:'تعداد پست‌های آمادهٔ تلاش دوباره',attempts:'تلاش ناموفق',next:'تلاش بعدی'},
  en:{button:'Retry failed posts',help:'Requeue failed posts and scheduled retries only. Save model settings first and enable the assistant to process them.',queued:'Posts queued for another attempt',attempts:'Failed attempts',next:'Next retry'},
  ar:{button:'إعادة محاولة المنشورات الفاشلة',help:'تُعاد فقط المنشورات الفاشلة والمحاولات المجدولة. احفظ إعدادات النموذج أولًا وفعّل المساعد.',queued:'المنشورات الجاهزة لإعادة المحاولة',attempts:'المحاولات الفاشلة',next:'المحاولة التالية'},
  es:{button:'Reintentar publicaciones fallidas',help:'Reintenta solo los fallos y reintentos programados. Guarda la configuración del modelo y activa el asistente.',queued:'Publicaciones listas para reintentar',attempts:'Intentos fallidos',next:'Próximo intento'}
 }[lang];
 const renderRecent=state=>{
  form.querySelector('pre').textContent=Object.entries(state.counts).map(([key,count])=>(names[key]||key)+': '+count).join('\n')||'—';
  form.querySelector('#assistant-recent').innerHTML=state.recent.map(r=>`<p dir="auto">#${r.message} · ${esc(names[r.status]||r.status)}${r.error?' · '+esc(assistantError(r.error)):''}${r.attempts?' · '+esc(recovery.attempts)+': '+r.attempts:''}${r.status==='retry'&&r.retry_at?' · '+esc(recovery.next)+': '+esc(new Date(r.retry_at*1000).toLocaleTimeString(lang)):''}</p>`).join('');
 };
 renderRecent(result);
 form.insertAdjacentHTML('beforeend',`<div class="assistant-rewrite"><p class="small muted">${esc(recovery.help)}</p><button type="button" class="button secondary" id="assistant-retry">${esc(recovery.button)}</button><p id="assistant-retry-result" role="status"></p></div>`);
 form.querySelector('#assistant-retry').addEventListener('click',async e=>{
  const button=e.currentTarget,feedback=form.querySelector('#assistant-retry-result');
  button.disabled=true;
  try{
   const response=await mutate('/api/admin/assistant/retry','POST',{});
   feedback.textContent=recovery.queued+': '+response.queued;
   renderRecent(await api('/api/admin/assistant'));
  }catch(err){feedback.textContent=err.message||l.error;}
  finally{button.disabled=false;}
 });
 const rewrite={
  fa:{button:'بازنویسی پست‌های منتشرشده',help:'عنوان و توضیحات پست‌های قبلی با تنظیمات فعلی هوش مصنوعی بازنویسی می‌شود. دستیار باید فعال باشد؛ متن فعلی تا آماده‌شدن جایگزین نمایش داده می‌شود.',queued:'تعداد پست‌های اضافه‌شده به صف بازنویسی'},
  en:{button:'Rewrite published posts',help:'Rewrite previous titles and descriptions using the current AI settings. Enable the assistant to process them; current posts stay visible until their replacements are ready.',queued:'Posts queued for rewriting'},
  ar:{button:'إعادة كتابة المنشورات المنشورة',help:'تُعاد كتابة العناوين والتفاصيل بإعدادات الذكاء الاصطناعي الحالية. فعّل المساعد للمعالجة؛ يبقى النص الحالي ظاهرًا حتى يجهز البديل.',queued:'المنشورات المضافة إلى قائمة إعادة الكتابة'},
  es:{button:'Reescribir publicaciones',help:'Reescribe los títulos y las descripciones con la configuración de IA actual. Activa el asistente; las publicaciones actuales siguen visibles hasta que estén listas sus sustitutas.',queued:'Publicaciones en cola para reescribir'}
 }[lang];
 form.insertAdjacentHTML('beforeend',`<div class="assistant-rewrite"><p class="small muted">${esc(rewrite.help)}</p><button type="button" class="button secondary" id="assistant-reprocess">${esc(rewrite.button)}</button><p id="assistant-reprocess-result" role="status"></p></div>`);
 form.querySelector('#assistant-reprocess').addEventListener('click',async e=>{
  const button=e.currentTarget,feedback=form.querySelector('#assistant-reprocess-result');
  button.disabled=true;
  try{
   const response=await mutate('/api/admin/assistant/reprocess','POST',{});
   feedback.textContent=rewrite.queued+': '+response.queued;
   const state=await api('/api/admin/assistant');
   renderRecent(state);
  }catch(err){feedback.textContent=err.message||l.error;}
  finally{button.disabled=false;}
 });
 form.elements.channel.maxLength=200;
 const accountLabels={fa:{source:'روش دریافت تلگرام',bot:'ربات (پست‌های جدید)',account:'حساب کاربری (تاریخچه، کانال خصوصی و رسانه)',provider:'روش تحلیل هوش مصنوعی',openai:'OpenAI آنلاین (نیازمند اعتبار API)',ollama:'Ollama محلی رایگان',help:'App API ID و API hash را ذخیره کنید. حساب باید از قبل عضو و مدیر کانال خصوصی باشد. سپس روی همین دستگاه، python telegram_account.py login و بعد python telegram_account.py watch را اجرا کنید. کپشن، نوع رسانه و تصویر پیش‌نمایش عکس/ویدیو تحلیل می‌شود. شماره تلفن، کد ورود و رمز دومرحله‌ای فقط در ترمینال محلی وارد می‌شوند.',receiver:'دریافت‌کننده حساب'},en:{source:'Telegram intake',bot:'Bot (new posts)',account:'User account (history, private channels and media)',provider:'AI analysis provider',openai:'Online OpenAI (API billing required)',ollama:'Free local Ollama',help:'Save the App API ID and API hash here. The account must already be a member and admin of a private channel. Run python telegram_account.py login, then python telegram_account.py watch on this device. Captions, media type and photo/video previews are analyzed. Enter your phone, login code and two-step password only in your local terminal.',receiver:'Account receiver'}};
 const a=accountLabels[lang]||accountLabels.en;
 form.querySelector('h2').insertAdjacentHTML('afterend',`<label class="field">${esc(a.source)}<select name="source"><option value="bot">${esc(a.bot)}</option><option value="account">${esc(a.account)}</option></select></label><div id="account-fields"><p class="notice">${esc(a.help)}</p><label class="field">Telegram App API ID<input name="telegram_api_id" dir="ltr" inputmode="numeric" maxlength="16" value="${esc(c.telegram_api_id||'')}"></label><label class="field">Telegram API hash · ${c.telegram_api_hash_set?'✓':'—'}<input name="telegram_api_hash" type="password" dir="ltr" autocomplete="new-password" maxlength="32" placeholder="${esc(l.placeholder)}"></label><p>${esc(a.receiver)}: ${esc(result.receiver?.state||'not_started')}</p></div>`);
 form.querySelector('#account-fields').insertAdjacentHTML('afterend',`<label class="field">${esc(a.provider)}<select name="provider"><option value="openai">${esc(a.openai)}</option><option value="ollama">${esc(a.ollama)}</option></select></label>`);
 form.elements.source.value=c.source||'bot';
 form.elements.provider.value=c.provider||'openai';
 const updateSource=()=>{const account=form.elements.source.value==='account';form.querySelector('#account-fields').hidden=!account;form.elements.bot_token.closest('label').hidden=account;form.querySelector(':scope > .notice').hidden=account;};
 const updateProvider=()=>{const local=form.elements.provider.value==='ollama';form.elements.api_key.closest('label').hidden=local;if(local&&form.elements.model.value==='gpt-4.1-mini')form.elements.model.value='qwen3-vl:4b';};
 form.elements.source.addEventListener('change',updateSource);updateSource();
 form.elements.provider.addEventListener('change',updateProvider);updateProvider();
 form.addEventListener('submit',async e=>{
  e.preventDefault();const f=new FormData(form),b=form.querySelector('button[type=submit]'),error=form.querySelector('#assistant-error');b.disabled=true;error.hidden=true;
  try{await mutate('/api/admin/assistant','PUT',{source:f.get('source'),provider:f.get('provider'),telegram_api_id:f.get('telegram_api_id'),telegram_api_hash:f.get('telegram_api_hash'),channel:f.get('channel'),model:f.get('model'),bot_token:f.get('bot_token'),api_key:f.get('api_key'),enabled:f.get('enabled')==='on'});form.elements.bot_token.value='';form.elements.api_key.value='';form.elements.telegram_api_hash.value='';form.querySelector('#assistant-saved').textContent=l.saved;}
  catch(err){const details={invalid_assistant_channel:'لینک یا شناسه کانال معتبر نیست؛ برای لینک خصوصی روش حساب کاربری را انتخاب کنید.',invalid_assistant_model:'نام مدل OpenAI معتبر نیست.',invalid_telegram_api_id:'Telegram App API ID فقط باید عدد باشد.',invalid_telegram_api_hash:'Telegram API hash باید دقیقاً ۳۲ نویسه هگز باشد.',invalid_api_key:'کلید OpenAI دارای فاصله یا نویسه نامعتبر است.',invalid_bot_token:'توکن ربات معتبر نیست.',missing_channel:'کانال وارد نشده است.',missing_api_key:'کلید OpenAI ذخیره نشده است.',missing_bot_token:'توکن ربات ذخیره نشده است.',missing_telegram_api_id:'Telegram App API ID ذخیره نشده است.',missing_telegram_api_hash:'Telegram API hash ذخیره نشده است.'};error.textContent=details[err.code]||err.message||l.error;error.hidden=false;}finally{b.disabled=false;}
 });
}
